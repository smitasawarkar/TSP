package com.maveric.spectrum.endoresmentms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EndorsedRequestDTO {
	
	private Integer empId;
	private Integer managerId;
	private List<SkillDataDTO> skills;

}
