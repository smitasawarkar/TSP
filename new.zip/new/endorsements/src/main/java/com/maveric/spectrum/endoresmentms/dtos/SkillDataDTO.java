package com.maveric.spectrum.endoresmentms.dtos;

import lombok.Data;

@Data

public class SkillDataDTO {
	private Integer skillId;
	private String skillName;

}
