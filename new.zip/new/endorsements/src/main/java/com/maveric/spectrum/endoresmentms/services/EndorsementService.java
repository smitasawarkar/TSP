package com.maveric.spectrum.endoresmentms.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.endoresmentms.dtos.EndorsedRequestDTO;
import com.maveric.spectrum.endoresmentms.dtos.EndorsedResponseDTO;

public interface EndorsementService {

	ResponseEntity<String> saveEndorsement(EndorsedRequestDTO endorsedRequestDTO);
	List<EndorsedResponseDTO> getCountOfEndorsedSkill();
}
