package com.maveric.spectrum.endoresmentms.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.endoresmentms.dtos.EndorsedRequestDTO;
import com.maveric.spectrum.endoresmentms.dtos.EndorsedResponseDTO;
import com.maveric.spectrum.endoresmentms.dtos.SkillDataDTO;
import com.maveric.spectrum.endoresmentms.entities.Endorsement;
import com.maveric.spectrum.endoresmentms.repositories.EndorsementRepository;
import com.maveric.spectrum.endoresmentms.utils.EndorsementKeyWord;

@Service
public class EndorsementServiceImpl implements EndorsementService{
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${myapp.urls.api.requestEndorsement}")
	private String requestEndorsementUrl;

	@Autowired
	private EndorsementRepository endorseRepo;
	@Override
	public ResponseEntity<String> saveEndorsement(EndorsedRequestDTO endorsedRequestDTO) {
		// TODO Auto-generated method stub
		for(SkillDataDTO skills:endorsedRequestDTO.getSkills()) {
			Endorsement endorse=new Endorsement();
			endorse.setEmployeeId(endorsedRequestDTO.getEmpId());
			endorse.setEndorsedDateTime(LocalDateTime.now().toString());
			endorse.setManagerId(endorsedRequestDTO.getManagerId());
			endorse.setSkillId(skills.getSkillId());
			endorseRepo.save(endorse);
		}
		
		ResponseEntity<String> endorseStatus=restTemplate.postForEntity(requestEndorsementUrl, endorsedRequestDTO, null);
		return new ResponseEntity<String>(EndorsementKeyWord.response,HttpStatus.OK);
	}
	
	@Override
    public List<EndorsedResponseDTO> getCountOfEndorsedSkill() {
        List<Endorsement> endorsements = endorseRepo.findEndorsementsByEmployeeId();
        Map<Integer, Integer> skillCountMap = new HashMap<>();

        for (Endorsement endorsement : endorsements) {
            Integer skillId = endorsement.getSkillId();
            skillCountMap.put(skillId, skillCountMap.getOrDefault(skillId, 0) + 1);
        }

        List<EndorsedResponseDTO> endorsedResponseDTOs = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : skillCountMap.entrySet()) {
            EndorsedResponseDTO dto = new EndorsedResponseDTO();
            dto.setSkillId(entry.getKey());
            dto.setSkillEndorsedCount(entry.getValue());
            endorsedResponseDTOs.add(dto);
        }

        return endorsedResponseDTOs;
    }

}
