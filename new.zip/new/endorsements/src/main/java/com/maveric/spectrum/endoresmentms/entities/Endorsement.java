package com.maveric.spectrum.endoresmentms.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name="endorsement")

public class Endorsement {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id")
	private Integer id;
	
	@Column(name="skill_id", nullable = false)
	private Integer skillId;
	
	@Column(name="manager_id", nullable = false)
	private Integer managerId;
	
	@Column(name="employee_id", nullable = false)
	private Integer employeeId;
	
	@Column(name="endorsed_time")
	private String endorsedDateTime;
	
	
	

}
