package com.maveric.spectrum.endoresmentms.dtos;

import lombok.Data;

@Data
public class EndorsedResponseDTO {
	
	private Integer skillId;
	private Integer skillEndorsedCount;

}
