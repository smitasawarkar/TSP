package com.maveric.spectrum.endoresmentms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.maveric.spectrum.endoresmentms.dtos.EndorsedResponseDTO;
import com.maveric.spectrum.endoresmentms.entities.Endorsement;

@Repository
public interface EndorsementRepository extends JpaRepository<Endorsement, Integer>{

	List<Endorsement> getByEmployeeId(Integer empId);

	@Query("SELECT DISTINCT e.skillId FROM Endorsement e WHERE e.employeeId = :employeeId")
    List<Integer> findSkillsByEmployeeId(@Param("employeeId") Integer employeeId);

//	@Query("SELECT e.skillId, COUNT(e.skillId) FROM Endorsement e WHERE e.employeeId = :employeeId GROUP BY e.skillId")
//	List<EndorsedResponseDTO[]> countSkillsByEmployeeId(@Param("employeeId") Integer employeeId);
//	
//	 @Query("SELECT COUNT(s) FROM Skill s WHERE s.skillId = :skillId")
//	 Long countBySkillId(@Param("skillId") Long skillId);
	
	
    @Query("SELECT e FROM Endorsement e WHERE e.employeeId = 1")
    List<Endorsement> findEndorsementsByEmployeeId();

}
