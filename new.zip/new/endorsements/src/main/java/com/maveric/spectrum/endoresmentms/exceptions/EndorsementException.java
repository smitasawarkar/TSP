package com.maveric.spectrum.endoresmentms.exceptions;

public class EndorsementException {

}
