package com.maveric.spectrum.endoresmentms.utils;

public class EndorsementKeyWord {
	
	public static final String response="Details Stored";

}
