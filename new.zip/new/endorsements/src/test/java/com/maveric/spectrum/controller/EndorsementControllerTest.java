//package com.maveric.spectrum.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.maveric.spectrum.endoresmentms.controllers.EndorsementController;
//import com.maveric.spectrum.endoresmentms.dtos.EndorsedRequestDTO;
//import com.maveric.spectrum.endoresmentms.dtos.EndorsedResponseDTO;
//import com.maveric.spectrum.endoresmentms.services.EndorsementService;
// 
//public class EndorsementControllerTest {
//	 private EndorsementController endorsementController;
//	    private EndorsementService endorsementServiceMock;
// 
//	    @BeforeEach
//	    public void setup() {
//	        endorsementServiceMock = mock(EndorsementService.class);
//	        endorsementController = new EndorsementController();
//	        endorsementController.setEndorsementService(endorsementServiceMock);
//	    }
// 
//	    @Test
//	    public void testSaveEndorseDetails() {
//	        // Given
//	        EndorsedRequestDTO requestDTO = new EndorsedRequestDTO();
//	        ResponseEntity<String> mockResponse = new ResponseEntity<>("Success", HttpStatus.OK);
//	        when(endorsementServiceMock.saveEndorsement(any(EndorsedRequestDTO.class)))
//	                .thenReturn(mockResponse);
// 
//	        // When
//	        ResponseEntity<String> responseEntity = endorsementController.postMethodName(requestDTO);
// 
//	        // Then
//	        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
//	        assertEquals("Success", responseEntity.getBody());
//	    }
// 
//	    @Test
//	    public void testGetEndorsedSkillDetails() {
//	        // Given
//	        List<EndorsedResponseDTO> mockResponse = new ArrayList<>();
//	        when(endorsementServiceMock.getCountOfEndorsedSkill())
//	                .thenReturn(mockResponse);
// 
//	        // When
//	        List<EndorsedResponseDTO> response = endorsementController.getMethodName();
// 
//	        // Then
//	        assertEquals(mockResponse, response);
//	    }
// 
//}
