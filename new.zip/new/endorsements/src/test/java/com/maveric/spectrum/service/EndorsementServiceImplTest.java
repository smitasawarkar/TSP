//package com.maveric.spectrum.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.client.RestTemplate;
//
//import com.maveric.spectrum.endoresmentms.dtos.EndorsedRequestDTO;
//import com.maveric.spectrum.endoresmentms.dtos.SkillDataDTO;
//import com.maveric.spectrum.endoresmentms.repositories.EndorsementRepository;
//import com.maveric.spectrum.endoresmentms.services.EndorsementServiceImpl;
// 
//public class EndorsementServiceImplTest { 
//	 private EndorsementServiceImpl endorsementService;
//	    private EndorsementRepository endorsementRepositoryMock;
//	    private RestTemplate restTemplateMock;
// 
//	    @BeforeEach
//	    public void setup() {
//	        endorsementRepositoryMock = mock(EndorsementRepository.class);
//	        restTemplateMock = mock(RestTemplate.class);
//	        endorsementService = new EndorsementServiceImpl();
//	        endorsementService.setEndorseRepo(endorsementRepositoryMock);
//	        endorsementService.setRestTemplate(restTemplateMock);
//	    }
// 
//	    @Test
//	    public void testSaveEndorsement() {
//	        // Given
//	        EndorsedRequestDTO requestDTO = new EndorsedRequestDTO();
//	        requestDTO.setEmpId(1);
//	        requestDTO.setManagerId(2);
//	        List<SkillDataDTO> skills = new ArrayList<>();
//	        SkillDataDTO skill = new SkillDataDTO();
//	        skill.setSkillId(101);
//	        skills.add(skill);
//	        requestDTO.setSkills(skills);
// 
//	        ResponseEntity<String> mockResponse = new ResponseEntity<>("Success", HttpStatus.OK);
//	        when(restTemplateMock.postForEntity(any(String.class), any(EndorsedRequestDTO.class), any(Class.class)))
//	                .thenReturn(mockResponse);
// 
//	        // When
//	        ResponseEntity<String> responseEntity = endorsementService.saveEndorsement(requestDTO);
// 
//	        // Then
//	        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
//	        assertEquals("Details Stored", responseEntity.getBody());
//	    }
// 
//	    @Test
//	    public void testGetCountOfEndorsedSkill() {
//	        // Write test cases for getCountOfEndorsedSkill method here
//	    }
//}
//
