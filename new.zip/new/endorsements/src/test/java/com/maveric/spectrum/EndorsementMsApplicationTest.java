//package com.maveric.spectrum;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.maveric.spectrum.endoresmentms.EndorsementMsApplication;
//
//@SpringBootTest(classes = EndorsementMsApplication.class)
//class EndorsementMsApplicationTest {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
