package com.maveric.spectrum.requestendorsementms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EndorsementResponseDTO {
	
	private Integer managerId;
	private List<EndorseEmployeeDTO> endorseSkillDTO;

}
