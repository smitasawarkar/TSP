package com.maveric.spectrum.requestendorsementms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EmployeeEducationResponseDTO {

	private Integer id;
    private String educationTitle;
    private String instituteName;
    private String place;
    private String startDuration;
    private String endDuration;
    private Double score;
    private String fieldOfStudy;
    private List<String> activitiesAndSocieties;
    private List<Integer> skillIds;
}