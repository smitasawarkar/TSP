package com.maveric.spectrum.requestendorsementms.dtos;

import lombok.Data;

@Data

public class SkillDataDTO {
	private Integer skillId;
	private String skillName;
	private Integer skillEndorsementId;

}
