package com.maveric.spectrum.requestendorsementms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableDiscoveryClient
public class SpectrumRequestEndorsementMsApplication extends SpringBootServletInitializer{

	public static void main(String[] args) {
		System.out.println("Entered application");
		SpringApplication.run(SpectrumRequestEndorsementMsApplication.class, args);
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(SpectrumRequestEndorsementMsApplication.class);
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
