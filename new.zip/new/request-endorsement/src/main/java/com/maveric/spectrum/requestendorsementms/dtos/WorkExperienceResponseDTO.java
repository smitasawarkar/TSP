package com.maveric.spectrum.requestendorsementms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class WorkExperienceResponseDTO {

	private Integer id;
    private String jobTitle;
    private String companyName;
    private String startDate;
    private String endDate;
    private String location;
    private String employeeType;
    private String industry;
    private String locationType;
    private Boolean isActive;
    private List<Integer> skillIds;
}