package com.maveric.spectrum.requestendorsementms.utils;

public class RequestEndorsementKeyWord {
	
	public static final String RESPONSE="Details Stored";

}
