package com.maveric.spectrum.requestendorsementms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EmployeeCertificateResponseDTO {

	private Integer id;
    private String certificationName;
    private String issuingOrganization;
    private String issuingDate;
    private String expirationDate;
    private String credentialId;
    private String credentialURL;
    private List<Integer> skillIds;
}