package com.maveric.spectrum.requestendorsementms.controller;

import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.requestendorsementms.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsedRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementResponseDTO;
import com.maveric.spectrum.requestendorsementms.exceptions.DataUnavailableException;
import com.maveric.spectrum.requestendorsementms.services.RequestEndorsementService;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin
@RequestMapping("/api/spectrum/requestEndorsement")
public class RequestEndorsementController {

	@Autowired
	private RequestEndorsementService service;

	@PostMapping("/storeSkill")
	public ResponseEntity<String> storeSkill(@RequestBody EndorsementRequestDTO request)
			throws URISyntaxException, DataUnavailableException {
		System.out.println("Received request for storing the details"+request);
		return service.storeSkills(request);
	}

	@GetMapping("/getEndorsementDetails/{id}")
	public EndorsementResponseDTO getEndorsementDetails(@PathVariable("id") Integer id) throws URISyntaxException, DataUnavailableException {
		System.out.println("Received request for getting endorsement details with id: "+id);
		return service.getListOfEndorsementRequestDetails(id);
	}

	@PostMapping("/setEndorseStatus")
	public ResponseEntity<String> setEndorseStatus(@RequestBody EndorsedRequestDTO endorsedRequestDTO) {
		// TODO: process POST request
		return service.setEndorsedStatus(endorsedRequestDTO);
	}

	@GetMapping("/getProfile/{id}")
	public ResponseEntity<EmployeeResponseDTO> getProfile(@PathVariable("id") Integer id) throws URISyntaxException, DataUnavailableException {
		return service.getProfile(id);
	}

}
