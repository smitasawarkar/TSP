package com.maveric.spectrum.requestendorsementms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.maveric.spectrum.requestendorsementms.entities.EndorsementRequest;

import jakarta.transaction.Transactional;

@Repository
public interface EndorsementRequestRepository extends JpaRepository<EndorsementRequest, Integer> {
	
	List<EndorsementRequest> getAllByManagerId(int id);

	@Query("SELECT er.skillId FROM EndorsementRequest er WHERE er.employeeId = :employeeId AND er.managerId = :managerId AND er.endorsedStatus = false")
	List<Integer> getAllSkillIdsByEmployeeIdAndManagerIdWithFalseEndorsedStatus(@Param("employeeId") Integer employeeId, @Param("managerId") Integer managerId);

	@Transactional
	@Modifying
	@Query("UPDATE EndorsementRequest er SET er.endorsedStatus = true WHERE er.employeeId = :employeeId AND er.managerId = :managerId AND er.skillId = :skillId")
	void setEndorsedStatusToTrue(@Param("employeeId") Integer employeeId, @Param("managerId") Integer managerId, @Param("skillId") Integer skillId);

	@Query("SELECT er.id FROM EndorsementRequest er WHERE er.skillId = :skillId")
	List<Integer> getIdBySkillId(@Param("skillId") Integer skillId);

    boolean existsBySkillIdAndManagerIdAndEmployeeId(Integer skillId, Integer managerId, Integer employeeId);

	boolean existsBySkillId(Integer skillId);
	}
