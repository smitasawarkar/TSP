package com.maveric.spectrum.requestendorsementms.dtos;
 
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class SkillClusterDTO {
 
	private Integer clusterId;
 
	private String clusterName;
}