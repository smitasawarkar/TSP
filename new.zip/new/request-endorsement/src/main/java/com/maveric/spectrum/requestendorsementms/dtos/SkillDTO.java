package com.maveric.spectrum.requestendorsementms.dtos;
 
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@NoArgsConstructor
public class SkillDTO {
	private Integer skillId;
 
	private String skillName;
 
	private List<SkillClusterDTO> skillClusterDTO;
 
}