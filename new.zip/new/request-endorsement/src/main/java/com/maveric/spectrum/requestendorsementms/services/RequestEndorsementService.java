package com.maveric.spectrum.requestendorsementms.services;

import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.requestendorsementms.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsedRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementResponseDTO;
import com.maveric.spectrum.requestendorsementms.exceptions.DataUnavailableException;

public interface RequestEndorsementService {
	
	ResponseEntity<String> storeSkills(EndorsementRequestDTO request) throws URISyntaxException, DataUnavailableException;

	ResponseEntity<EmployeeResponseDTO> getProfile(Integer id) throws URISyntaxException, DataUnavailableException;

	EndorsementResponseDTO getListOfEndorsementRequestDetails(Integer id) throws URISyntaxException, DataUnavailableException ;

	ResponseEntity<String> setEndorsedStatus(EndorsedRequestDTO endorsedRequestDTO);

}

