package com.maveric.spectrum.requestendorsementms.exceptions;

public class URISyntaxException extends Exception {

	public URISyntaxException(String msg) {
		super(msg);
	}

	public URISyntaxException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
