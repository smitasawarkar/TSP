package com.maveric.spectrum.requestendorsementms.services;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.requestendorsementms.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorseEmployeeDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsedRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementRequestDTO;
import com.maveric.spectrum.requestendorsementms.dtos.EndorsementResponseDTO;
import com.maveric.spectrum.requestendorsementms.dtos.SendNotificationDTO;
import com.maveric.spectrum.requestendorsementms.dtos.SkillDTO;
import com.maveric.spectrum.requestendorsementms.dtos.SkillDataDTO;
import com.maveric.spectrum.requestendorsementms.entities.EndorsementRequest;
import com.maveric.spectrum.requestendorsementms.exceptions.DataUnavailableException;
import com.maveric.spectrum.requestendorsementms.repositories.EndorsementRequestRepository;
import com.maveric.spectrum.requestendorsementms.utils.RequestEndorsementKeyWord;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RequestEndorsementServiceImpl implements RequestEndorsementService {
	@Autowired
	private RestTemplate rest;

	@Autowired
	private EndorsementRequestRepository endorsementRequestRepository;

	@Value("${myapp.urls.api.employeems}")
	private String employeeUrl;

	@Value("${myapp.urls.api.notification}")
	private String notificationUrl;

	@Value("${myapp.urls.api.skillclusterms}")
	private String skillClusterUrl;

	@Override
	public ResponseEntity<String> storeSkills(EndorsementRequestDTO request)
			throws URISyntaxException, DataUnavailableException {
		// Get employee profile with employee id
		ResponseEntity<EmployeeResponseDTO> employeeProfile = this.getProfile(request.getEmpId());
		System.out.println("employee response in storeskills method:"+employeeProfile);

		if (employeeProfile == null) {
			System.out.println("employee profile is null");
			throw new DataUnavailableException("Employee Not Found for the ID:" + request.getEmpId());
		}

		// set employee name
		String empName = employeeProfile.getBody().getFirstName() + " " + employeeProfile.getBody().getLastName();

		// save request data to database
		for (Integer managerId : request.getManagerIdList()) {
			for (Integer skill : request.getSkillList()) {
				if (endorsementRequestRepository.existsBySkillIdAndManagerIdAndEmployeeId(skill, managerId,
						request.getEmpId())) {
					System.out.println("employee details already exist");
					throw new DataUnavailableException("Endorsement details already exist");
				}
				System.out.println("storing endorsment detail in db");
				EndorsementRequest endorsementRequest = new EndorsementRequest();
				endorsementRequest.setEmployeeId(request.getEmpId());
				endorsementRequest.setEndorseRequestDateTime(LocalDateTime.now().toString());
				endorsementRequest.setManagerId(managerId);
				endorsementRequest.setSkillId(skill);
				endorsementRequest.setEndorsedStatus(false);
				endorsementRequestRepository.save(endorsementRequest);
				System.out.println("endorsement details stored in db");
			}

		}

		// creating object for notification
		SendNotificationDTO sendNotification = new SendNotificationDTO();
		sendNotification.setEmpId(request.getEmpId());
		sendNotification.setEmpName(empName);
		sendNotification.setManagerId(request.getManagerIdList());

		// sending notificationdata to notificationMS
		System.out.println("sending notification data to notificationms");
		ResponseEntity<String> notificationRequest = rest.postForEntity(notificationUrl, sendNotification,
				String.class);

		System.out.println("notification response"+notificationRequest);
		return new ResponseEntity<String>(RequestEndorsementKeyWord.RESPONSE, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<EmployeeResponseDTO> getProfile(Integer id)
			throws URISyntaxException, DataUnavailableException {
		System.out.println("calling the employeems to get profile with ID: " + id);
		ResponseEntity<EmployeeResponseDTO> response = rest.getForEntity(employeeUrl + "/" + id,
				EmployeeResponseDTO.class);
		System.out.println("employee response " + response);
		return response;

	}

	@Override
	public EndorsementResponseDTO getListOfEndorsementRequestDetails(Integer id)
			throws URISyntaxException, DataUnavailableException {
		// fetching managerlist
		List<EndorsementRequest> managerList = endorsementRequestRepository.getAllByManagerId(id);
		if (managerList.isEmpty()) {
			throw new DataUnavailableException("No manager found with ID:" + id);
		}
		EndorsementResponseDTO endorseResponse = new EndorsementResponseDTO();

		List<EndorseEmployeeDTO> endorseSkillList = new ArrayList<>();
		List<Integer> checklist = new ArrayList<>();
		for (EndorsementRequest endorsementRequest : managerList) {
			if (checklist.contains(endorsementRequest.getEmployeeId())) {

			} else {
				EndorseEmployeeDTO endorseSkillDTO = new EndorseEmployeeDTO();
				ResponseEntity<EmployeeResponseDTO> employeeProfile = this
						.getProfile(endorsementRequest.getEmployeeId());
				String empName = employeeProfile.getBody().getFirstName() + " "
						+ employeeProfile.getBody().getLastName();

				List<Integer> skillIdList = endorsementRequestRepository
						.getAllSkillIdsByEmployeeIdAndManagerIdWithFalseEndorsedStatus(
								endorsementRequest.getEmployeeId(), endorsementRequest.getManagerId());
				List<SkillDTO> skillList = this.getAllSkills(skillIdList);
				endorseSkillDTO.setSkillDTO(employeeProfile.getBody().getEmployeeSkills());
				if (!skillIdList.isEmpty()) {

					List<SkillDataDTO> selectedSKill = new ArrayList<>();
					for (SkillDTO skillDto : skillList) {
						SkillDataDTO dataDto = new SkillDataDTO();
						dataDto.setSkillId(skillDto.getSkillId());
						dataDto.setSkillName(skillDto.getSkillName());
						dataDto.setSkillEndorsementId(
								endorsementRequestRepository.getIdBySkillId(skillDto.getSkillId()).get(0));
						selectedSKill.add(dataDto);
					}
					endorseSkillDTO.setSkillDataDTO(selectedSKill);
					endorseSkillList.add(endorseSkillDTO);
					checklist.add(endorsementRequest.getEmployeeId());
					endorseResponse.setManagerId(id);
					endorseSkillDTO.setEmployeeName(empName);
					endorseSkillDTO.setEmployeeId(endorsementRequest.getEmployeeId());

				} else {
					endorseResponse = new EndorsementResponseDTO();
					endorseResponse.setManagerId(id);

				}
			}

		}
		endorseResponse.setEndorseSkillDTO(endorseSkillList);

		return endorseResponse;
	}

	public List<SkillDTO> getAllSkills(List<Integer> idList) throws URISyntaxException, DataUnavailableException {
		URI url = new URI(skillClusterUrl);
		ResponseEntity<SkillDTO[]> response = rest.postForEntity(url, idList, SkillDTO[].class);

		List<SkillDTO> responseList = new ArrayList<>();
		for (SkillDTO skillDto : response.getBody()) {
			responseList.add(skillDto);
		}

		return responseList;

	}

	@Override
	public ResponseEntity<String> setEndorsedStatus(EndorsedRequestDTO endorsedRequestDTO) {
		// TODO Auto-generated method stub
		for (SkillDataDTO skills : endorsedRequestDTO.getSkills()) {
			if (endorsementRequestRepository.existsBySkillId(skills.getSkillId())) {
				endorsementRequestRepository.setEndorsedStatusToTrue(endorsedRequestDTO.getEmpId(),
						endorsedRequestDTO.getManagerId(), skills.getSkillId());
			} else {
				EndorsementRequest endorsementRequest = new EndorsementRequest();
				endorsementRequest.setEmployeeId(endorsedRequestDTO.getEmpId());
				endorsementRequest.setEndorsedStatus(true);
				endorsementRequest.setEndorseRequestDateTime(LocalDateTime.now().toString());
				endorsementRequest.setManagerId(endorsedRequestDTO.getManagerId());
				endorsementRequest.setSkillId(skills.getSkillId());
				endorsementRequestRepository.save(endorsementRequest);

			}
		}
		return new ResponseEntity<String>(RequestEndorsementKeyWord.RESPONSE, HttpStatus.OK);
	}
}
