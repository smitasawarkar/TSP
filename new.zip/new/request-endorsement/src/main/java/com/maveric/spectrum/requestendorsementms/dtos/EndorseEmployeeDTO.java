package com.maveric.spectrum.requestendorsementms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EndorseEmployeeDTO {
	private Integer employeeId;
	private String employeeName;
	private List<SkillDataDTO> skillDataDTO;
	private List<EmployeeSkillDTO> skillDTO;

}
