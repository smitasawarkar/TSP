//package com.maveric.spectrum.requestendorsementms;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class SpectrumRequestEndorsementMsApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
