package com.maveric.spectrum.employeems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


class ProfileApplicationTests {

	@Test
	void contextLoads() {
	}
	
	

}
