package com.maveric.spectrum.employeems.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.openxml4j.exceptions.NotOfficeXmlFileException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.spectrum.profilems.dtos.UserCertificateResponseDTO;
import com.maveric.spectrum.profilems.dtos.UserEducationResponeDTO;
import com.maveric.spectrum.profilems.dtos.UserProfileResponseDTO;
import com.maveric.spectrum.profilems.dtos.UserProjectExperienceResponseDTO;
import com.maveric.spectrum.profilems.dtos.UserWorkExperienceResponeDTO;
import com.maveric.spectrum.profilems.exceptions.DataUnavailableException;
import com.maveric.spectrum.profilems.exceptions.InvalidFileFormatException;
import com.maveric.spectrum.profilems.services.TechnicalSkillService;
import com.maveric.spectrum.profilems.services.TechnicalSkillServiceImpl;
import com.maveric.spectrum.profilems.services.UserCertificateService;
import com.maveric.spectrum.profilems.services.UserCertificateServiceImpl;
import com.maveric.spectrum.profilems.services.UserEducationService;
import com.maveric.spectrum.profilems.services.UserEducationServiceImpl;
import com.maveric.spectrum.profilems.services.UserProfileService;
import com.maveric.spectrum.profilems.services.UserProfileServiceImpl;
import com.maveric.spectrum.profilems.services.UserProjectExperienceService;
import com.maveric.spectrum.profilems.services.UserProjectExperienceServiceImpl;
import com.maveric.spectrum.profilems.services.UserWorkExperienceService;
import com.maveric.spectrum.profilems.services.UserWorkExperienceServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UserProfileServiceImplUnitTests {
	@Autowired
	private UserProfileService userProfileServiceMock;
	
	@Autowired
	private UserProfileResponseDTO userProfilResponseDTOMock;
	
	@Autowired
	private TechnicalSkillService technicalService;
	
	@Autowired
	private UserCertificateService userCertificateService;
	
	@Autowired
	private UserEducationService userEducationService;
	
	@Autowired
	private UserProjectExperienceService userProjectExperienceService;
 
	@Autowired
	private UserWorkExperienceService userWorkExperienceService;
	
	private RestTemplate restTemplate;
 
	@BeforeEach
	void setUpTestEnv() {
		technicalService = new TechnicalSkillServiceImpl();
		userProfilResponseDTOMock=new UserProfileResponseDTO();
		userCertificateService=new UserCertificateServiceImpl();
		userEducationService=new UserEducationServiceImpl();
		userProjectExperienceService = new UserProjectExperienceServiceImpl();
		userWorkExperienceService = new UserWorkExperienceServiceImpl();
		userProfileServiceMock= new UserProfileServiceImpl(technicalService, userProfilResponseDTOMock, userCertificateService, userProjectExperienceService, userWorkExperienceService, userEducationService,restTemplate);
	}
	
//	@Test
//	@DisplayName("TestCreateUserProfile")
//	void createUserProfileTest() throws IOException {
//
//		ClassPathResource resource = new ClassPathResource("resume");
//		InputStream inputStream = resource.getInputStream();
////
////		String json = "{\n" + "    \"skills\": {\n" + "        \"Programming\": [\n" + "            \"COREJAVA\"\n"
////				+ "        ]\n" + "    },\n" + "    \"certifications\": [\n" + "        {\n"
////				+ "            \"certificationName\": \"AWS associate Solution Architect certificate\",\n"
////				+ "            \"issuingOrganization\": \"AWS\",\n" + "            \"issueDate\": \"June 26,2020\",\n"
////				+ "            \"expirationDate\": \"June 27,2023\",\n"
////				+ "            \"credentialID\": \"674590871A\"\n" + "        },\n" + "        {\n"
////				+ "            \"certificationName\": \"Kubernetes Application Developer Certificate\",\n"
////				+ "            \"issuingOrganization\": \"OrOracle\",\n"
////				+ "            \"issueDate\": \"June 26,2023\",\n"
////				+ "            \"expirationDate\": \"June 27,2025\",\n"
////				+ "            \"credentialID\": \"674590871O\"\n" + "        }\n" + "    ],\n"
////				+ "    \"projectExperiences\": [\n" + "        {\n"
////				+ "            \"projectTitle\": \"Network Cloud and Inventory Exposure\",\n"
////				+ "            \"role\": \"IC\",\n" + "            \"duration\": \"13 months\",\n"
////				+ "            \"description\": \"Cloud networking is type of IT infrastructure in which some or all of an organization’s network capabilities and  resource are hosted in a public or private cloud platform, managed in-house or  by a server provider and available on demand As a part of this network cloud program, Inventory creation and sharing of inventory data for devices supporting Network Cloud will be done in SHRIMS. SRIMS will be single source of inventory management application for all infra structure device and VM and linux container etc for NW Cloud.\",\n"
////				+ "            \"responsibilities\": \"Involved in the Deployment for the different environment Resolving the technical issues when team facing technical issues\"\n"
////				+ "        }\n" + "    ],\n" + "    \"qualifications\": [\n" + "        {\n"
////				+ "            \"qualificationTitle\": \"HSC\",\n"
////				+ "            \"instituteName\": \"Modern education Society’s College Of Engineering\",\n"
////				+ "            \"place\": \"Pune\",\n" + "            \"durationFrom\": \"2016\",\n"
////				+ "            \"durationTo\": \"2020\",\n" + "            \"score\": \"8.64\"\n" + "        }\n"
////				+ "    ]\n" + "}";
////
//		MultipartFile multipartFile = new MockMultipartFile("resume", inputStream);
//	
//
//	    // Create response entity with status 201 Created and headers
//	    ResponseEntity<String> expected = new ResponseEntity<>("okay", HttpStatus.CREATED);
////		when(userProfileServiceMock.createUserProfile(multipartFile)).thenReturn(expected);
//		ResponseEntity<String> resumeParserResponse = userProfileServiceMock.createUserProfile(multipartFile);
//		
//	
//		assertEquals(expected,resumeParserResponse);
//	}
	
	
	@Test
	@DisplayName("TestParseResume")
	void parseResumeTest() throws IOException {
		ClassPathResource resource = new ClassPathResource("resume");
		InputStream inputStream = resource.getInputStream();
		XWPFDocument document = null;
		document = new XWPFDocument(inputStream);
		
		String data = "ASHLESHA GHUTE, Summary, A seasoned IT professional with 13+ years of experience in Java/J2ee (Technical) Architecture, Application Support & Maintenance, Frontend – Angular, Design & Development, Technical Design, Cross-functional Coordination, Team Building & Leadership. , Worked as Application Admin on Unix for 2+ years., Expertise in developing Web Application Services using Technologies like Core Java, JDBC, Servlets, Hibernate, Spring core, Spring MVC, Spring Boot Micro services, Spring web flux, Spring Cloud, SOAP/ Restful web services, Maven., 2 years of experience as Architect, 4 years of experience as Technical Lead, A strong knowledge in J2EE, UML and OOAD concepts. , Design and Architecture of scalable &high-performance software products using modeling techniques and software design patterns., Provide technical and architectural leadership to the customers recommends architectural approaches supporting solutions, creates/reviews enterprise/systems architecture documents., Strong knowledge of structured analysis, design and programming techniques and development methodologies and have ability to identify, define and develop right standards, process, and IT governance., Expertise in developing Web Application UI using Technologies JSP, JSF, Angular 7.0, Working experience on database connections with Oracle, MySQL and Couchbase (NoSQL)respectively., Experience in using Git for source control system and Jenkins used for continuous integration., Working Knowledge on Docker, Kubernetes, OpenShift and Spring Cloud, Worked Knowledge on Kafka and Rabbit MQ, Worked in Agile methodology and have experience using Jira and Rally, Having hands on experience in handling Use Cases, Functional Specification, Knowledge Transfers and Business Analysis., Good working knowledge on Application development and maintenance projects., Proficient in Analyses and design documents., Technical Skills:, Programming : COREJAVA , Process : Agile, SDLC, Paradigms : OOPS, UML and MVC, Frameworks : Spring Boot, Cloud, MVC, Data, Security, Web Flux, Hibernate, JPA JAX-RS Restful (Jersey), Cloud : OpenShift, Spring Cloud, Eureka, Ribbon, Netflix Hystrix, Zulu, Container : Docker and Kubernetes, Messaging Queue : Kafka, RabbitMQ, Web Frameworks : Spring, Hibernate, Jsf2.0 and Angular7.0, Test and Junit : JUNIT4.0, MOCKITO. , DataBase : ORACLE, MYSQL and NOSQL (Couch Base), Others : PMD, Find bugs, Log4j, Sonar, ELK, Build : MAVEN, GRADLE, IDE : ECLIPSE, STS and INTELLI, Certification:, Project Experience:, Project# 1, Network Cloud and Inventory Exposure, Role: IC, Duration: Mar 2023 - Jun 2023, Description: , Cloud networking is type of IT infrastructure in which some or all of an organization’s network capabilities and resource are hosted in a public or private cloud platform, managed in-house or by a server provider and available on demand As a part of this network cloud program, Inventory creation and sharing of inventory data for devices supporting Network Cloud will be done in SHRIMS. SRIMS will be single source of inventory management application for all infra structure device and VM and linux container etc for NW Cloud., Responsibilities:, Involved in the Deployment for the different environment. , Resolving the technical issues when team facing technical issues  , Envisioned Solution Architecture and Design for modernization efforts, Technical Design reviews and Code Reviews, Adopted DevOps practices including CI/CD, Test Automation, Deployment automation, etc.,, Implemented JWT for securing REST endpoints., Identified Key Performance Metrics and developed Performance Testing framework using JMeter., Implemented Application Monitoring Dashboards using Prometheus and Grafana, Requirement Analysis and preparing design document., Involved in Developing Producer and consumer APIs using Springboot Microservice with KAFKA, Involved in Created topics in different Environments and tested all the flows., Involved in writing Junits using Mockito., , , Project# 2: , NEMO - Disputes, Role: Technical Lead and IC, Duration: Mar 2023 - Jun 2023, Description: , Nemo is centralized payment system for authorizing, issuing, clearing and settlement processing of AMEX payments transactions Working for Amex credit card Disputes. Where transforming and enhancing the existing applications to microservices. Using technologies, Spring Boot, Couchbase, Springwebflux, Docker and Kubernetes, Key performance metrics dashboard creation using Prometheus and Grafana. , Responsibilities:, Envisioned Solution Architecture and Design for modernization efforts, Technical Design reviews and Code Reviews, Adopted DevOps practices including CI/CD, Test Automation, Deployment automation, etc.,, Implemented JWT for securing REST endpoints., Identified Key Performance Metrics and developed Performance Testing framework using JMeter., Implemented Application Monitoring Dashboards using Prometheus and Grafana, Responsible for designing Microservices for critical Business services and guide the implementation., Involved in research of enterprise-wide Caching solutions and integrated Elastic Search solutions., Involving in the Deployment for the different environment , Resolving the technical issues when team facing technical issues  , Fixing all the bugs that may arise in QA/UAT and working on enhancements., Work Experience:, Company Name: Maveric Systems Limited, Job Title: SDE1-Think Nxt, Start Date: Aug 2023, End Date: present, Location: Chennai, Tamil Nadu, India, Company Name: Tata Consultancy Services, Job Title: System Engineer, Start Date: Jan 2021, End Date: Nov 2022, Location: Pune, Maharashtra, India, Qualifications:, Qualification Title: Master of Business Administration - MBA, Institute Name: Modern education Society’s College of Engineering, Place: Pune, Duration From: 2016, Duration To: 2020, Score: 8.64";
 
        String[] lines = data.split(",");
 
        List<String> textList = new ArrayList<String>();
 
        for (String line : lines) {
            textList.add(line.trim());
        }
        UserProfileResponseDTO userProfile = new UserProfileResponseDTO();
 
     // Skills
     List<String> skills = Arrays.asList(
         "JUNIT4.0", "PMD", "COREJAVA",
         "Agile", "Spring", "ECLIPSE",
         "Kafka", "ORACLE", "Docker",
         "Kubernetes", "MAVEN", "Spring Boot", "OpenShift", "OOPS"
     );
     userProfile.setSkills(skills);
 
     // Certificates
     List<UserCertificateResponseDTO> certificates = List.of(
         new UserCertificateResponseDTO(
             "AWS associate Solution Architect certificate",
             "AWS",
             "June 26,2020",
             "June 27,2023",
             "674590871A"
         ),
         new UserCertificateResponseDTO(
             "Kubernetes Application Developer Certificate",
             "Oracle",
             "June 26,2023",
             "June 27,2025",
             "674590871O"
         )
     );
     userProfile.setUserCertificates(certificates);
 
     // Project Experiences
     List<UserProjectExperienceResponseDTO> projectExperiences = Arrays.asList(
         new UserProjectExperienceResponseDTO(
             "Network Cloud and Inventory Exposure",
             "IC",
             "Cloud networking is type of IT infrastructure in which some or all of an organization’s network capabilities and resource are hosted in a public or private cloud platform managed in-house or by a server provider and available on demand As a part of this network cloud program Inventory creation and sharing of inventory data for devices supporting Network Cloud will be done in SHRIMS. SRIMS will be single source of inventory management application for all infra structure device and VM and linux container etc for NW Cloud. ",
             "Involved in the Deployment for the different environment. Resolving the technical issues when team facing technical issues Envisioned Solution Architecture and Design for modernization efforts Technical Design reviews and Code Reviews Adopted DevOps practices including CI/CD Test Automation Deployment automation etc. Implemented JWT for securing REST endpoints. Identified Key Performance Metrics and developed Performance Testing framework using JMeter. Implemented Application Monitoring Dashboards using Prometheus and Grafana Requirement Analysis and preparing design document. Involved in Developing Producer and consumer APIs using Springboot Microservice with KAFKA Involved in Created topics in different Environments and tested all the flows. Involved in writing Junits using Mockito. ",
             "Mar 2023",
             "Jun 2023"
         ),
         new UserProjectExperienceResponseDTO(
             "NEMO - Disputes",
             "Technical Lead and IC",
             "Nemo is centralized payment system for authorizing issuing clearing and settlement processing of AMEX payments transactions Working for Amex credit card Disputes. Where transforming and enhancing the existing applications to microservices. Using technologies Spring Boot Couchbase Springwebflux Docker and Kubernetes Key performance metrics dashboard creation using Prometheus and Grafana.",
             "Envisioned Solution Architecture and Design for modernization efforts Technical Design reviews and Code Reviews Adopted DevOps practices including CI/CD Test Automation Deployment automation etc. Implemented JWT for securing REST endpoints. Identified Key Performance Metrics and developed Performance Testing framework using JMeter. Implemented Application Monitoring Dashboards using Prometheus and Grafana Responsible for designing Microservices for critical Business services and guide the implementation. Involved in research of enterprise-wide Caching solutions and integrated Elastic Search solutions. Involving in the Deployment for the different environment Resolving the technical issues when team facing technical issues Fixing all the bugs that may arise in QA/UAT and working on enhancements.",
             "Mar 2023",
             "Jun 2023"
         )
     );
     userProfile.setUserProjectExperiences(projectExperiences);
 
     // Work Experiences
     List<UserWorkExperienceResponeDTO> workExperiences = Arrays.asList(
         new UserWorkExperienceResponeDTO(
             "SDE1-Think Nxt",
             "Maveric Systems Limited",
             "Chennai",
             "Aug 2023",
             "present"
         ),
         new UserWorkExperienceResponeDTO(
             "System Engineer",
             "Tata Consultancy Services",
             "Pune",
             "Jan 2021",
             "Nov 2022"
         )
     );
     userProfile.setUserWorkExperiences(workExperiences);
 
     // Education
     List<UserEducationResponeDTO> education = Arrays.asList(
         new UserEducationResponeDTO(
             "Master of Business Administration - MBA",
             "Modern education Society’s College of Engineering",
             "2016",
             "2020",
             8.64
         )
     );
     userProfile.setUserEducation(education);
     
     UserProfileResponseDTO expected=userProfile;
     UserProfileServiceImpl userp=new UserProfileServiceImpl(technicalService, userProfilResponseDTOMock, userCertificateService, userProjectExperienceService, userWorkExperienceService, userEducationService,restTemplate);
     UserProfileResponseDTO actual=userp.parseResume(textList, document);
     
     assertEquals(expected.getUserEducation().get(0).getEducationTitle(), actual.getUserEducation().get(0).getEducationTitle());
//		assertEquals(expected.get(0).getEndDuration(), actual.get(0).getEndDuration());
//		assertEquals(expected.get(0).getInstituteName(), actual.get(0).getInstituteName());
//		assertEquals(expected.get(0).getScore(), actual.get(0).getScore());
//		assertEquals(expected.get(0).getStartDuration(), actual.get(0).getStartDuration());
     
 
        
        
        
        
		
	}
 
//	@Test
//	@DisplayName("TestForInvalidFileFormat")
//	void test1() throws IOException, DataUnavailableException, InvalidFileFormatException {
//		try {
//			ClassPathResource resource = new ClassPathResource("test.doc");
//			InputStream inputStream = resource.getInputStream();
//			MultipartFile multipartFile = new MockMultipartFile("test.doc","test.doc",null, inputStream);
//			multipartFile.getOriginalFilename();
//			userProfileServiceMock.createUserProfile(multipartFile);
// 
//		} catch (NotOfficeXmlFileException e) {
//			String errorMessage = e.getMessage();
//			assertEquals("Invalid File Format Exception", errorMessage);
//		}
// 
//	}
	
//	@Test
//	@DisplayName("TestForNoSectionAvailable")
//	void test2() throws IOException {
//		try {
//			ClassPathResource resource = new ClassPathResource("empty.docx");
//			InputStream inputStream = resource.getInputStream();
//			MultipartFile multipartFile = new MockMultipartFile("empty.docx", inputStream);
//			userProfileServiceMock.createUserProfile(multipartFile);
//
//		} catch (Exception e) {
//			String errorMessage = e.getMessage();
//			assertEquals("No Content is Available", errorMessage);
//		}
//
//	}
	
	
	@Test
	@DisplayName("getTechnicalSkillsTest")
	void getTechnicalSkillsTest() {
		List<String> skillListBefore = new ArrayList<String>();
		String technicalSkillsRaw = "Technical Skills:, Programming		:        COREJAVA , Process     		:        Agile, SDLC, Paradigms		:        OOPS, UML and MVC, Frameworks		:         Spring Boot, Cloud, MVC, Data, Security, Web Flux, Hibernate,                                		                       JPA JAX-RS Restful   (Jersey), Cloud           		:         OpenShift, Spring Cloud, Eureka, Ribbon, Netflix Hystrix, Zulu, Container   		:         Docker and Kubernetes, Messaging Queue	:         Kafka, RabbitMQ, Web Frameworks  	:         Spring, Hibernate, Jsf2.0 and Angular7.0, Test and Junit        	:         JUNIT4.0, MOCKITO. , DataBase                	:         ORACLE, MYSQL and NOSQL (Couch Base), Others                    	:         PMD, Find bugs, Log4j, Sonar, ELK, Build                     	:         MAVEN, GRADLE, IDE                      	:         ECLIPSE, STS and INTELLI";
		String[] skillArray = technicalSkillsRaw.split(",");
		for (String s : skillArray) {
			skillListBefore.add(s);
		}
		List<String> skillListAfter = new ArrayList<String>();
		String expectedSkillRaw = "JUNIT4.0,PMD,COREJAVA,Agile,Spring,ECLIPSE,Kafka,ORACLE,Docker,Kubernetes,MAVEN,Spring Boot,OpenShift,OOPS";
		String[] skillArrayExpected = expectedSkillRaw.split(",");
		for (String s : skillArrayExpected) {
			skillListAfter.add(s);
		}
		List<String> expected = skillListAfter;
		List<String> actual = technicalService.getTechnicalSkills(skillListBefore);
		assertEquals(expected, actual);
	}
 
	@Test
	@DisplayName("getCertificationsTest")
	void getCertificationsTest() throws IOException {
		ClassPathResource resource = new ClassPathResource("resume");
		InputStream inputStream = resource.getInputStream();
		MultipartFile file = new MockMultipartFile("resume", inputStream);
		InputStream fis = file.getInputStream();
 
		String originalFilename = file.getOriginalFilename();
		String fileExtension = FilenameUtils.getExtension(originalFilename);
		XWPFDocument document = new XWPFDocument(fis);
 
		List<UserCertificateResponseDTO> certificates = new ArrayList<>();
 
		UserCertificateResponseDTO certificate1 = new UserCertificateResponseDTO(
				"AWS associate Solution Architect certificate", "AWS", "June 26,2020", "June 27,2023", "674590871A");
		certificates.add(certificate1);
 
		UserCertificateResponseDTO certificate2 = new UserCertificateResponseDTO(
				"Kubernetes Application Developer Certificate", "Oracle", "June 26,2023", "June 27,2025","674590871O");
		certificates.add(certificate2);
		
		List<UserCertificateResponseDTO> expected=certificates;
		List<UserCertificateResponseDTO> actual=userCertificateService.getUserCertifications(document);
		assertEquals(expected.get(0).getCertificationName(), actual.get(0).getCertificationName());
		assertEquals(expected.get(0).getCredentialId(), actual.get(0).getCredentialId());
		assertEquals(expected.get(0).getExpirationDate(), actual.get(0).getExpirationDate());
		assertEquals(expected.get(0).getIssuingDate(), actual.get(0).getIssuingDate());
		assertEquals(expected.get(0).getIssuingOrganization(), actual.get(0).getIssuingOrganization());
 
		assertEquals(expected.get(1).getCertificationName(), actual.get(1).getCertificationName());
		assertEquals(expected.get(1).getCredentialId(), actual.get(1).getCredentialId());
		assertEquals(expected.get(1).getExpirationDate(), actual.get(1).getExpirationDate());
		assertEquals(expected.get(1).getIssuingDate(), actual.get(1).getIssuingDate());
		assertEquals(expected.get(1).getIssuingOrganization(), actual.get(1).getIssuingOrganization());
 
	}
	
	@Test
	@DisplayName("getEducationDetailsTest")
	void getEducationTest() {
		List<String> educationList=new ArrayList<String>();
		String education="Qualifications:, Qualification Title: Master of Business Administration - MBA, Institute Name: Modern education Society’s College of Engineering, Place: Pune, Duration From: 2016, Duration To: 2020, Score: 8.64";
		String[] educationArray=education.split(",");
		for(String s: educationArray) {
			educationList.add(s);
		}
		
		List<UserEducationResponeDTO> expected=new ArrayList<>();
		UserEducationResponeDTO education1=new UserEducationResponeDTO();
		education1.setEducationTitle("Master of Business Administration - MBA");
		education1.setEndDuration("2020");
		education1.setInstituteName("Modern education Society’s College of Engineering");
		education1.setScore(8.64);
		education1.setStartDuration("2016");
		expected.add(education1);
		
		List<UserEducationResponeDTO> actual=userEducationService.getUserEducationExperience(educationList);
		assertEquals(expected.get(0).getEducationTitle(), actual.get(0).getEducationTitle());
		assertEquals(expected.get(0).getEndDuration(), actual.get(0).getEndDuration());
		assertEquals(expected.get(0).getInstituteName(), actual.get(0).getInstituteName());
		assertEquals(expected.get(0).getScore(), actual.get(0).getScore());
		assertEquals(expected.get(0).getStartDuration(), actual.get(0).getStartDuration());
		
		
	}
	
	
	@Test
	@DisplayName("getProjectExperienceTest")
	void getProjectExperienceTest() {
		List<String> projectList=new ArrayList<String>();
		String project="Project Experience:, Project# 1, Network Cloud and Inventory Exposure, Role: IC, Duration: Mar 2023 - Jun 2023, Description: , Cloud networking is type of IT infrastructure in which some or all of an organization’s network capabilities and resource are hosted in a public or private cloud platform, managed in-house or by a server provider and available on demand As a part of this network cloud program, Inventory creation and sharing of inventory data for devices supporting Network Cloud will be done in SHRIMS. SRIMS will be single source of inventory management application for all infra structure device and VM and linux container etc for NW Cloud., Responsibilities:, Involved in the Deployment for the different environment. , Resolving the technical issues when team facing technical issues  , Envisioned Solution Architecture and Design for modernization efforts, Technical Design reviews and Code Reviews, Adopted DevOps practices including CI/CD, Test Automation, Deployment automation, etc.,, Implemented JWT for securing REST endpoints., Identified Key Performance Metrics and developed Performance Testing framework using JMeter., Implemented Application Monitoring Dashboards using Prometheus and Grafana, Requirement Analysis and preparing design document., Involved in Developing Producer and consumer APIs using Springboot Microservice with KAFKA, Involved in Created topics in different Environments and tested all the flows., Involved in writing Junits using Mockito., 	, 				, Project# 2: , NEMO - Disputes, Role: Technical Lead and IC, Duration: Mar 2023 - Jun 2023, Description: , Nemo is centralized payment system for authorizing, issuing, clearing and settlement processing of AMEX payments transactions Working for Amex credit card Disputes. Where transforming and enhancing the existing applications to microservices. Using technologies, Spring Boot, Couchbase, Springwebflux, Docker and Kubernetes, Key performance metrics dashboard creation using Prometheus and Grafana. , Responsibilities:, Envisioned Solution Architecture and Design for modernization efforts, Technical Design reviews and Code Reviews, Adopted DevOps practices including CI/CD, Test Automation, Deployment automation, etc.,, Implemented JWT for securing REST endpoints., Identified Key Performance Metrics and developed Performance Testing framework using JMeter., Implemented Application Monitoring Dashboards using Prometheus and Grafana, Responsible for designing Microservices for critical Business services and guide the implementation., Involved in research of enterprise-wide Caching solutions and integrated Elastic Search solutions., Involving in the Deployment for the different environment , Resolving the technical issues when team facing technical issues  ,  Fixing all the bugs that may arise in QA/UAT and working on enhancements.";
		String[] projects=project.split(",");
		for(String s: projects) {
			projectList.add(s);
		}
		
		List<UserProjectExperienceResponseDTO> expected= new ArrayList<>();
		UserProjectExperienceResponseDTO projectExp=new UserProjectExperienceResponseDTO();
		projectExp.setDescription("Cloud networking is type of IT infrastructure in which some or all of an organization’s network capabilities and resource are hosted in a public or private cloud platform managed in-house or by a server provider and available on demand As a part of this network cloud program Inventory creation and sharing of inventory data for devices supporting Network Cloud will be done in SHRIMS. SRIMS will be single source of inventory management application for all infra structure device and VM and linux container etc for NW Cloud. ");
		projectExp.setEndDuration("Jun 2023");
		projectExp.setResponsibilities("Involved in the Deployment for the different environment. Resolving the technical issues when team facing technical issues Envisioned Solution Architecture and Design for modernization efforts Technical Design reviews and Code Reviews Adopted DevOps practices including CI/CD Test Automation Deployment automation etc. Implemented JWT for securing REST endpoints. Identified Key Performance Metrics and developed Performance Testing framework using JMeter. Implemented Application Monitoring Dashboards using Prometheus and Grafana Requirement Analysis and preparing design document. Involved in Developing Producer and consumer APIs using Springboot Microservice with KAFKA Involved in Created topics in different Environments and tested all the flows. Involved in writing Junits using Mockito. ");
		projectExp.setRole("IC");
		projectExp.setStartDuration("Mar 2023");
		projectExp.setTitle("Network Cloud and Inventory Exposure");
		
		expected.add(projectExp);
		
		List<UserProjectExperienceResponseDTO> actual=userProjectExperienceService.getUserProjectExperience(projectList);
		assertEquals(expected.get(0).getDescription(), actual.get(0).getDescription());
		assertEquals(expected.get(0).getEndDuration(), actual.get(0).getEndDuration());
		assertEquals(expected.get(0).getResponsibilities(), actual.get(0).getResponsibilities());
		assertEquals(expected.get(0).getRole(), actual.get(0).getRole());
		assertEquals(expected.get(0).getStartDuration(), actual.get(0).getStartDuration());
		assertEquals(expected.get(0).getTitle(), actual.get(0).getTitle());
 
		
	}
	
	@Test
	@DisplayName("getWorkExperienceTest")
	void getWorkExperiencetest() {
		List<String> workList=new ArrayList<String>();
		String workString="Work Experience:, Company Name: Maveric Systems Limited, Job Title: SDE1-Think Nxt, Start Date: Aug 2023, End Date: present, Location: Chennai, Tamil Nadu, India, Company Name: Tata Consultancy Services, Job Title: System Engineer, Start Date: Jan 2021, End Date: Nov 2022, Location: Pune, Maharashtra, India";
		String[] works=workString.split(",");
		for(String s: works) {
			workList.add(s);
		}
		
		List<UserWorkExperienceResponeDTO> expected=new ArrayList<>();
		
		UserWorkExperienceResponeDTO userwork=new UserWorkExperienceResponeDTO();
		userwork.setCompanyName("Maveric Systems Limited");
		userwork.setEndDate("present");
		userwork.setJobTitle("SDE1-Think Nxt");
		userwork.setLocation("Chennai");
		userwork.setStartDate("Aug 2023");
		expected.add(userwork);
		
		List<UserWorkExperienceResponeDTO> actual= userWorkExperienceService.getUserWorkExperience(workList);
		assertEquals(expected.get(0).getCompanyName(), actual.get(0).getCompanyName());
		assertEquals(expected.get(0).getEndDate(), actual.get(0).getEndDate());
		assertEquals(expected.get(0).getJobTitle(), actual.get(0).getJobTitle());
		assertEquals(expected.get(0).getLocation(), actual.get(0).getLocation());
		assertEquals(expected.get(0).getStartDate(), actual.get(0).getStartDate());
 
	}
}
