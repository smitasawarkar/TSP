package com.maveric.spectrum.profilems.services;

import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.maveric.spectrum.profilems.dtos.UserCertificateResponseDTO;

public interface UserCertificateService {
	public List<UserCertificateResponseDTO> getUserCertifications( XWPFDocument document);
}
