package com.maveric.spectrum.profilems.dtos;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class UserCertificateResponseDTO {

	private String certificationName;
	private String issuingOrganization;
	private String issuingDate;
	private String expirationDate;
	private String credentialId;
}
