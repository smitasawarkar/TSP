package com.maveric.spectrum.profilems.dtos;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class UserProjectExperienceResponseDTO {
	private String title;
	private String role;
	private String description;
	private String responsibilities;
	private String startDuration;
	private String endDuration;
}
