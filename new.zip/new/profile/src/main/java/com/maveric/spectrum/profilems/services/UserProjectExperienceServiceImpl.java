package com.maveric.spectrum.profilems.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.maveric.spectrum.profilems.dtos.UserProjectExperienceResponseDTO;
import com.maveric.spectrum.profilems.utils.ResumeKeyword;

@Service
public class UserProjectExperienceServiceImpl implements UserProjectExperienceService {

	@Override
	public List<UserProjectExperienceResponseDTO> getUserProjectExperience(List<String> projectExperienceSection) {

		List<String> cleanedProjectExperienceSection = projectExperienceSection.stream()
				.filter(s -> !s.trim().isEmpty()).map(String::trim).toList();

		List<UserProjectExperienceResponseDTO> projectExperiences = new ArrayList<>();
		UserProjectExperienceResponseDTO currentProject = null;
		StringBuilder responsibilitiesBuilder = new StringBuilder();
		StringBuilder descriptionBuilder = new StringBuilder();
		boolean isNextLineTitle = false;
		boolean isDescription = false;

		for (String line : cleanedProjectExperienceSection) {
			if (line.startsWith(ResumeKeyword.PROJECT_EXPERIENCE_KEY[0])) {
				if (currentProject != null) {
					currentProject.setResponsibilities(responsibilitiesBuilder.toString());
					currentProject.setDescription(descriptionBuilder.toString());
					projectExperiences.add(currentProject);
				}
				currentProject = new UserProjectExperienceResponseDTO();
				responsibilitiesBuilder = new StringBuilder();
				descriptionBuilder = new StringBuilder();
				isNextLineTitle = true;
			} else if (line.startsWith(ResumeKeyword.PROJECT_EXPERIENCE_KEY[1]) && currentProject != null) {
				currentProject.setRole(line.substring(6).trim());
			} else if (line.startsWith(ResumeKeyword.PROJECT_EXPERIENCE_KEY[2]) && currentProject != null) {
				 setCurrentProjectDuration(line, currentProject);
			} else if (line.startsWith(ResumeKeyword.PROJECT_EXPERIENCE_KEY[3]) && currentProject != null) {
				isDescription = true;
				descriptionBuilder.append(line.substring(12).trim()).append("");
			} else if (line.startsWith(ResumeKeyword.PROJECT_EXPERIENCE_KEY[4]) && currentProject != null) {
				isDescription = false;
			} else if (isNextLineTitle) {
				currentProject.setTitle(line.trim());
				isNextLineTitle = false;
			} else if (currentProject != null) {
				if (isDescription) {
					descriptionBuilder.append(line.trim()).append(" ");
				} else {
					responsibilitiesBuilder.append(line.trim()).append(" ");
				}
			}
		}

		if (currentProject != null) {
			currentProject.setResponsibilities(responsibilitiesBuilder.toString().trim());
			currentProject.setDescription(descriptionBuilder.toString().trim());
			projectExperiences.add(currentProject);
		}

		return projectExperiences;
	}
	
	 private void setCurrentProjectDuration(String line, UserProjectExperienceResponseDTO currentProject) {
	        String[] durations = line.substring(10).trim().split("-", 2);
	        currentProject.setStartDuration(durations[0].trim());
	        currentProject.setEndDuration(durations[1].trim());
	    }
}
