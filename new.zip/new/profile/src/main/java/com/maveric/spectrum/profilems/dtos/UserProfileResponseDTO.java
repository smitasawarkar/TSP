package com.maveric.spectrum.profilems.dtos;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Component
public class UserProfileResponseDTO {
	
		private List<String> skills;
		private List<UserCertificateResponseDTO> userCertificates;
		private List<UserProjectExperienceResponseDTO> userProjectExperiences;
		private List<UserWorkExperienceResponeDTO> userWorkExperiences;
		private List<UserEducationResponeDTO> userEducation;
}
