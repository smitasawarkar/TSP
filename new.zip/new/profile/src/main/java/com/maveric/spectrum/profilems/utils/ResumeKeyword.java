package com.maveric.spectrum.profilems.utils;

public class ResumeKeyword {
	
	//prevent instantiation
	private ResumeKeyword(){}
	
	public static final String TECHNICAL_SKILL = "Technical Skills";
	public static final String CERTIFICATION = "Certification";
	public static final String PROJECT_EXPERIENCE = "Project Experience";
	public static final String QUALIFICATION = "Qualifications";
	public static final String WORKEXPERIENCE="Work Experience";
	public static final String[] PROJECT_EXPERIENCE_KEY = { "Project#", "Role", "Duration", "Description", "Responsibilities" };
	public static final String[] QUALIFICATION_KEYS = { "Qualification Title", "Institute Name","Duration From", "Duration To", "Score" };
}
