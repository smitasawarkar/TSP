package com.maveric.spectrum.profilems.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.profilems.dtos.UserCertificateResponseDTO;

@Service
public class UserCertificateServiceImpl implements UserCertificateService{

	@Override
	public List<UserCertificateResponseDTO> getUserCertifications(XWPFDocument document) {
		List<UserCertificateResponseDTO> certifications = new ArrayList<>();

		for (XWPFTable table : document.getTables()) {
			for (int i = 1; i < table.getRows().size(); i++) {
				XWPFTableRow row = table.getRows().get(i);
				UserCertificateResponseDTO certification = new UserCertificateResponseDTO();
				List<XWPFTableCell> cells = row.getTableCells();
				if (cells.size() >= 5) {
					certification.setCertificationName(cells.get(0).getText().trim());
					certification.setIssuingOrganization(cells.get(1).getText().trim());
					certification.setIssuingDate(null);
					certification.setIssuingDate(cells.get(2).getText().trim());
					certification.setExpirationDate(cells.get(3).getText().trim());
					certification.setCredentialId(cells.get(4).getText().trim());
					certifications.add(certification);
				}
			}
		}
		return certifications;
	}

}
