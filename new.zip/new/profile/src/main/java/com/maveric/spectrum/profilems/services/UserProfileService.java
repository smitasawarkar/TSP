package com.maveric.spectrum.profilems.services;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.spectrum.profilems.dtos.UserProfileResponseDTO;
import com.maveric.spectrum.profilems.exceptions.DataUnavailableException;
import com.maveric.spectrum.profilems.exceptions.InvalidFileFormatException;

public interface UserProfileService {
	
	public ResponseEntity<String> createUserProfile(MultipartFile file) throws IOException,DataUnavailableException,InvalidFileFormatException;
}
