package com.maveric.spectrum.profilems.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.spectrum.profilems.dtos.UserProfileResponseDTO;
import com.maveric.spectrum.profilems.exceptions.DataUnavailableException;
import com.maveric.spectrum.profilems.exceptions.InvalidFileFormatException;
import com.maveric.spectrum.profilems.utils.ResumeKeyword;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserProfileServiceImpl implements UserProfileService {

	private TechnicalSkillService technicalSkillService;
	private UserProfileResponseDTO userProfileResponseDTO;
	private UserCertificateService userCertificateService;
	private UserProjectExperienceService userProjectExperienceService;
	private UserWorkExperienceService userWorkExperienceService;
	private UserEducationService userEducationService;
	private RestTemplate restTemplate;

	@Value("${employee.url}")
	private String url;
	
	@Value("${resume.type}")
	private String resumeType;

	public UserProfileServiceImpl(TechnicalSkillService technicalSkillService,
			UserProfileResponseDTO userProfileResponseDTO, UserCertificateService userCertificateService,
			UserProjectExperienceService userProjectExperienceService,
			UserWorkExperienceService userWorkExperienceService, UserEducationService userEducationService,RestTemplate restTemplate) {
		super();
		this.technicalSkillService = technicalSkillService;
		this.userProfileResponseDTO = userProfileResponseDTO;
		this.userCertificateService = userCertificateService;
		this.userProjectExperienceService = userProjectExperienceService;
		this.userWorkExperienceService = userWorkExperienceService;
		this.userEducationService = userEducationService;
		this.restTemplate=restTemplate;
	}

	@Override
	public ResponseEntity<String> createUserProfile(MultipartFile file) throws IOException, DataUnavailableException, InvalidFileFormatException {

		XWPFDocument document = null;
		try {
			InputStream fis = file.getInputStream();

			String originalFilename = file.getOriginalFilename();
			String fileExtension = FilenameUtils.getExtension(originalFilename);

			if (!resumeType.equals(fileExtension)) 
				throw new InvalidFileFormatException("Invalid File Format Exception");
						
			document = new XWPFDocument(fis);
			List<String> textList=getSectionListFromDocument( document);

			if (textList.isEmpty()) 
				throw new DataUnavailableException("Content is not Available");
					
			parseResume(textList, document);
			return restTemplate.postForEntity(url, userProfileResponseDTO, String.class);
		}
		finally {
			if(document!=null)
				document.close();
		}
		
	}

	public List<String> getSectionListFromDocument( XWPFDocument document) {
		List<String> textList=new ArrayList<>();
		List<XWPFParagraph> paragraphs = null;
		paragraphs = document.getParagraphs();

		for (XWPFParagraph para : paragraphs) {
			String text = para.getText();
			if (text != null && !text.isEmpty()) {
				textList.add(text);
			}
		}
		return textList;
	}

	public UserProfileResponseDTO parseResume(List<String> textList, XWPFDocument document) {

		int startIndexOfTechnicalSkill = findIndex(textList, ResumeKeyword.TECHNICAL_SKILL);
		int startIndexOfCertification = findIndex(textList, ResumeKeyword.CERTIFICATION);
		int startIndexOfProjectExperience = findIndex(textList, ResumeKeyword.PROJECT_EXPERIENCE);
		int startIndexOfWorkExperience = findIndex(textList, ResumeKeyword.WORKEXPERIENCE);
		int startIndexOfQualification = findIndex(textList, ResumeKeyword.QUALIFICATION);

		if (startIndexOfTechnicalSkill != -1) {
			List<String> technicalSkillsSection = textList.subList(startIndexOfTechnicalSkill,
					startIndexOfCertification);
			userProfileResponseDTO.setSkills(technicalSkillService.getTechnicalSkills(technicalSkillsSection));
		}

		if (startIndexOfCertification != -1) {
			userProfileResponseDTO.setUserCertificates(userCertificateService.getUserCertifications(document));
		}

		if (startIndexOfProjectExperience != -1) {
			List<String> projectExperienceSection = textList.subList(startIndexOfProjectExperience,
					startIndexOfWorkExperience);
			userProfileResponseDTO.setUserProjectExperiences(
					userProjectExperienceService.getUserProjectExperience(projectExperienceSection));
		}

		if (startIndexOfWorkExperience != -1) {
			List<String> workExperienceSection = textList.subList(startIndexOfWorkExperience,
					startIndexOfQualification);
			userProfileResponseDTO
					.setUserWorkExperiences(userWorkExperienceService.getUserWorkExperience(workExperienceSection));
		}

		if (startIndexOfQualification != -1) {
			List<String> educationSection = textList.subList(startIndexOfQualification, textList.size());
			userProfileResponseDTO.setUserEducation(userEducationService.getUserEducationExperience(educationSection));
		}
		
		log.info("User profile response:"+userProfileResponseDTO);
		return userProfileResponseDTO;

	}

	public int findIndex(List<String> textList, String keyword) {
		for (int i = 0; i < textList.size(); i++) {
			String element = textList.get(i);
			if (element.startsWith(keyword))
				return i;
		}
		return -1;
	}

}
