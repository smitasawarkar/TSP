package com.maveric.spectrum.profilems.services;

import java.util.List;

import com.maveric.spectrum.profilems.dtos.UserProjectExperienceResponseDTO;

public interface UserProjectExperienceService {
	public List<UserProjectExperienceResponseDTO> getUserProjectExperience(List<String> projectExperienceSection);
}
