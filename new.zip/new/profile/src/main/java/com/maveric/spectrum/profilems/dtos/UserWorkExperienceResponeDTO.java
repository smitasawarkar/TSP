package com.maveric.spectrum.profilems.dtos;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class UserWorkExperienceResponeDTO {
	private String jobTitle;
	private String companyName;
	private String location;
	private String startDate;
	private String endDate;

}
