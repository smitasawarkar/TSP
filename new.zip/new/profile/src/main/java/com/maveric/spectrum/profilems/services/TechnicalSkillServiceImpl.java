package com.maveric.spectrum.profilems.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.springframework.stereotype.Service;

@Service
public class TechnicalSkillServiceImpl implements TechnicalSkillService{

	@Override
	public List<String> getTechnicalSkills(List<String> technicalSkillsSection) {
		
		List<String> cleanedTechnicalSkillsSection = technicalSkillsSection.stream().filter(s -> !s.trim().isEmpty())
				.map(String::trim).toList();

		Map<String, String[]> technicalSkillsMap = new HashMap<>();
		List<String> listOfSkills=new ArrayList<>();

		for (String skill : cleanedTechnicalSkillsSection) {
			String[] parts = skill.split(":");
			if (parts.length == 2) {
				String key = parts[0].trim();
				String[] values = parts[1].trim().split("\\s*(,|and)\\s*");
				for (int i = 0; i < values.length; i++) {
					values[i] = values[i].trim();
				}
				technicalSkillsMap.put(key, values);
			}
		}
				
		for(Entry<String, String[]> skill:technicalSkillsMap.entrySet()) {
			 for (String skillName : skill.getValue()) {
				 	Collections.addAll(listOfSkills, skillName);
	            }
		}
		
		return listOfSkills;
	}

}
