package com.maveric.spectrum.profilems.controllers;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.maveric.spectrum.profilems.exceptions.DataUnavailableException;
import com.maveric.spectrum.profilems.exceptions.InvalidFileFormatException;
import com.maveric.spectrum.profilems.services.UserProfileService;


@RestController
@CrossOrigin
@RequestMapping("/userprofile")
public class UserProfileController {

	public UserProfileController(UserProfileService userProfileService) {
		this.userProfileService = userProfileService;
	}

	private UserProfileService userProfileService;
	
	@PostMapping("/createUserProfile")
	public ResponseEntity<String> createUserProfile(@RequestParam("resume") MultipartFile file) throws IOException, DataUnavailableException, InvalidFileFormatException{
		return userProfileService.createUserProfile(file);
	}

}
