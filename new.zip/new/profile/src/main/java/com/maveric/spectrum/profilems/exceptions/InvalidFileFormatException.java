package com.maveric.spectrum.profilems.exceptions;

public class InvalidFileFormatException extends Exception {

	public InvalidFileFormatException(String msg) {
		super(msg);
	}

	public InvalidFileFormatException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
