package com.maveric.spectrum.profilems.services;

import java.util.List;

import com.maveric.spectrum.profilems.dtos.UserWorkExperienceResponeDTO;

public interface UserWorkExperienceService {
	
	public List<UserWorkExperienceResponeDTO> getUserWorkExperience(List<String> workExperienceSection);

}
