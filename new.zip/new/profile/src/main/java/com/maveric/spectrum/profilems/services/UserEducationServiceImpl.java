package com.maveric.spectrum.profilems.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.maveric.spectrum.profilems.dtos.UserEducationResponeDTO;
import com.maveric.spectrum.profilems.utils.ResumeKeyword;

@Service
public class UserEducationServiceImpl implements UserEducationService {

	@Override
	public List<UserEducationResponeDTO> getUserEducationExperience(List<String> educationSection) {
		List<String> cleanedQualificationSection = educationSection.stream().filter(s -> !s.trim().isEmpty())
				.map(String::trim).toList();

		List<UserEducationResponeDTO> qualifications = new ArrayList<>();
		UserEducationResponeDTO qualification = null;

		for (String line : cleanedQualificationSection) {

			if (line.startsWith(ResumeKeyword.QUALIFICATION_KEYS[0])) {
				if (qualification != null) {
					qualifications.add(qualification);
				}
				qualification = new UserEducationResponeDTO();
				qualification.setEducationTitle(line.substring(20).trim());
			} else if (line.startsWith(ResumeKeyword.QUALIFICATION_KEYS[1]) && qualification != null) {
					qualification.setInstituteName(line.substring(16).trim());
			} else if (line.startsWith(ResumeKeyword.QUALIFICATION_KEYS[2]) && qualification != null) {
					qualification.setStartDuration(line.substring(14).trim());
			} else if (line.startsWith(ResumeKeyword.QUALIFICATION_KEYS[3]) && qualification != null) {
				qualification.setEndDuration(line.substring(13).trim());
			} else if (line.startsWith(ResumeKeyword.QUALIFICATION_KEYS[4]) && qualification != null) {
				Double score = Double.valueOf(line.substring(7).trim());
				qualification.setScore(score);
			}
		}
		if (qualification != null) {
			qualifications.add(qualification);
		}
		
		return qualifications;
	}

}
