package com.maveric.spectrum.profilems.services;

import java.util.List;

import com.maveric.spectrum.profilems.dtos.UserEducationResponeDTO;

public interface UserEducationService {
	public List<UserEducationResponeDTO> getUserEducationExperience(List<String> educationSection);

}
