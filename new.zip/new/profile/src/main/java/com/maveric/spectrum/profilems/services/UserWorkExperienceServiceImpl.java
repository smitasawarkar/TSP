package com.maveric.spectrum.profilems.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.maveric.spectrum.profilems.dtos.UserWorkExperienceResponeDTO;

@Service
public class UserWorkExperienceServiceImpl implements UserWorkExperienceService {

	@Override
	public List<UserWorkExperienceResponeDTO> getUserWorkExperience(List<String> workExperienceSection) {
		List<UserWorkExperienceResponeDTO> workExperiences = new ArrayList<>();

		for (String line : workExperienceSection) {
			String[] parts = line.split(":");
			if (parts.length == 2) {
				String fieldName = parts[0].trim();
				String fieldValue = parts[1].trim();

				if (fieldName.equalsIgnoreCase("Company Name")) {
					UserWorkExperienceResponeDTO currentExperience = new UserWorkExperienceResponeDTO();
					currentExperience.setCompanyName(fieldValue);
					workExperiences.add(currentExperience);
				} else {
					UserWorkExperienceResponeDTO currentExperience = workExperiences.get(workExperiences.size() - 1);
					switch (fieldName) {
					case "Job Title":
						currentExperience.setJobTitle(fieldValue);
						break;
					case "Start Date":
						currentExperience.setStartDate(fieldValue);
						break;
					case "End Date":
						currentExperience.setEndDate(fieldValue);
						break;
					case "Location":
						currentExperience.setLocation(fieldValue);
						break;
					default:
						break;
					}
				}
			}
		}
		return workExperiences;
	}

}
