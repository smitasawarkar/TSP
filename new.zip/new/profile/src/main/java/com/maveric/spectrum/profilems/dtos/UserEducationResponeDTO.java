package com.maveric.spectrum.profilems.dtos;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class UserEducationResponeDTO {
	private String educationTitle;
	private String instituteName;
	private String startDuration;
	private String endDuration;
	private Double score;
}
