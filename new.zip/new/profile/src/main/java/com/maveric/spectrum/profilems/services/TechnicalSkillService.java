package com.maveric.spectrum.profilems.services;

import java.util.List;

public interface TechnicalSkillService {
	public List<String> getTechnicalSkills(List<String> technicalSkillsSection);
}
