//package com.maveric.spectrum.notification.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.ArgumentMatchers.eq;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.maveric.spectrum.notification.dtos.NotificationResponseDTO;
//import com.maveric.spectrum.notification.dtos.SendNotificationDTO;
//import com.maveric.spectrum.notification.entities.Notification;
//import com.maveric.spectrum.notification.entities.NotificationStatus;
//import com.maveric.spectrum.notification.exceptions.DataUnavailableException;
//import com.maveric.spectrum.notification.repositories.notificationRepository;
//import com.maveric.spectrum.notification.services.NotificationServiceImpl;
//import com.maveric.spectrum.notification.utils.NotificationKeyWord;
// 
//class NotificationServiceImplTest {
// 
//	@Mock
//	private notificationRepository NotificationRepository;
// 
//	@InjectMocks
//	private NotificationServiceImpl notificationServiceImpl;
//	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
// 
//	@BeforeEach
//	void setUp() {
//		MockitoAnnotations.openMocks(this);
//	}
// 
//	@Test
//	void testGetNotifications() throws DataUnavailableException {
//		// Given
//		Integer managerId = 1;
//		Notification notification = new Notification();
//		notification.setId(1);
//		notification.setEmployeeName("Hariprasad Tarate");
//		notification.setManagerId(managerId);
//		notification.setNotificationTime(LocalDateTime.now().format(formatter));
//		notification.setNotificationStatus(NotificationStatus.SENT);
// 
//		when(NotificationRepository.findByManagerId(managerId)).thenReturn(Arrays.asList(notification));
//		doNothing().when(NotificationRepository).setNotificationStatus(anyInt(), eq(NotificationStatus.RECEIVED));
// 
//		// When
//		List<NotificationResponseDTO> result = notificationServiceImpl.getNotifications(managerId);
// 
//		// Then
//		assertEquals(1, result.size());
//		assertEquals("Hariprasad Tarate", result.get(0).getEmployeeName());
//		assertEquals(managerId.intValue(), result.get(0).getManagerId());
//		verify(NotificationRepository, times(1)).findByManagerId(managerId);
//		verify(NotificationRepository, times(1)).setNotificationStatus(anyInt(), eq(NotificationStatus.RECEIVED));
//	}
// 
//	@Test
//	void testSetNotification() {
//		// Given
//		SendNotificationDTO sendNotificationDTO = new SendNotificationDTO();
//		sendNotificationDTO.setEmpName("Ashlesha Ghute");
//		sendNotificationDTO.setManagerId(Arrays.asList(1, 2));
// 
//		// When
//		ResponseEntity<String> response = notificationServiceImpl.setNotification(sendNotificationDTO);
// 
//		// Then
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertEquals(NotificationKeyWord.respone, response.getBody());
//		verify(NotificationRepository, times(2)).save(any(Notification.class));
//	}
// 
//	@Test
//	void testSetNotificationStatus() {
//		// Given
//		NotificationResponseDTO notificationResponseDTO1 = new NotificationResponseDTO();
//		notificationResponseDTO1.setNotificationId(1);
// 
//		NotificationResponseDTO notificationResponseDTO2 = new NotificationResponseDTO();
//		notificationResponseDTO2.setNotificationId(2);
// 
//		List<NotificationResponseDTO> notificationResponseDTOList = Arrays.asList(notificationResponseDTO1,
//				notificationResponseDTO2);
// 
//		// When
//		ResponseEntity<String> response = notificationServiceImpl.setNotificationStatus(notificationResponseDTOList);
// 
//		// Then
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertEquals(NotificationKeyWord.stausUpdte, response.getBody());
//		verify(NotificationRepository, times(1)).setNotificationStatus(1, NotificationStatus.SEEN);
//		verify(NotificationRepository, times(1)).setNotificationStatus(2, NotificationStatus.SEEN);
//	}
//}
