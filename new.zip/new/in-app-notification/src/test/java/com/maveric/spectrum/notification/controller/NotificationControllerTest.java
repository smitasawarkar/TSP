//package com.maveric.spectrum.notification.controller;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//
//import com.maveric.spectrum.notification.dtos.NotificationResponseDTO;
//import com.maveric.spectrum.notification.dtos.SendNotificationDTO;
//import com.maveric.spectrum.notification.services.NotificationService;
//import com.maveric.spectrum.notification.utils.NotificationKeyWord;
// 
//public class NotificationControllerTest {
// 
//	 @Mock
//	    private NotificationService notificationService;
// 
//	    @InjectMocks
//	    private NotificationController notificationController;
// 
//	    private MockMvc mockMvc;
// 
//	    @BeforeEach
//	    void setUp() {
//	        MockitoAnnotations.openMocks(this);
//	        mockMvc = MockMvcBuilders.standaloneSetup(notificationController).build();
//	    }
// 
//	    @Test
//	    void testGetNotifications() throws Exception {
//	        Integer managerId = 1;
//	        NotificationResponseDTO notificationResponseDTO = new NotificationResponseDTO();
//	        notificationResponseDTO.setEmployeeName("Hariprasad Tarate");
//	        notificationResponseDTO.setManagerId(managerId);
//	        notificationResponseDTO.setNotificationTime("2023-05-01T10:00:00");
//	        List<NotificationResponseDTO> notifications = Arrays.asList(notificationResponseDTO);
// 
//	        when(notificationService.getNotifications(anyInt())).thenReturn(notifications);
// 
//	        mockMvc.perform(get("/api/spectrum/notification/notifications/{id}", managerId))
//	                .andExpect(status().isOk())
//	                .andExpect(jsonPath("$[0].employeeName").value("Hariprasad Tarate"))
//	                .andExpect(jsonPath("$[0].managerId").value(managerId));
//	    }
// 
//	    @Test
//	    void testSetNotification() throws Exception {
//	        SendNotificationDTO sendNotificationDTO = new SendNotificationDTO();
//	        sendNotificationDTO.setEmpName("Jane Doe");
//	        sendNotificationDTO.setManagerId(Arrays.asList(1, 2));
// 
//	        when(notificationService.setNotification(any(SendNotificationDTO.class))).thenReturn(new ResponseEntity<>(NotificationKeyWord.respone, HttpStatus.OK));
// 
//	        mockMvc.perform(post("/api/spectrum/notification/notify")
//	                .contentType("application/json")
//	                .content("{\"empName\":\"Ashlesha Ghute\",\"managerId\":[1,2]}"))
//	                .andExpect(status().isOk())
//	                .andExpect(jsonPath("$").value(NotificationKeyWord.respone));
//	    }
// 
//	    @Test
//	    void testSetNotificationStatus() throws Exception {
//	        NotificationResponseDTO notificationResponseDTO = new NotificationResponseDTO();
//	        notificationResponseDTO.setNotificationId(1);
// 
//	        when(notificationService.setNotificationStatus(any(List.class))).thenReturn(new ResponseEntity<>(NotificationKeyWord.stausUpdte, HttpStatus.OK));
// 
//	        mockMvc.perform(post("/api/spectrum/notification/updateStatus")
//	                .contentType("application/json")
//	                .content("[{\"notificationId\":1}]"))
//	                .andExpect(status().isOk())
//	                .andExpect(jsonPath("$").value(NotificationKeyWord.stausUpdte));
//	    }
//}