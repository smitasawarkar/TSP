//package com.maveric.spectrum.notification;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class SpectrumNotificationMsApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
