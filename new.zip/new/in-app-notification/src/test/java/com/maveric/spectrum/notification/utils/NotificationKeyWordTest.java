//package com.maveric.spectrum.notification.utils;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import org.junit.jupiter.api.Test;
// 
//public class NotificationKeyWordTest {
// 
//	@Test
//    public void testResponseConstant() {
//        assertEquals("Details saved", NotificationKeyWord.respone);
//    }
// 
//    @Test
//    public void testStatusUpdateConstant() {
//        assertEquals("Status Updated", NotificationKeyWord.stausUpdte);
//    }
//}