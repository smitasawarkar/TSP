package com.maveric.spectrum.notification.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.notification.dtos.NotificationResponseDTO;
import com.maveric.spectrum.notification.dtos.SendNotificationDTO;
import com.maveric.spectrum.notification.exceptions.DataUnavailableException;
import com.maveric.spectrum.notification.services.NotificationService;


@RestController
@CrossOrigin
@RequestMapping("/api/spectrum/notification")
public class NotificationController {
	
	@Autowired
	private NotificationService notificationService;

	@GetMapping("/notifications/{id}")
	public ResponseEntity<List<NotificationResponseDTO>> getNotifications(@PathVariable("id") Integer managerId) throws DataUnavailableException {
	    List<NotificationResponseDTO> notifications = notificationService.getNotifications(managerId);
	    return new ResponseEntity<>(notifications, HttpStatus.OK);
	}
	
	@PostMapping("/notify")
	public ResponseEntity<String> setNotification(@RequestBody SendNotificationDTO sendNotificationDTO) {
		//TODO: process POST request
		
		return notificationService.setNotification(sendNotificationDTO);
	}
	
	@PostMapping("/updateStatus")
	public ResponseEntity<String> updateStatus(@RequestBody List<NotificationResponseDTO> notificationResponseDTO) throws DataUnavailableException {
		//TODO: process POST request
		
		return notificationService.setNotificationStatus(notificationResponseDTO);
	}
	
	
}
