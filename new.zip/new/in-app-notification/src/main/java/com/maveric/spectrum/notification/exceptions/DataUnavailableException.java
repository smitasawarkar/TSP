package com.maveric.spectrum.notification.exceptions;

public class DataUnavailableException extends Exception{

	private int statusCode;
	
	public DataUnavailableException(String msg) {
		super(msg);
	}
	
	public DataUnavailableException(int statusCode,String msg) {
		super(msg);
		this.statusCode=statusCode;
	}

	public DataUnavailableException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
