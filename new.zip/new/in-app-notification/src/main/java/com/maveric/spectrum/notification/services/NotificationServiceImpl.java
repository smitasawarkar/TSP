package com.maveric.spectrum.notification.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.notification.dtos.NotificationResponseDTO;
import com.maveric.spectrum.notification.dtos.SendNotificationDTO;
import com.maveric.spectrum.notification.entities.Notification;
import com.maveric.spectrum.notification.entities.NotificationStatus;
import com.maveric.spectrum.notification.exceptions.DataUnavailableException;
import com.maveric.spectrum.notification.repositories.notificationRepository;
import com.maveric.spectrum.notification.utils.NotificationKeyWord;

@Service
public class NotificationServiceImpl implements NotificationService {
	
	@Autowired
	private notificationRepository notificationRepository;
	
	@Override
	public List<NotificationResponseDTO> getNotifications(Integer managerId) throws DataUnavailableException {
		List<Notification> notificationList = notificationRepository.findByManagerId(managerId);
		if(notificationList.isEmpty()) {
			throw new DataUnavailableException("Data not found with Manager ID:"+managerId);
		}
		return notificationList.stream().map(this::mapToNotificationResponseDTO).collect(Collectors.toList());
	}

	private NotificationResponseDTO mapToNotificationResponseDTO(Notification notification) {
		NotificationResponseDTO responseDTO = new NotificationResponseDTO();
		responseDTO.setEmployeeName(notification.getEmployeeName());
		responseDTO.setManagerId(notification.getManagerId());
		responseDTO.setNotificationTime(notification.getNotificationTime());
		responseDTO.setNotificationStatus(notification.getNotificationStatus());
		responseDTO.setNotificationId(notification.getId());
		notificationRepository.setNotificationStatus(notification.getId(), NotificationStatus.RECEIVED);
		return responseDTO;
	}

	@Override
	public ResponseEntity<String> setNotification(SendNotificationDTO sendNotificationDto) {
		
		for (Integer managerId : sendNotificationDto.getManagerId()) {
			Notification notification = new Notification();
			notification.setEmployeeName(sendNotificationDto.getEmpName());
			notification.setManagerId(managerId);
			notification.setNotificationTime(LocalDateTime.now().toString());
			notification.setNotificationStatus(NotificationStatus.SENT);
			notificationRepository.save(notification);
		}
		return new ResponseEntity<String>(NotificationKeyWord.respone,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> setNotificationStatus(List<NotificationResponseDTO> notificationResponseDTO)  {
		// TODO Auto-generated method stub
		for(NotificationResponseDTO notification:notificationResponseDTO) {
			notificationRepository.setNotificationStatus(notification.getNotificationId(), notification.getNotificationStatus() );

		}
		return new ResponseEntity<String>(NotificationKeyWord.stausUpdte,HttpStatus.OK);
	}

}
