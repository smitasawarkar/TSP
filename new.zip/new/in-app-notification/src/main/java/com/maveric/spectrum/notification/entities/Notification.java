package com.maveric.spectrum.notification.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "notification")
public class Notification {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id")
	private Integer id;

	@Column(name = "employee_name", nullable = false)
	private String employeeName;

	@Column(name = "notification_time")
	private String notificationTime;

	@Column(name = "manager_id", nullable = false)
	private Integer managerId;

	@Enumerated(EnumType.STRING)
	@Column(name = "notification_status", nullable = false)
	private NotificationStatus notificationStatus;
}
