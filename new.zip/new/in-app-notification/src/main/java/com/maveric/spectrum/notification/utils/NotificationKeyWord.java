package com.maveric.spectrum.notification.utils;

public class NotificationKeyWord {
	public static final String respone="Details saved";
	public static final String stausUpdte="Status Updated";

}
