package com.maveric.spectrum.notification.exceptions;

public class NotificationException {

}
