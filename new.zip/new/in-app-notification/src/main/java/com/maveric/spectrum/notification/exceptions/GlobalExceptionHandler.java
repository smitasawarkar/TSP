package com.maveric.spectrum.notification.exceptions;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(URISyntaxException.class)
    public ResponseEntity<String> handleURISyntaxException(URISyntaxException ex) {
    	log.error("Employee Not Found");
        return errorResponse(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<String> handleMaxUploadSizeExceededException(MaxUploadSizeExceededException ex) {
    	log.error("File Size Exceeded Exception");
        return errorResponse(HttpStatus.BAD_REQUEST, "Uploaded file size exceeds the maximum limit");
    }

    @ExceptionHandler(DataUnavailableException.class)
    public ResponseEntity<String> handleDataUnavailableException(DataUnavailableException ex) {
    	log.error("Data unavailable Exception");
        return errorResponse(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<String> handleIOException(IOException ex) {
    	log.error("IO Exception");
        return errorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing the file");
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception ex) {
    	log.error("An unexpected error occurred");
        return errorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred");
    }

    private ResponseEntity<String> errorResponse(HttpStatus status, String message) {
        return ResponseEntity.status(status).body(message);
    }
}