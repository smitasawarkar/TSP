package com.maveric.spectrum.notification.entities;

public enum NotificationStatus {
	SENT, SEEN, RECEIVED

}
