package com.maveric.spectrum.notification.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.notification.dtos.NotificationResponseDTO;
import com.maveric.spectrum.notification.dtos.SendNotificationDTO;
import com.maveric.spectrum.notification.exceptions.DataUnavailableException;

public interface NotificationService {

	List<NotificationResponseDTO> getNotifications(Integer managerId) throws DataUnavailableException;
	ResponseEntity<String> setNotification(SendNotificationDTO endorseRequestDto);
	ResponseEntity<String> setNotificationStatus(List<NotificationResponseDTO> notificationResponseDTO) throws DataUnavailableException;
}
