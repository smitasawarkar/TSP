package com.maveric.spectrum.notification.dtos;

import java.time.LocalDateTime;

import com.maveric.spectrum.notification.entities.NotificationStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NotificationResponseDTO {
	private Integer notificationId;
    private String employeeName;
    private Integer managerId;
    private LocalDateTime notificationTime;
    private NotificationStatus notificationStatus;
 
    public void setNotificationTime(String notificationTime) {
        this.notificationTime = LocalDateTime.parse(notificationTime);
    }
 
}
