package com.maveric.spectrum.notification.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.maveric.spectrum.notification.entities.Notification;
import com.maveric.spectrum.notification.entities.NotificationStatus;

import jakarta.transaction.Transactional;

@Repository
public interface notificationRepository extends JpaRepository<Notification, Integer>{
	List<Notification> findByManagerId(Integer managerId);
	
	@Transactional
	@Modifying
	@Query("UPDATE Notification n SET n.notificationStatus = :receivedStatus WHERE n.id = :id")
	void setNotificationStatus(@Param("id") Integer notificationId, @Param("receivedStatus") NotificationStatus receivedStatus);

}
