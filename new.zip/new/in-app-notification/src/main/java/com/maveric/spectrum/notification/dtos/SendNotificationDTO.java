package com.maveric.spectrum.notification.dtos;

import java.util.List;

import lombok.Data;

@Data
public class SendNotificationDTO {
	private Integer empId;
	private String empName;
	private List<Integer> managerId;

}
