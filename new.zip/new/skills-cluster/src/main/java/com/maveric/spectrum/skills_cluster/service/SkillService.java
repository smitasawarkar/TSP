package com.maveric.spectrum.skills_cluster.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.spectrum.skills_cluster.dtos.SkillDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillMergeDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillNewDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillResponseDTO;
import com.maveric.spectrum.skills_cluster.dtos.UnclassifiedSkillDTO;

@Service
public interface SkillService {

	public List<Integer> reviewSkills(List<String> skillList);
	
	public List<SkillDTO> getAllSkills();
	
	public List<SkillDTO> getUserSkills(List<Integer> skillIDs);
	
	public List<SkillDTO> reviewSkillsDTOList(List<String> skillList);
	
	public SkillResponseDTO getSkillIdsBySkillName(String skillName);
	
	public List<UnclassifiedSkillDTO> getAllUnclassifiedSkills();
	
	public String mergeUnclassifiedSkills(SkillMergeDTO skillMergeDTO);
	
	public List<SkillNewDTO> getSkillBasedonParent(Integer parentInteger);
}
