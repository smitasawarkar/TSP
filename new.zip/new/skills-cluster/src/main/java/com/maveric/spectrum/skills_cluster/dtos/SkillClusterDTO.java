package com.maveric.spectrum.skills_cluster.dtos;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
public class SkillClusterDTO{
	
	private Integer clusterId;

	private String clusterName;
	
}
