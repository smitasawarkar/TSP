package com.maveric.spectrum.skills_cluster.utils;

public class Util {

}
