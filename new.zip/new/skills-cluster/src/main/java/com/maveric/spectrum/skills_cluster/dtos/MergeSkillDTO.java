package com.maveric.spectrum.skills_cluster.dtos;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MergeSkillDTO {
 
	private SkillMergeResponseDTO mergedSkill;
	private List<SkillMergeResponseDTO> mergeSkills; 
}
