package com.maveric.spectrum.skills_cluster.controller;

public class CenteralizedExpectionHandler {

}
