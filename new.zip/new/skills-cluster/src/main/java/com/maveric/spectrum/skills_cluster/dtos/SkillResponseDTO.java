package com.maveric.spectrum.skills_cluster.dtos;
 
 
import java.util.List;
 
import org.springframework.stereotype.Component;
 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
public class SkillResponseDTO {
 
	private List<Integer> skillId;
}