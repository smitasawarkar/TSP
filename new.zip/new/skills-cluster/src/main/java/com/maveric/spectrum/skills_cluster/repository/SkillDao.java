package com.maveric.spectrum.skills_cluster.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.maveric.spectrum.skills_cluster.entities.Skill;

public interface SkillDao extends JpaRepository<Skill, Integer> {

	boolean existsBySkillName(String skillName);

	Skill getBySkillName(String skillName);
	
	@Query(value = "select skillId from Skill where skillName like CONCAT('%', :skillName, '%')")
	List<Integer> findSkillIdsBySkillName(@Param("skillName") String skillName);
 
    @Query("SELECT s FROM Skill s WHERE s.parentSkill.skillId = :parentSkillId")
    List<Skill> findByParentId(@Param("parentSkillId") Integer parentSkillId);
    
    void deleteBySkillName(String skillName);
    
}
