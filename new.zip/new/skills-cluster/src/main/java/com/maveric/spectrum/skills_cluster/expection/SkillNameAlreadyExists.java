package com.maveric.spectrum.skills_cluster.expection;

public class SkillNameAlreadyExists extends RuntimeException {
	public SkillNameAlreadyExists(String msg) {
		super(msg);
	}
 
}
