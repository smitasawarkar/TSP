package com.maveric.spectrum.skills_cluster.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.spectrum.skills_cluster.entities.SkillCluster;


public interface SkillClusterRepository extends JpaRepository<SkillCluster, Integer> {

}
