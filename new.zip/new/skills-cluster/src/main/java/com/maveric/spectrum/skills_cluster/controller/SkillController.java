package com.maveric.spectrum.skills_cluster.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.skills_cluster.dtos.SkillDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillMergeDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillNewDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillResponseDTO;
import com.maveric.spectrum.skills_cluster.dtos.UnclassifiedSkillDTO;
import com.maveric.spectrum.skills_cluster.expection.SkillNotFoundException;
import com.maveric.spectrum.skills_cluster.service.SkillService;

@RestController
@CrossOrigin
@RequestMapping("/skills_clusterMS")
public class SkillController {
	
	private SkillService skillService;
	
	public SkillController(SkillService skillService) {
		this.skillService=skillService;
	}
	
	@PostMapping("/reviewSkill")
	public ResponseEntity<List<Integer>> reviewSkills(@RequestBody List<String> skillList) {		
		 List<Integer> skillIds =skillService.reviewSkills(skillList);
		 return ResponseEntity.ok(skillIds);
	}
	
	@GetMapping("/getAllSkills")
	public ResponseEntity<List<SkillDTO>> getAllSkills() throws SkillNotFoundException{
		List<SkillDTO> ListSkillDtos = skillService.getAllSkills();
		return ResponseEntity.ok(ListSkillDtos);
	}
	
	@PostMapping("/getUserSkill")
	public ResponseEntity<List<SkillDTO>> getSkillNames(@RequestBody List<Integer> skillIdList){
		List<SkillDTO> ListSkillDtos = skillService.getUserSkills(skillIdList);
		return ResponseEntity.ok(ListSkillDtos);
	}
	
	@PostMapping("/reviewSkillDTO")
	public ResponseEntity<List<SkillDTO>> getreviewSkillsDTOList(@RequestBody List<String> skillList){
		List<SkillDTO> ListSkillDtos = skillService.reviewSkillsDTOList(skillList);
		return ResponseEntity.ok(ListSkillDtos);
	}
	
	@GetMapping("/skillIds")
    public ResponseEntity<SkillResponseDTO> getSkillIdsBySkillName(@RequestParam("skillName") String skillName){
        return ResponseEntity.ok(skillService.getSkillIdsBySkillName(skillName));
    }
	
	@GetMapping("/getAllUnclassifiedSkills")
	public ResponseEntity<List<UnclassifiedSkillDTO>> getAllUnclassifiedSkills(){
		return ResponseEntity.ok(skillService.getAllUnclassifiedSkills());
	}
	
	@GetMapping("/getSkillBasedonParent/{parentId}")
	public ResponseEntity<List<SkillNewDTO>> getSkillBasedonParent(@PathVariable("parentId")Integer parentId){
		 List<SkillNewDTO> skills = skillService.getSkillBasedonParent(parentId);
	        return ResponseEntity.ok(skills);
	}
	
	@PostMapping("/mergeUnclassifieldSkills")
	public String mergeUnclassifiedSkills(@RequestBody SkillMergeDTO skillMergeDTO) {
	    return skillService.mergeUnclassifiedSkills(skillMergeDTO);
	}
}
