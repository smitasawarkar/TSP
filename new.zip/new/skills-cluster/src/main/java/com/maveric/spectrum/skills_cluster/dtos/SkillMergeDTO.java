package com.maveric.spectrum.skills_cluster.dtos;

import java.util.List;

import org.springframework.stereotype.Component;

import com.maveric.spectrum.skills_cluster.entities.Skill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class SkillMergeDTO {
	List<Skill> skillList;
	String newSkillName;
}
