package com.maveric.spectrum.skills_cluster.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.skills_cluster.dtos.MergeSkillDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillClusterDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillMergeDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillMergeResponseDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillNewDTO;
import com.maveric.spectrum.skills_cluster.dtos.SkillResponseDTO;
import com.maveric.spectrum.skills_cluster.dtos.UnclassifiedSkillDTO;
import com.maveric.spectrum.skills_cluster.entities.Skill;
import com.maveric.spectrum.skills_cluster.expection.SkillNameAlreadyExists;
import com.maveric.spectrum.skills_cluster.repository.SkillDao;

@Service
public class SkillServiceImpl implements SkillService {
	
	SkillDao skillDao;
	RestTemplate restTemplate;
	
	public SkillServiceImpl(SkillDao skillDao,RestTemplate restTemplate) {
		this.skillDao=skillDao;
		this.restTemplate=restTemplate;
	}

	@Override
	public List<Integer> reviewSkills(List<String> skillList) {
		List<Skill> responseSkillList = new ArrayList<>();
		List<Integer> skillIds = new ArrayList<>();
		Set<String> uniqueSkillNames = new HashSet<>();
		
		for(String skillName : skillList) {
			String formattedSkillName = skillName;
	        if (!formattedSkillName.isEmpty()) {
	            if (uniqueSkillNames.add(formattedSkillName)) {
	                Skill skill = skillDao.getBySkillName(formattedSkillName);
	                if (skill !=null) {
	                	responseSkillList.add(skill);
	                } else {
	                    Skill newSkill = new Skill();
	                    newSkill.setSkillName(formattedSkillName);
	                    newSkill.setParentSkill(skillDao.getBySkillName("Unclassified"));
	                    responseSkillList.add(skillDao.save(newSkill));
	                }
	            }
	        }
		}
	    for (Skill skill : responseSkillList) {
	        skillIds.add(skill.getSkillId());
	    }
	    return skillIds; 
	}

    @Override
    public List<SkillDTO> getAllSkills() {
        List<Skill> allSkills = skillDao.findAll();
        List<Skill> skillsToRemove = new ArrayList<>();
        List<SkillDTO> allClassifiedSkillsDTO = new ArrayList<>();

        Skill unclassifiedSkill = skillDao.getBySkillName("Unclassified");

        for (Skill skill : allSkills) {
            if (skill.getParentSkill() == null || skill.getParentSkill().getSkillId().equals(unclassifiedSkill.getSkillId())) {
                skillsToRemove.add(skill);
            }
        }

        allSkills.removeAll(skillsToRemove);

        for (Skill skill : allSkills) {
            allClassifiedSkillsDTO.add(skillToDTOConversion(skill));
        }

        return allClassifiedSkillsDTO;
    }


	@Override
	public List<SkillDTO> getUserSkills(List<Integer> skillIDs) {
		List<Skill> skills = skillDao.findAllById(skillIDs);

		List<SkillDTO> SkillDTOs = new ArrayList<>();
		for (Skill skill : skills) {
			SkillDTOs.add(skillToDTOConversion(skill));
		}
		return SkillDTOs;
	}
	
	private SkillDTO skillToDTOConversion(Skill skill) {
		SkillDTO skillDTO = new SkillDTO();
		List<SkillClusterDTO> SkillClusterDTOs = new ArrayList<>();
		
		//	if(skill.getParentSkill()!=null)
			if (!(skill.getParentSkill().getSkillId().equals(skillDao.getBySkillName("Unclassified").getSkillId()))) {
			skill.getParentSkill();
			SkillClusterDTO skillClusterDTO = new SkillClusterDTO();
			skillClusterDTO.setClusterId(getRootParent(skill).getSkillId());
			skillClusterDTO.setClusterName(getRootParent(skill).getSkillName());
			SkillClusterDTOs.add(skillClusterDTO);	
		}
		skillDTO.setSkillId(skill.getSkillId());
		skillDTO.setSkillName(skill.getSkillName());
		skillDTO.setSkillClusterDTO(SkillClusterDTOs);
		return skillDTO;
	}
	
    private Skill getRootParent(Skill skill) {
        Skill parentSkill = skill;
        while (parentSkill.getParentSkill() != null) {
        	parentSkill = parentSkill.getParentSkill();
        }
        return parentSkill;
    }

	@Override
	public List<SkillDTO> reviewSkillsDTOList(List<String> skillList) {
	    List<Skill> responseSkillList = new ArrayList<>();
	    Set<String> uniqueSkillNames = new HashSet<>();

	    for (String skillName : skillList) {
	        String formattedSkillName = skillName;
	        if (!formattedSkillName.isEmpty()) {
	            if (uniqueSkillNames.add(formattedSkillName)) {
	                Skill skill = skillDao.getBySkillName(formattedSkillName);
	                if (skill != null) {
	                    responseSkillList.add(skill);
	                } else {
	                    Skill newSkill = new Skill();
	                    newSkill.setSkillName(formattedSkillName);
	                    responseSkillList.add(skillDao.save(newSkill));
	                }
	            }
	        }
	    }

	    // Convert Skill objects to SkillDTO objects
	    List<SkillDTO> skillsDTO = new ArrayList<>();
	    for (Skill skill : responseSkillList) {
	        skillsDTO.add(skillToDTOConversion(skill));
	    }
	    
	    return skillsDTO;   
	}

	@Override
	public SkillResponseDTO getSkillIdsBySkillName(String skillName) {
		SkillResponseDTO response = new SkillResponseDTO();
		response.setSkillId(skillDao.findSkillIdsBySkillName(skillName));
		return response;
	}
	
	private List<Skill> getAllSkillFromDB(){
		  List<Skill> allSkills = skillDao.findAll();
		return allSkills;
	}

	@Override
	public List<UnclassifiedSkillDTO> getAllUnclassifiedSkills() {
		  List<Skill> allSkills = skillDao.findAll();
	      List<UnclassifiedSkillDTO> unclassifiedSkillsDTO = new ArrayList<>();
	      
	      for(Skill skill : allSkills) {
	    	  if(skill.getParentSkill()!=null && skill.getParentSkill().getSkillId().equals(skillDao.getBySkillName("Unclassified").getSkillId())) {
	    		  UnclassifiedSkillDTO unclassifiedSkillDTO = new UnclassifiedSkillDTO();
	    		  unclassifiedSkillDTO.setSkillId(skill.getSkillId());
	    		  unclassifiedSkillDTO.setSkillName(skill.getSkillName());
	    		  unclassifiedSkillsDTO.add(unclassifiedSkillDTO);
	    	  }
	      }
		return unclassifiedSkillsDTO;
	}
	public String mergeUnclassifiedSkills(SkillMergeDTO skillMergeDTO) {
		MergeSkillDTO mergeSkillDTO = new MergeSkillDTO();
		List<SkillMergeResponseDTO> skillsMergeResponseDTO = new ArrayList<>();
		Skill skill=new Skill();
		skill.setSkillName(skillMergeDTO.getNewSkillName());
		Skill parentSkill=skillDao.getBySkillName("Unclassified");
		skill.setParentSkill(parentSkill);
		List<Skill> skillList=getAllSkillFromDB();
		Skill checkDuplicate=skillDao.getBySkillName(skillMergeDTO.getNewSkillName());
		if(checkDuplicate!=null) {
			if(skillMergeDTO.getNewSkillName().equals(checkDuplicate.getSkillName())) {
				throw new SkillNameAlreadyExists("The skill name entered is already exists");
		}
	}
		Skill newSkill = skillDao.save(skill);
		for(Skill skillData : skillMergeDTO.getSkillList()) {
			SkillMergeResponseDTO skillMergeResponseDTOs = new SkillMergeResponseDTO();		
			skillMergeResponseDTOs.setSkillId(skillData.getSkillId());
			skillMergeResponseDTOs.setSkillName(skillData.getSkillName());
			skillsMergeResponseDTO.add(skillMergeResponseDTOs);
			mergeSkillDTO.setMergeSkills(skillsMergeResponseDTO);
			SkillMergeResponseDTO skillMergeResponseDTO = new SkillMergeResponseDTO();
			skillMergeResponseDTO.setSkillId(newSkill.getSkillId());
			skillMergeResponseDTO.setSkillName(newSkill.getSkillName());
			mergeSkillDTO.setMergedSkill(skillMergeResponseDTO);
		}
		System.out.println(mergeSkillDTO);
		restTemplate.postForObject("http://localhost:9002/api/spectrum/employee/mergeEmployeeSkills", mergeSkillDTO ,MergeSkillDTO.class);
		deleteDuplicateSkill(skillMergeDTO);
		
		return "Skill Merged";
	}
	
	@Override
	public List<SkillNewDTO> getSkillBasedonParent(Integer parentId) {
		//Skill skill = skillDao.findById(parentId).get();
		List<Skill> skills = skillDao.findByParentId(parentId);
		List<SkillNewDTO> SkillNewDTOs= new ArrayList<>();
			for(Skill skill : skills) {
				SkillNewDTO skillNewDTO = new SkillNewDTO();
				skillNewDTO.setSkillId(skill.getSkillId());
				skillNewDTO.setSkillName(skill.getSkillName());	
				SkillNewDTOs.add(skillNewDTO);
			}
	        return SkillNewDTOs;
	    }
	
	private void deleteDuplicateSkill(SkillMergeDTO skillMergeDTO) {
		List<Skill> skillToBeDeleted=skillMergeDTO.getSkillList();
		if(skillToBeDeleted!=null) {
		for(Skill skill:skillToBeDeleted) {
			skillDao.deleteById(skill.getSkillId());
	  }
	}
  }
}
