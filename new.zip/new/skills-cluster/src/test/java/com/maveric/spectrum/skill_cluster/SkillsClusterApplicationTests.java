//package com.maveric.spectrum.skill_cluster;
//
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.maveric.spectrum.skills_cluster.dtos.SkillClusterDTO;
//import com.maveric.spectrum.skills_cluster.dtos.SkillDTO;
//import com.maveric.spectrum.skills_cluster.entities.Skill;
//import com.maveric.spectrum.skills_cluster.entities.SkillCluster;
//import com.maveric.spectrum.skills_cluster.repository.SkillDao;
//import com.maveric.spectrum.skills_cluster.service.SkillServiceImpl;
//import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;
//
//@ExtendWith(MockitoExtension.class)
//class SkillsClusterApplicationTests {
//
//	@Autowired
//	private MockMvc mockMvc;
//	
//	@Mock
//	private SkillDao skillDao;
//	
//	@InjectMocks
//	private SkillServiceImpl skillService;
//
//	@Test
//	void testReviewSkills() {
//		// Mocking data
//		String skillName = "Java";
//		List<String> skillList = new ArrayList<>();
//		skillList.add(skillName);
//		Skill skill = new Skill();
//		skill.setSkillId(1);
//		skill.setSkillName(skillName);
//
//		// Stubbing method calls
//		when(skillDao.getBySkillName(skillName)).thenReturn(skill);
//
//		// Calling the method under test
//		List<Integer> result = skillService.reviewSkills(skillList);
//
//		// Verifying behavior
//		Assertions.assertEquals(1, result.size());
//		Assertions.assertEquals(Integer.valueOf(1), result.get(0));
//	}
//
//	@Test
//	void testReviewSkills2() {
//		
//		String skillName = "java";
//		List<String> skillList = new ArrayList<>(Arrays.asList(skillName));
//		
//		Skill skillTobeSaved = new Skill();
//		skillTobeSaved.setSkillName(skillName);
//		
//		Skill skillResponse = new Skill();
//		SkillCluster firstCluster = new SkillCluster();
//		SkillCluster secondCluster = new SkillCluster(); 
//		firstCluster.setClusterId(1);
//		firstCluster.setClusterName("Domain");
//		secondCluster.setClusterId(2);
//		secondCluster.setClusterName("Technical");
//		
//		List<SkillCluster> skillClusters = new ArrayList<>();
//		skillClusters.add(secondCluster);
//		skillClusters.add(firstCluster);
//
//		skillResponse.setSkillId(1);
//		skillResponse.setSkillName("java");
//		skillResponse.setSkillClusters(skillClusters);
//
//		// Stubbing method calls
//		when(skillDao.getBySkillName(skillName)).thenReturn(null);
//		when(skillDao.save(skillTobeSaved)).thenReturn(skillResponse);
//		
//		//Act
//		List<Integer> result = skillService.reviewSkills(skillList);
//		
//	    // Verify method invocations
//	    verify(skillDao, times(1)).getBySkillName(skillName);
//	    verify(skillDao, times(1)).save(skillTobeSaved);
//		
//		//Assertion
//		Assertions.assertEquals(Integer.valueOf(1), result.get(0));
//	}
//
//	/*@Test
//	void getAllSkills() {
//		List<SkillDTO> expected = new ArrayList<>();
//		String[] skillCluster = {"Domain","Technical"}; 
//		
//		List<Skill> skillSkills = new ArrayList<>();
//		List<SkillCluster> skillClusters = new ArrayList<>();
//		SkillCluster oneSkillCluster = new SkillCluster();
//		oneSkillCluster.setClusterId(1);
//		oneSkillCluster.setClusterName("Tools");
//		Skill skillResponse = new Skill();
//		skillResponse.setSkillId(1);
//		skillResponse.setSkillName("java");
//		skillResponse.setSkillClusters(skillClusters);
//		
//		List<SkillClusterDTO> skillClustersDTO = new ArrayList<>();
//		SkillClusterDTO firstCluster = new SkillClusterDTO();
//		SkillClusterDTO secondCluster = new SkillClusterDTO(); 
//		firstCluster.setClusterId(1);
//		firstCluster.setClusterName("Domain");
//		secondCluster.setClusterId(2);
//		secondCluster.setClusterName("Technical");
//		skillClustersDTO.add(secondCluster);
//		skillClustersDTO.add(firstCluster);
//
//		SkillDTO skillDTO = new SkillDTO();
//		skillDTO.setSkillId(1);
//		skillDTO.setSkillName("Management");
//		skillDTO.setSkillClusterDTO(new ArrayList<SkillClusterDTO>(skillClustersDTO));
//		
//		expected.add(skillDTO);
//		
//		//Stub
//		when(skillDao.findAll()).thenReturn(skillSkills);
//		
//		List<SkillDTO> actual = skillService.getAllSkills();
//		
//		//Assert
//		Assertions.assertEquals(expected.size(), actual.size());
//		Assertions.assertEquals(expected.get(0).getSkillName(), actual.get(0).getSkillName());
//		Assertions.assertEquals(expected.get(0).getSkillClusterDTO().size(), actual.get(0).getSkillClusterDTO().size());
//		
//	}*/
//}