package com.maveric.spectrum.educationms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.maveric.spectrum.educationms.entities.ActivitiesAndSocities;
import com.maveric.spectrum.educationms.entities.Degrees;
import com.maveric.spectrum.educationms.entities.FieldOfStudies;
import com.maveric.spectrum.educationms.entities.Institutes;
import com.maveric.spectrum.educationms.repository.ActivitiesAndSocitiesRepository;
import com.maveric.spectrum.educationms.repository.DegreesRepository;
import com.maveric.spectrum.educationms.repository.FieldOfStudiesRepository;
import com.maveric.spectrum.educationms.repository.InstitutesReository;
import com.maveric.spectrum.educationms.service.EmloyeeEducationServiceImpl;

@ExtendWith(MockitoExtension.class)
class EmployeeEducationServiceImplTests {

	@Mock	
    InstitutesReository institutesRepository;
    
    @Mock
    DegreesRepository degreesRepository;
    
    @Mock
    ActivitiesAndSocitiesRepository activitiesAndSocitiesRepository;
    
    @Mock
    FieldOfStudiesRepository fieldOfStudiesRepository;
    
    @InjectMocks
    EmloyeeEducationServiceImpl educationService;
 

    @Test
    void testGetInstituteName() {

        List<Institutes> mockInstitutes = new ArrayList<>();
        mockInstitutes.add(new Institutes(1, "Amrutvahini College"));
        mockInstitutes.add(new Institutes(2, "D.Y.Patil College"));
        mockInstitutes.add(new Institutes(3, "Sanjivani College"));
        when(institutesRepository.findAll()).thenReturn(mockInstitutes);
        
        List<String> instituteNames = educationService.getInstituteName();
        
        List<String> expectedNames = mockInstitutes.stream()
                                    .map(Institutes::getInstituteName)
                                    .collect(Collectors.toList());
        assertEquals(expectedNames, instituteNames);
    }

    @Test
    void testGetDegreeName() {
 
    	List<Degrees> mockDegrees = new ArrayList<>();
        mockDegrees.add(new Degrees(1, "Mechanical Engineering"));
        mockDegrees.add(new Degrees(2, "Computer Engineering"));
        mockDegrees.add(new Degrees(3, "Electrical Engineering"));
        when(degreesRepository.findAll()).thenReturn(mockDegrees);
        
        List<String> degreeNames = educationService.getDegreeName();
        
        List<String> expectedNames = mockDegrees.stream()
                                    .map(Degrees::getDegreeName)
                                    .collect(Collectors.toList());
        assertEquals(expectedNames, degreeNames);
    }

    @Test
    void testGetActivityAndSocietyName() {

    	List<ActivitiesAndSocities> mockActivitiesAndSocities = new ArrayList<>();
        mockActivitiesAndSocities.add(new ActivitiesAndSocities(1, "Cricket"));
        mockActivitiesAndSocities.add(new ActivitiesAndSocities(2, "Foot Ball"));
        mockActivitiesAndSocities.add(new ActivitiesAndSocities(3, "Chess"));
        when(activitiesAndSocitiesRepository.findAll()).thenReturn(mockActivitiesAndSocities);
        
        List<String> activityAndSocietyNames = educationService.getActivityAndSocietyName();
        
        List<String> expectedNames = mockActivitiesAndSocities.stream()
                                    .map(ActivitiesAndSocities::getActivitySocietyName)
                                    .collect(Collectors.toList());
        assertEquals(expectedNames, activityAndSocietyNames);
    }
    
    @Test
    void testGetFieldOfStudyName() {
    	
        List<FieldOfStudies> mockFieldOfStudies = new ArrayList<>();
        mockFieldOfStudies.add(new FieldOfStudies(1, "Computer Science"));
        mockFieldOfStudies.add(new FieldOfStudies(2, "Mathematics"));
        mockFieldOfStudies.add(new FieldOfStudies(3, "History"));
        when(fieldOfStudiesRepository.findAll()).thenReturn(mockFieldOfStudies);
        
        List<String> fieldOfStudyNames = educationService.getFieldOfStudyName();
        
        List<String> expectedNames = mockFieldOfStudies.stream()
                                    .map(FieldOfStudies::getFieldOfStudyName)
                                    .collect(Collectors.toList());
        assertEquals(expectedNames, fieldOfStudyNames);
    }


}
