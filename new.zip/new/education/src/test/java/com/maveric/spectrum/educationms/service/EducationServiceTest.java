package com.maveric.spectrum.educationms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.maveric.spectrum.educationms.entities.ActivitiesAndSocities;
import com.maveric.spectrum.educationms.entities.Degrees;
import com.maveric.spectrum.educationms.entities.FieldOfStudies;
import com.maveric.spectrum.educationms.entities.Institutes;
import com.maveric.spectrum.educationms.repository.ActivitiesAndSocitiesRepository;
import com.maveric.spectrum.educationms.repository.DegreesRepository;
import com.maveric.spectrum.educationms.repository.FieldOfStudiesRepository;
import com.maveric.spectrum.educationms.repository.InstitutesReository;

class EducationServiceTest {

    @Mock
    private InstitutesReository institutesRepository;
    
    @Mock
    private DegreesRepository degreesRepository;
    
    @Mock
    private ActivitiesAndSocitiesRepository activitiesAndSocitiesRepository;
    
    @Mock
    private FieldOfStudiesRepository fieldOfStudiesRepository;
    
    @InjectMocks
    private EmloyeeEducationServiceImpl employeeEducationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetInstituteName() {
        List<Institutes> institutes = Arrays.asList(
            new Institutes(1, "Amrutvahini College"),
            new Institutes(2, "D.Y.Patil College"),
            new Institutes(3, "Sanjivani College")
        );
        when(institutesRepository.findAll()).thenReturn(institutes);

        List<String> result = employeeEducationService.getInstituteName();

        List<String> expectedNames = institutes.stream()
                                            .map(Institutes::getInstituteName)
                                            .collect(Collectors.toList());
        assertEquals(expectedNames, result);
    }

    @Test
    void testGetDegreeName() {
        List<Degrees> degrees = Arrays.asList(
            new Degrees(1, "Mechanical Engineering"),
            new Degrees(2, "Computer Engineering"),
            new Degrees(3, "Electrical Engineering")
        );
        when(degreesRepository.findAll()).thenReturn(degrees);

        List<String> result = employeeEducationService.getDegreeName();

        List<String> expectedNames = degrees.stream()
                                            .map(Degrees::getDegreeName)
                                            .collect(Collectors.toList());
        assertEquals(expectedNames, result);
    }

    @Test
    void testGetActivityAndSocietyName() {
        List<ActivitiesAndSocities> activities = Arrays.asList(
            new ActivitiesAndSocities(1, "Cricket"),
            new ActivitiesAndSocities(2, "Foot Ball"),
            new ActivitiesAndSocities(3, "Chess")
        );
        when(activitiesAndSocitiesRepository.findAll()).thenReturn(activities);

        List<String> result = employeeEducationService.getActivityAndSocietyName();

        List<String> expectedNames = activities.stream()
                                            .map(ActivitiesAndSocities::getActivitySocietyName)
                                            .collect(Collectors.toList());
        assertEquals(expectedNames, result);
    }

    @Test
    void testGetFieldOfStudyName() {
        List<FieldOfStudies> fields = Arrays.asList(
            new FieldOfStudies(1, "Computer Science"),
            new FieldOfStudies(2, "Mathematics"),
            new FieldOfStudies(3, "History")
        );
        when(fieldOfStudiesRepository.findAll()).thenReturn(fields);

        List<String> result = employeeEducationService.getFieldOfStudyName();

        List<String> expectedNames = fields.stream()
                                            .map(FieldOfStudies::getFieldOfStudyName)
                                            .collect(Collectors.toList());
        assertEquals(expectedNames, result);
    }
}
