package com.maveric.spectrum.educationms.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.maveric.spectrum.educationms.service.EducationService;

class EducationControllerTest {

	@Mock
	private EducationService educationService;

	@InjectMocks
	private EducationController educationController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testGetInstituteName() {

		List<String> institutes = Arrays.asList("Amrutvahini College", "D.Y.Patil College", "Sanjivani College");
		when(educationService.getInstituteName()).thenReturn(institutes);

		List<String> result = educationController.getInstituteName();

		assertEquals(institutes, result);
	}

	@Test
	void testGetDegreeName() {

		List<String> degrees = Arrays.asList("Mechanical Engineering", "Computer Engineering", "Electrical Engineering");
		when(educationService.getDegreeName()).thenReturn(degrees);

		List<String> result = educationController.getDegreeName();

		assertEquals(degrees, result);
	}

	@Test
	void testGetActivityAndSocietyName() {

		List<String> activities = Arrays.asList("Cricket", "Foot Ball", "Chess");
		when(educationService.getActivityAndSocietyName()).thenReturn(activities);

		List<String> result = educationController.getActivityAndSocietyName();

		assertEquals(activities, result);
	}

	@Test
	void testGetFieldOfStudyName() {

		List<String> fields = Arrays.asList("Computer Science", "Mathematics", "History");
		when(educationService.getFieldOfStudyName()).thenReturn(fields);

		List<String> result = educationController.getFieldOfStudyName();

		assertEquals(fields, result);
	}
}
