package com.maveric.spectrum.educationms.service;

import java.util.List;

import com.maveric.spectrum.educationms.dtos.CertificateResponseDTO;

public interface EducationService {
	
		public List<String> getInstituteName();
		public List<String> getDegreeName();
		public List<String> getActivityAndSocietyName();
		public List<String> getFieldOfStudyName();
		public CertificateResponseDTO getCertificate();
}
