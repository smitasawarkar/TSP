package com.maveric.spectrum.educationms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.maveric.spectrum.educationms.dtos.CertificateResponseDTO;
import com.maveric.spectrum.educationms.entities.ActivitiesAndSocities;
import com.maveric.spectrum.educationms.entities.Certificate;
import com.maveric.spectrum.educationms.entities.Degrees;
import com.maveric.spectrum.educationms.entities.FieldOfStudies;
import com.maveric.spectrum.educationms.entities.Institutes;
import com.maveric.spectrum.educationms.repository.ActivitiesAndSocitiesRepository;
import com.maveric.spectrum.educationms.repository.CertificateRepository;
import com.maveric.spectrum.educationms.repository.DegreesRepository;
import com.maveric.spectrum.educationms.repository.FieldOfStudiesRepository;
import com.maveric.spectrum.educationms.repository.InstitutesReository;

@Service
public class EmloyeeEducationServiceImpl implements EducationService {

	private InstitutesReository institutesRepository;
	private DegreesRepository degreesRepository;
	private ActivitiesAndSocitiesRepository activitiesAndSocitiesRepository;
	private FieldOfStudiesRepository fieldOfStudiesRepository;
	private CertificateRepository certificateRepository;
	

	public EmloyeeEducationServiceImpl(InstitutesReository institutesRepository, DegreesRepository degreesRepository,
			ActivitiesAndSocitiesRepository activitiesAndSocitiesRepository,
			FieldOfStudiesRepository fieldOfStudiesRepository, CertificateRepository certificateRepository) {
		super();
		this.institutesRepository = institutesRepository;
		this.degreesRepository = degreesRepository;
		this.activitiesAndSocitiesRepository = activitiesAndSocitiesRepository;
		this.fieldOfStudiesRepository = fieldOfStudiesRepository;
		this.certificateRepository = certificateRepository;
	}

	@Override
	public List<String> getInstituteName() {
		List<Institutes> listOfinstitute = institutesRepository.findAll();
		List<String> instituteNames = listOfinstitute.stream().map(institute -> {
			return institute.getInstituteName();
		}).distinct().collect(Collectors.toList());

		return instituteNames;
	}

	@Override
	public List<String> getDegreeName() {
		List<Degrees> listOfdegree = degreesRepository.findAll();
		List<String> degreeNames = listOfdegree.stream().map(degree -> {
			return degree.getDegreeName();
		}).distinct().collect(Collectors.toList());

		return degreeNames;
	}

	@Override
	public List<String> getActivityAndSocietyName() {
		List<ActivitiesAndSocities> listOfactivityAndSociety = activitiesAndSocitiesRepository.findAll();
		List<String> activityAndSocietyNames = listOfactivityAndSociety.stream().map(activityAndSociety -> {
			return activityAndSociety.getActivitySocietyName();
		}).distinct().collect(Collectors.toList());

		return activityAndSocietyNames;
	}

	@Override
	public List<String> getFieldOfStudyName() {
		List<FieldOfStudies> listOffieldOfStudy = fieldOfStudiesRepository.findAll();

		List<String> fieldOfStudyNames = listOffieldOfStudy.stream().map(fieldOfStudy -> {
			return fieldOfStudy.getFieldOfStudyName();
		}).distinct().collect(Collectors.toList());
		return fieldOfStudyNames;
	}

	@Override
	public CertificateResponseDTO getCertificate() {
		List<Certificate> listOfCertificate = certificateRepository.findAll();
		CertificateResponseDTO certificateResponseDTO = new CertificateResponseDTO();

		List<String> certificateName = listOfCertificate.stream().map(Certificate::getCertificateName).distinct()
				.toList();

		List<String> organizationName = listOfCertificate.stream().map(Certificate::getOrganizationName).distinct()
				.toList();

		certificateResponseDTO.setCertificateName(certificateName);
		certificateResponseDTO.setOrganizationName(organizationName);

		return certificateResponseDTO;
	}
}
