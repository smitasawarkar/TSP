package com.maveric.spectrum.educationms.dtos;

import java.util.List;

import lombok.Data;

@Data
public class CertificateResponseDTO {

	private List<String> certificateName;	
	private List<String> organizationName;
}
