package com.maveric.spectrum.educationms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.educationms.dtos.CertificateResponseDTO;
import com.maveric.spectrum.educationms.service.EducationService;


@RestController
@RequestMapping("/education")
@CrossOrigin
public class EducationController {

	private EducationService educationService;
	
	public EducationController(EducationService educationService) {
		super();
		this.educationService = educationService;
	}

	@GetMapping("/getInstituteName")
	public List<String> getInstituteName() {		
		return educationService.getInstituteName();
	}
	
	@GetMapping("/getDegreeName")
	public List<String> getDegreeName() {
		return educationService.getDegreeName();
	}
	@GetMapping("/getActivityAndSocietyName")
	public List<String> getActivityAndSocietyName() {
		return educationService.getActivityAndSocietyName();
	}
	@GetMapping("/getFieldOfStudyName")
	public List<String> getFieldOfStudyName() {
		return educationService.getFieldOfStudyName();
	}
	@GetMapping("/getCertificateAndIssuingOrgnization")
	public CertificateResponseDTO getCertificateDetails(){
		return educationService.getCertificate();
	}
}