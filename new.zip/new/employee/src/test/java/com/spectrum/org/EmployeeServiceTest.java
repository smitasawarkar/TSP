/*
 * package com.spectrum.org;
 * 
 * import static org.mockito.Mockito.RETURNS_SMART_NULLS; import static
 * org.mockito.Mockito.times;
 * 
 * import java.util.List; import java.util.Optional;
 * 
 * import org.assertj.core.util.Arrays; import org.junit.jupiter.api.Assertions;
 * import org.junit.jupiter.api.BeforeAll; import
 * org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test; import
 * org.mockito.Mockito; import org.springframework.http.ResponseEntity; import
 * org.springframework.web.client.RestTemplate;
 * 
 * import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO; import
 * com.maveric.spectrum.employeems.dtos.EducationRequestDTO; import
 * com.maveric.spectrum.employeems.dtos.EmployeeRequestDTO; import
 * com.maveric.spectrum.employeems.dtos.ProjectExperienceRequestDTO; import
 * com.maveric.spectrum.employeems.dtos.WorkExperienceRequestDTO; import
 * com.maveric.spectrum.employeems.entities.Employee; import
 * com.maveric.spectrum.employeems.entities.EmployeeCertificate; import
 * com.maveric.spectrum.employeems.entities.EmployeeEducation; import
 * com.maveric.spectrum.employeems.entities.ProjectExperience; import
 * com.maveric.spectrum.employeems.entities.Role; import
 * com.maveric.spectrum.employeems.entities.WorkExperience; import
 * com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
 * import
 * com.maveric.spectrum.employeems.repositories.EmployeeCertificateRepository;
 * import
 * com.maveric.spectrum.employeems.repositories.EmployeeEducationRepository;
 * import com.maveric.spectrum.employeems.repositories.EmployeeRepository;
 * import
 * com.maveric.spectrum.employeems.repositories.ProjectExperienceRepository;
 * import com.maveric.spectrum.employeems.repositories.WorkExperienceRepository;
 * import com.maveric.spectrum.employeems.services.EmployeeService; import
 * com.maveric.spectrum.employeems.services.EmployeeServiceImpl; import
 * com.maveric.spectrum.employeems.utils.Util;
 * 
 * class EmployeeServiceTest {
 * 
 * private static EmployeeService employeeService; private static
 * EmployeeCertificateRepository mockCertificateRepository; private static
 * EmployeeRepository mockemployeeRepository; private static
 * ProjectExperienceRepository mockProjectExperienceRepository; private static
 * WorkExperienceRepository mockWorkExperienceRepository; private static
 * EmployeeEducationRepository mockEducationRepository; private static Util
 * mockUtil; private static RestTemplate mockRestTemplate;
 * 
 * @BeforeAll static void setUptTestEnv() {
 * 
 * mockCertificateRepository=Mockito.mock(EmployeeCertificateRepository.class);
 * mockemployeeRepository=Mockito.mock(EmployeeRepository.class);
 * mockProjectExperienceRepository=Mockito.mock(ProjectExperienceRepository.
 * class);
 * mockWorkExperienceRepository=Mockito.mock(WorkExperienceRepository.class);
 * mockEducationRepository=Mockito.mock(EmployeeEducationRepository.class);
 * mockUtil=Mockito.mock(Util.class);
 * mockRestTemplate=Mockito.mock(RestTemplate.class); // employeeService=new
 * EmployeeServiceImpl(mockCertificateRepository,mockemployeeRepository,
 * mockProjectExperienceRepository,mockWorkExperienceRepository,mockRestTemplate
 * ,mockUtil,mockEducationRepository); }
 * 
 * @BeforeEach void setUpTestMockDataEnv() {
 * Mockito.when(mockemployeeRepository.findById(2)).thenReturn(Optional.
 * ofNullable(null)); WorkExperience workExperience=new WorkExperience(
 * 56,"SDE1-Think Nxt","Maveric Systems Limited","Aug 2023"
 * ,"present","Chennai, Tamil Nadu, India",new
 * Employee(),"Part Time","IT","Remote",true,null); ProjectExperience
 * projectExperience=new ProjectExperience(56,
 * "Network Cloud and Inventory Exposure", "IC", "description1",
 * "responsibilty1", "Mar 2023", "Jun 2023", "Wipro", "Maverick", new
 * Employee(), null); EmployeeCertificate certificate=new
 * EmployeeCertificate(56, "AWS associate Solution Architect certificate",
 * "AWS", "June 26,2020", "June 27,2023", "674590871A", "firstURL", new
 * Employee(), null); EmployeeEducation education=new EmployeeEducation(4,
 * "Master of Business Administration - MBA",
 * "Modern education Society’s College of Engineering", "Kochi", "2016", "2020",
 * 8.64, "Computer Science", null, new Employee(), null); Employee employee=new
 * Employee(1, "Prem Kumar", "Sinha", "Praveen", "prems@maveric-systems.com",
 * "SDE1", "This is a small description about me", Role.USER,null, null, null,
 * null, null);
 * Mockito.when(mockemployeeRepository.findById(1)).thenReturn(Optional.of(
 * employee)); }
 * 
 * @Test void testEmployeeDetailsNotFound() {
 * Assertions.assertThrows(EmployeeDetailsNotFoundException.class, ()->
 * employeeService.getEmployeeById(2)); Mockito.verify(mockemployeeRepository
 * ,times(1)).findById(2); }
 * 
 * @Test void testGetEmloyeeById() throws EmployeeDetailsNotFoundException {
 * Employee expectedEmployee=new Employee(1, "Prem Kumar", "Sinha", "Praveen",
 * "prems@maveric-systems.com", "SDE1", "This is a small description about me",
 * Role.USER,null, null, null, null, null); Employee
 * actualEmployee=employeeService.getEmployeeById(1);
 * Assertions.assertEquals(expectedEmployee, actualEmployee); // == || equals()
 * ----> Mockito.verify(mockemployeeRepository ,times(1)).findById(1); }
 * 
 * void testAddEmployeeDetails() throws EmployeeDetailsNotFoundException {
 * CertificateRequestDTO certificateRequestDTO=new
 * CertificateRequestDTO("AWS associate Solution Architect certificate", "AWS",
 * "June 26,2020", "June 27,2023", "674590871A"); EducationRequestDTO
 * educationRequestDTO=new
 * EducationRequestDTO("Modern education Society’s College of Engineering",
 * "2016", "2020", "Master of Business Administration - MBA", 8.64);
 * ProjectExperienceRequestDTO projectExperienceRequestDTO=new
 * ProjectExperienceRequestDTO("Network Cloud and Inventory Exposure", "IC",
 * "description1", "responsibility1", "Mar 2023", "Jun 2023");
 * WorkExperienceRequestDTO workExperienceRequestDTO=new
 * WorkExperienceRequestDTO("SDE1-Think Nxt", "Maveric Systems Limited",
 * "Chennai, Tamil Nadu, India", "Aug 2023", "present"); EmployeeRequestDTO
 * employeeRequestDTO=new
 * EmployeeRequestDTO(List.of("Java","Python"),List.of(educationRequestDTO),
 * List.of(certificateRequestDTO), List.of(workExperienceRequestDTO),
 * List.of(projectExperienceRequestDTO)); String
 * expectedResponse="Employee details successfully saved";
 * ResponseEntity<String>
 * actualResponse=employeeService.addEmployeeDetails(employeeRequestDTO); } }
 */