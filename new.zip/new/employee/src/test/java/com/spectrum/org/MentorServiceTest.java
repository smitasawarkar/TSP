package com.spectrum.org;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Pageable;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.employeems.dtos.MentorCountResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorDataResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorResponseDTO;
import com.maveric.spectrum.employeems.dtos.SkillDTO;
import com.maveric.spectrum.employeems.dtos.SkillResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;
import com.maveric.spectrum.employeems.repositories.EmployeeRepository;
import com.maveric.spectrum.employeems.repositories.EmployeeSkillEntryRepository;
import com.maveric.spectrum.employeems.services.MentorServiceImpl;
import com.maveric.spectrum.employeems.utils.Util;

public class MentorServiceTest {

	@InjectMocks
	private MentorServiceImpl mentorService;

	@Mock
	private EmployeeRepository employeeRepository;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private Util util;

	@Mock
	private EmployeeSkillEntryRepository employeeSkillEntryRepository;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testFindMentorsBySkill() throws EmployeeDetailsNotFoundException, NoValidSkillsFoundException {
		String skillName = "Java";
		List<Integer> skillIds = Arrays.asList(1, 2);
		SkillResponseDTO skillResponseDTO = new SkillResponseDTO(skillIds);

		when(restTemplate.getForObject(any(String.class), any(Class.class))).thenReturn(skillResponseDTO);
		when(employeeSkillEntryRepository.findEmployeesBySkillIds(anyList(), any(Pageable.class)))
				.thenReturn(Arrays.asList(1, 2));

		Employee employee = new Employee(1, "John", "Doe", "Manager", "john.doe@example.com", "Developer", "About me",
				null, Collections.emptyList(), Collections.emptyList(), Collections.emptyList(),
				Collections.emptyList(), Collections.singletonList(new EmployeeSkill(1, "Expert")));

		when(employeeRepository.findEmployeesByEmployeeIds(anyList())).thenReturn(Arrays.asList(employee));
		when(util.toResposeMentorResponseDTO(any(Employee.class))).thenReturn(new MentorResponseDTO(1L, "John", "Doe",
				Arrays.asList("Java"), "About me", "Developer", "image.png", 10, "Senior", 500, 5, true, 4.5f));
		when(util.toResposeMentorMockDTO(any(MentorResponseDTO.class))).thenReturn(new MentorResponseDTO(1L, "John",
				"Doe", Arrays.asList("Java"), "About me", "Developer", "image.png", 10, "Senior", 500, 5, true, 4.5f));

		SkillDTO[] responseSkills = { new SkillDTO(1, "Java", null) };
		when(restTemplate.postForObject(any(String.class), any(), any(Class.class))).thenReturn(responseSkills);

		MentorDataResponseDTO result = mentorService.findMentorsBySkill(skillName, 10, 0);

		assertEquals(1, result.getList().size());
		assertEquals("John", result.getList().get(0).getFirstName());
		verify(employeeRepository).findEmployeesByEmployeeIds(Arrays.asList(1, 2));
	}

	@Test
	public void testFindMentorsCountBySkill() throws NoValidSkillsFoundException, EmployeeDetailsNotFoundException {
		String skillName = "Java";
		List<Integer> skillIds = Arrays.asList(1, 2);
		SkillResponseDTO skillResponseDTO = new SkillResponseDTO(skillIds);

		when(restTemplate.getForObject(any(String.class), any(Class.class))).thenReturn(skillResponseDTO);
		when(employeeSkillEntryRepository.findEmployeesCountBySkillIds(anyList())).thenReturn(Optional.of(5));

		MentorCountResponseDTO result = mentorService.findMentorsCountBySkill(skillName);

		assertEquals(5, result.getTotalCount());
		verify(employeeSkillEntryRepository).findEmployeesCountBySkillIds(Arrays.asList(1, 2));
	}

	@Test
	public void testFindMentorsBySkillThrowsNoValidSkillsFoundException() {
		String skillName = "Unknown";
		SkillResponseDTO skillResponseDTO = new SkillResponseDTO(Collections.emptyList());

		when(restTemplate.getForObject(any(String.class), any(Class.class))).thenReturn(skillResponseDTO);

		assertThrows(NoValidSkillsFoundException.class, () -> {
			mentorService.findMentorsBySkill(skillName, 10, 0);
		});
	}

	@Test
	public void testFindMentorsCountBySkillThrowsNoValidSkillsFoundException() {
		String skillName = "Unknown";
		SkillResponseDTO skillResponseDTO = new SkillResponseDTO(Collections.emptyList());

		when(restTemplate.getForObject(any(String.class), any(Class.class))).thenReturn(skillResponseDTO);

		assertThrows(NoValidSkillsFoundException.class, () -> {
			mentorService.findMentorsCountBySkill(skillName);
		});
	}

	@Test
	public void testGetEmployeeSkill() throws EmployeeDetailsNotFoundException {
		// Mocking data
		Employee employee = new Employee();
		List<EmployeeSkill> employeeSkills = new ArrayList<>();
		employeeSkills.add(new EmployeeSkill(1, "Intermediate"));
		employeeSkills.add(new EmployeeSkill(2, "Expert"));
		employee.setEmployeeSkills(employeeSkills);

		SkillDTO[] responseSkills = { new SkillDTO(1, "Java", null), new SkillDTO(2, "Spring Boot", null) };

		List<String> expectedSkills = Arrays.asList("Java", "Spring Boot");

		// Mocking behavior
		when(restTemplate.postForObject(any(String.class), any(), any(Class.class))).thenReturn(responseSkills);
		when(util.mapSkills(any(List.class))).thenReturn(expectedSkills);

		// Method invocation
		List<String> actualSkills = mentorService.getEmployeeSkill(employee);

		// Assertion
		assertEquals(expectedSkills, actualSkills);
	}
}
