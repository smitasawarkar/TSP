//package com.spectrum.org;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO;
//import com.maveric.spectrum.employeems.dtos.EmployeeCertificateResponseDTO;
//import com.maveric.spectrum.employeems.entities.Employee;
//import com.maveric.spectrum.employeems.entities.EmployeeCertificate;
//import com.maveric.spectrum.employeems.exceptions.EmployeeCertificateDetailsNotFoundException;
//import com.maveric.spectrum.employeems.repositories.EmployeeCertificateRepository;
//import com.maveric.spectrum.employeems.services.EmployeeCertificateServiceImpl;
//import com.maveric.spectrum.employeems.utils.Util;
//
//@ExtendWith(MockitoExtension.class)
//public class CertificateServiceTest {
//	
//	@Mock
//    private EmployeeCertificateRepository employeeCertificateRepository;
//
//    @Mock
//    private Util util;
//
//    @InjectMocks
//    private EmployeeCertificateServiceImpl employeeCertificateService;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    @Test
//    void testGetEmployeeCertificateById() throws EmployeeCertificateDetailsNotFoundException {
//        EmployeeCertificate certificate = new EmployeeCertificate();
//        certificate.setId(1);
//        when(employeeCertificateRepository.findById(1)).thenReturn(Optional.of(certificate));
//
//        EmployeeCertificate result = employeeCertificateService.getEmployeeCertificateById(1);
//
//        assertEquals(certificate.getId(), result.getId());
//    }
//
//    @Test
//    void testGetEmployeeCertificateById_NotFound() {
//        when(employeeCertificateRepository.findById(1)).thenReturn(Optional.empty());
//
//        assertThrows(EmployeeCertificateDetailsNotFoundException.class, () -> {
//            employeeCertificateService.getEmployeeCertificateById(1);
//        });
//    }
//
//    @Test
//    void testDeleteEmployeeCertificateById() throws EmployeeCertificateDetailsNotFoundException {
//        EmployeeCertificate certificate = new EmployeeCertificate();
//        certificate.setId(1);
//        when(employeeCertificateRepository.findById(1)).thenReturn(Optional.of(certificate));
//
//        ResponseEntity<String> response = employeeCertificateService.deleteEmployeeCertificateById(1);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("Employee certificate details deleted successfully for id: 1", response.getBody());
//        verify(employeeCertificateRepository, times(1)).deleteById(1);
//    }
//
//    @Test
//    void testDeleteEmployeeCertificateById_NotFound() {
//        when(employeeCertificateRepository.findById(1)).thenReturn(Optional.empty());
//
//        assertThrows(EmployeeCertificateDetailsNotFoundException.class, () -> {
//            employeeCertificateService.deleteEmployeeCertificateById(1);
//        });
//    }
//
//
//    
//    @Test
//    public void testAddAllEmployeeCertificates() {
//        // Given
//        Employee employee = new Employee();
//        CertificateRequestDTO certificateDTO1 = new CertificateRequestDTO();
//        CertificateRequestDTO certificateDTO2 = new CertificateRequestDTO();
//        List<CertificateRequestDTO> certificates = Arrays.asList(certificateDTO1, certificateDTO2);
//        EmployeeCertificate certificate1 = new EmployeeCertificate();
//        EmployeeCertificate certificate2 = new EmployeeCertificate();
//        certificate1.setCertificationName("google");
//        certificate1.setCredentialId("1234");
//        certificate1.setCredentialURL("http");
//        certificate1.setEmployee(new Employee());
//        certificate1.setExpirationDate("1234");
//        certificate1.setId(1);
//        certificate1.setIssuingDate("3456");
//        certificate1.setIssuingOrganization("google");
//        certificate1.setSkillIds(new ArrayList<Integer>());
//        
//        certificate2.setCertificationName("google");
//        certificate2.setCredentialId("1234");
//        certificate2.setCredentialURL("http");
//        certificate2.setEmployee(new Employee());
//        certificate2.setExpirationDate("1234");
//        certificate2.setId(1);
//        certificate2.setIssuingDate("3456");
//        certificate2.setIssuingOrganization("google");
//        certificate2.setSkillIds(new ArrayList<Integer>());
//        
//        certificateDTO1.setCertificationName("google");
//        certificateDTO1.setCredentialId("1234");
//        certificateDTO1.setExpirationDate("1234");
//        certificateDTO1.setIssuingDate("3456");
//        certificateDTO1.setIssuingOrganization("google");
//        
//        certificateDTO2.setCertificationName("google");
//        certificateDTO2.setCredentialId("1234");
//        certificateDTO2.setExpirationDate("1234");
//        certificateDTO2.setIssuingDate("3456");
//        certificateDTO2.setIssuingOrganization("google");
//        
//        // Stubbing
//        when(util.toCertificateRequest(certificateDTO1)).thenReturn(certificate1);
//        when(util.toCertificateRequest(certificateDTO2)).thenReturn(certificate2);
//
//        // When
//        employeeCertificateService.addAllEmployeeCertificates(certificates, employee);
//
//        // Then
//        verify(util, times(2)).toCertificateRequest(certificateDTO1);
//        verify(util, times(2)).toCertificateRequest(certificateDTO2);
//        verify(employeeCertificateRepository, times(2)).save(certificate1);
//        verify(employeeCertificateRepository, times(2)).save(certificate2);
//        // Additional assertions if needed
//    }
//    
//    @Test
//    public void testUpdateAllEmployeeCertificates() {
//        // Given
//        Employee employee = new Employee();
//        EmployeeCertificateResponseDTO certificateDTO1 = new EmployeeCertificateResponseDTO();
//        EmployeeCertificateResponseDTO certificateDTO2 = new EmployeeCertificateResponseDTO();
//        List<EmployeeCertificateResponseDTO> certificates = Arrays.asList(certificateDTO1, certificateDTO2);
//        EmployeeCertificate certificate1 = new EmployeeCertificate();
//        EmployeeCertificate certificate2 = new EmployeeCertificate();
//        certificate1.setCertificationName("google");
//        certificate1.setCredentialId("1234");
//        certificate1.setCredentialURL("http");
//        certificate1.setEmployee(new Employee());
//        certificate1.setExpirationDate("1234");
//        certificate1.setId(1);
//        certificate1.setIssuingDate("3456");
//        certificate1.setIssuingOrganization("google");
//        certificate1.setSkillIds(new ArrayList<Integer>());
//        
//        certificate2.setCertificationName("google");
//        certificate2.setCredentialId("1234");
//        certificate2.setCredentialURL("http");
//        certificate2.setEmployee(new Employee());
//        certificate2.setExpirationDate("1234");
//        certificate2.setId(1);
//        certificate2.setIssuingDate("3456");
//        certificate2.setIssuingOrganization("google");
//        certificate2.setSkillIds(new ArrayList<Integer>());
//        
//        
//        certificateDTO1.setCertificationName("google");
//        certificateDTO1.setCredentialId("1234");
//        certificateDTO1.setCredentialURL("http");
//        certificateDTO1.setExpirationDate("1234");
//        certificateDTO1.setId(1);
//        certificateDTO1.setIssuingDate("3456");
//        certificateDTO1.setIssuingOrganization("google");
//        certificateDTO1.setSkillIds(new ArrayList<Integer>());
//       
//        
//        certificateDTO2.setCertificationName("google");
//        certificateDTO2.setCredentialId("1234");
//        certificateDTO2.setCredentialURL("http");
//        certificateDTO2.setExpirationDate("1234");
//        certificateDTO2.setId(1);
//        certificateDTO2.setIssuingDate("3456");
//        certificateDTO2.setIssuingOrganization("google");
//        certificateDTO2.setSkillIds(new ArrayList<Integer>());
//        
//        
//        // Stubbing
//        when(util.toUpdateEmployeeCertificate(certificateDTO1)).thenReturn(certificate1);
//        when(util.toUpdateEmployeeCertificate(certificateDTO2)).thenReturn(certificate2);
//
//        // When
//        employeeCertificateService.updateAllEmployeeCertificates(certificates, employee);
//
//        // Then
//        verify(util, times(2)).toUpdateEmployeeCertificate(certificateDTO1);
//        verify(util, times(2)).toUpdateEmployeeCertificate(certificateDTO2);
//        verify(employeeCertificateRepository, times(2)).save(certificate1);
//        verify(employeeCertificateRepository, times(2)).save(certificate2);
//        // Additional assertions if needed
//    }
//
//
//    
//
//}
