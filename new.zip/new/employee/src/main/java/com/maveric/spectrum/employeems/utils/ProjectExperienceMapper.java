package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.ProjectExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.ProjectExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.ProjectExperience;

@Mapper(componentModel = "spring")
public interface ProjectExperienceMapper {
	
	@Mapping(target = "id",ignore = true)
	@Mapping(target = "clientName",ignore = true)
	@Mapping(target = "companyName",ignore = true)
	@Mapping(target = "employee",ignore = true)
	@Mapping(target = "skillIds",ignore = true)
	ProjectExperience toRequest(ProjectExperienceRequestDTO projectExperienceRequestDTO);
	
@Mapping(target = "employee",ignore = true)
	ProjectExperience toUpdate(ProjectExperienceResponseDTO projectExperienceResponseDTO);

//	ProjectExperienceResponseDTO toGet(ProjectExperience projectExperience);

}
