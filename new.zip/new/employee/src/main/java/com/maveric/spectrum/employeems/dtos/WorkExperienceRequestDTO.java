package com.maveric.spectrum.employeems.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WorkExperienceRequestDTO {
	
	private String jobTitle,companyName,location,startDate,endDate;

}
