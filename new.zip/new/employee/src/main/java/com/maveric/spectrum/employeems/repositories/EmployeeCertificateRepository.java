package com.maveric.spectrum.employeems.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.spectrum.employeems.entities.EmployeeCertificate;

public interface EmployeeCertificateRepository extends JpaRepository<EmployeeCertificate, Integer> {

}
