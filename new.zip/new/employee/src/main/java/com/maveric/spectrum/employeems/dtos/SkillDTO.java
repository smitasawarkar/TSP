package com.maveric.spectrum.employeems.dtos;
 
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SkillDTO {
	private Integer skillId;
 
	private String skillName;
 
	private List<SkillClusterDTO> skillClusterDTO;
 
}