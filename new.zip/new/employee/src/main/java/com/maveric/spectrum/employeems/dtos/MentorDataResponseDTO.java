package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import com.maveric.spectrum.employeems.entities.Employee;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MentorDataResponseDTO {

	private List<MentorResponseDTO> list;
	 private int currentPage ;
	 private int from ;
	 private int to ;
}
