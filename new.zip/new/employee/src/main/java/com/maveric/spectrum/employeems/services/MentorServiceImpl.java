package com.maveric.spectrum.employeems.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.employeems.dtos.MentorCountResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorDataResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorResponseDTO;
import com.maveric.spectrum.employeems.dtos.SkillDTO;
import com.maveric.spectrum.employeems.dtos.SkillResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;
import com.maveric.spectrum.employeems.repositories.EmployeeRepository;
import com.maveric.spectrum.employeems.repositories.EmployeeSkillEntryRepository;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class MentorServiceImpl implements MentorService {

	private EmployeeRepository repository;
	private RestTemplate restTemplate;
	private Util util;

	private EmployeeSkillEntryRepository employeeSkillRepository;

	@Value("${myapp.urls.api.skillclusterms}")
	private String skillClusterURL;

	public MentorServiceImpl(EmployeeRepository repository, RestTemplate restTemplate, Util util,
							 EmployeeSkillEntryRepository employeeSkillRepository) {
		this.repository = repository;
		this.restTemplate = restTemplate;
		this.util = util;
		this.employeeSkillRepository = employeeSkillRepository;
	}

	@Override
	public MentorDataResponseDTO findMentorsBySkill(String skillName, int perPage, int currentPage)
			throws EmployeeDetailsNotFoundException,NoValidSkillsFoundException {
		List<Integer> skillIdsList = getSkillIds(skillName);
//		int offset = (currentPage - 1) * perPage;
//		List<Employee> mentors = repository.findEmployeesBySkillIds(skillIdsList, perPage, offset);

		Pageable pageRequest = PageRequest.of(currentPage,perPage);
		List<Integer> ids = employeeSkillRepository.findEmployeesBySkillIds(skillIdsList,pageRequest);
		List<Employee> employees = repository.findEmployeesByEmployeeIds(ids);

		List<MentorResponseDTO> mentorDTOs = new ArrayList<>();
		for (Employee mentor : employees) {
			List<String> skills = getEmployeeSkill(mentor);
			MentorResponseDTO mentorDTO = util.toResposeMentorResponseDTO(mentor);
			mentorDTO.setSkills(skills);
			mentorDTO=util.toResposeMentorMockDTO(mentorDTO);

			mentorDTOs.add(mentorDTO);
		}

		MentorDataResponseDTO mentorDataResponseDTO = new MentorDataResponseDTO();
		mentorDataResponseDTO.setList(mentorDTOs);

		return mentorDataResponseDTO;
	}

	@Override
	public MentorCountResponseDTO findMentorsCountBySkill(String skillName) throws NoValidSkillsFoundException,EmployeeDetailsNotFoundException {
		List<Integer> skillIdsList = getSkillIds(skillName);
		Integer count = employeeSkillRepository.findEmployeesCountBySkillIds(skillIdsList).orElseThrow(()->new NoValidSkillsFoundException("No Employees found for mentioned skill : "+skillName));
		
		MentorCountResponseDTO mentorCountResponseDTO = new MentorCountResponseDTO();
		mentorCountResponseDTO.setTotalCount(count);

		return mentorCountResponseDTO;
	}

	public List<Integer> getSkillIds(String skillName) throws NoValidSkillsFoundException {
		SkillResponseDTO skillIds = restTemplate.getForObject(
				skillClusterURL + "/skills_clusterMS/skillIds?skillName=" + skillName, SkillResponseDTO.class);

	    if (skillIds.getSkillId().isEmpty()) {
	        throw new NoValidSkillsFoundException("No valid skills found in the received request");
	    }
	    
		return skillIds.getSkillId();
	}
	


	public List<String> getEmployeeSkill(Employee employee) throws EmployeeDetailsNotFoundException {

		List<Integer> skillIds = new ArrayList<>();
		for (EmployeeSkill employeeSkill : employee.getEmployeeSkills()) {
			skillIds.add(employeeSkill.getSkillId());
		}
		SkillDTO[] responseSkills = restTemplate.postForObject(skillClusterURL + "/skills_clusterMS/getUserSkill",
				skillIds, SkillDTO[].class);
		List<SkillDTO> skillDTOList = new ArrayList<>(Arrays.asList(responseSkills));
		List<String> employeeSkillDTO = util.mapSkills(skillDTOList);

		return employeeSkillDTO;
	}

}
