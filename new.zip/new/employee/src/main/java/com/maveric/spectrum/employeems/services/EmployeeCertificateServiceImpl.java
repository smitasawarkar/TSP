package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeCertificateResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeCertificate;
import com.maveric.spectrum.employeems.exceptions.EmployeeCertificateDetailsNotFoundException;
import com.maveric.spectrum.employeems.repositories.EmployeeCertificateRepository;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class EmployeeCertificateServiceImpl implements EmployeeCertificateService {

	private EmployeeCertificateRepository employeeCertificateRepository;
	private Util util;
	
	public EmployeeCertificateServiceImpl(EmployeeCertificateRepository employeeCertificateRepository,Util util) {
		this.employeeCertificateRepository = employeeCertificateRepository;
		this.util=util;
	}

	@Override
	public EmployeeCertificate getEmployeeCertificateById(Integer id) throws EmployeeCertificateDetailsNotFoundException {
		return employeeCertificateRepository.findById(id).orElseThrow(()->new EmployeeCertificateDetailsNotFoundException("Employee certificate details not found for id: "+id));
	}

	@Override
	public ResponseEntity<String> deleteEmployeeCertificateById(Integer id) throws EmployeeCertificateDetailsNotFoundException {
		getEmployeeCertificateById(id);
		employeeCertificateRepository.deleteById(id);
		return new ResponseEntity<>("Employee certificate details deleted successfully for id: "+id,HttpStatus.OK);
	}

	public void addAllEmployeeCertificates(List<CertificateRequestDTO> certificates,Employee employee)
	{
		for(CertificateRequestDTO certificateDTO:certificates)
		{
			EmployeeCertificate certificate=util.toCertificateRequest(certificateDTO);
			certificate.setEmployee(employee);
			employeeCertificateRepository.save(certificate);
		}
	}

	@Override
	public void updateAllEmployeeCertificates(List<EmployeeCertificateResponseDTO> certificates, Employee employee) {
		
		for(EmployeeCertificateResponseDTO certificateDTO:certificates)
		{
			EmployeeCertificate certificate= util.toUpdateEmployeeCertificate(certificateDTO);
			certificate.setEmployee(employee);
			employeeCertificateRepository.save(certificate);
		}
		}
}
