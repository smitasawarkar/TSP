package com.maveric.spectrum.employeems.repositories;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.maveric.spectrum.employeems.entities.CompositeKey;
import com.maveric.spectrum.employeems.entities.EmployeeSkillEntry;

import jakarta.transaction.Transactional;

public interface EmployeeSkillEntryRepository extends JpaRepository<EmployeeSkillEntry,CompositeKey> {

    @Query("select distinct e.id.empId from EmployeeSkillEntry e where e.id.skillId in :skills")
    List<Integer> findEmployeesBySkillIds(@Param("skills")List<Integer> skillIds, Pageable pageable);

    @Query("select count(DISTINCT e.id.empId) from EmployeeSkillEntry e where e.id.skillId in :skills")
    Optional<Integer> findEmployeesCountBySkillIds(@Param("skills") List<Integer> skillIds);
    
    @Query("SELECT e FROM EmployeeSkillEntry e WHERE e.id.skillId IN :skillIds")
    List<EmployeeSkillEntry> findBySkillIds(@Param("skillIds") List<Integer> skillIds);
    
    @Modifying
    @Transactional
    @Query("DELETE FROM EmployeeSkillEntry e WHERE e.id.skillId IN :skillIds")
    void deleteBySkillIds(@Param("skillIds") Set<Integer> skillIds);
}
