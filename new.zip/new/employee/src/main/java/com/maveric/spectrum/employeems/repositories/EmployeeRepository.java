package com.maveric.spectrum.employeems.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;


import com.maveric.spectrum.employeems.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	@Query("select e from Employee e where e.id in :employees")
	List<Employee> findEmployeesByEmployeeIds(@Param("employees")List<Integer> employeeIds);


	@Query("SELECT e FROM Employee e WHERE e.role = 'Manager'")
    List<Employee> findManagerNamesByRole();
}
