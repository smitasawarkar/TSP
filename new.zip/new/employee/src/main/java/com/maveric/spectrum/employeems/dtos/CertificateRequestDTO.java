package com.maveric.spectrum.employeems.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CertificateRequestDTO {

	private String certificationName,issuingOrganization,issuingDate,expirationDate,credentialId;
}
