package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.employeems.dtos.ProjectExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.ProjectExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.ProjectExperience;
import com.maveric.spectrum.employeems.exceptions.ProjectExperienceDetailsNotFoundException;
import com.maveric.spectrum.employeems.repositories.ProjectExperienceRepository;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class ProjectExperienceServiceImpl implements ProjectExperienceService {

	private ProjectExperienceRepository projectExperienceRepository;
	private Util util;
	
	public ProjectExperienceServiceImpl(ProjectExperienceRepository projectExperienceRepository,Util util) {
		this.projectExperienceRepository = projectExperienceRepository;
		this.util=util;
	}

	@Override
	public ProjectExperience getProjectExperienceById(Integer id) throws ProjectExperienceDetailsNotFoundException {
		return projectExperienceRepository.findById(id).orElseThrow(()-> new ProjectExperienceDetailsNotFoundException("Project experience details not found for id: "+id));
	}

	@Override
	public ResponseEntity<String> deleteProjectExperienceById(Integer id) throws ProjectExperienceDetailsNotFoundException {
		getProjectExperienceById(id);
		projectExperienceRepository.deleteById(id);
		return new ResponseEntity<>("Project Experience successfully deleted for id: "+id,HttpStatus.OK);
	}
	
	public void addAllEmployeeProjectExperiences(List<ProjectExperienceRequestDTO> projectExperiences,Employee employee)
	{
		for(ProjectExperienceRequestDTO projectExperienceDTO:projectExperiences)
		{
			ProjectExperience projectExperience=util.toProjectExperienceRequest(projectExperienceDTO);
			projectExperience.setEmployee(employee);
			projectExperienceRepository.save(projectExperience);
		}
	}

	@Override
	public void updateAllEmployeeProjectExperiences(List<ProjectExperienceResponseDTO> projectExperiences,
			Employee employee) {
		
		for(ProjectExperienceResponseDTO projectExperienceDTO:projectExperiences)
		{
			ProjectExperience projectExperience= util.toUpdateProjectExperience(projectExperienceDTO);
			projectExperience.setEmployee(employee);
			projectExperienceRepository.save(projectExperience);
		}
		
	}

}
