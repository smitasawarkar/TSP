package com.maveric.spectrum.employeems.dtos;
 
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@NoArgsConstructor
public class EmployeeSkillDTO {
	private Integer skillId;
	private String skillName;
	private List<SkillClusterDTO> skillClusterDTO;
	private String proficiency;
}