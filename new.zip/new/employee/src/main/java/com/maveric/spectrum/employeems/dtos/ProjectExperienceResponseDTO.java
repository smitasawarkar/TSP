package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import lombok.Data;

@Data
public class ProjectExperienceResponseDTO {

	private Integer id;
    private String title;
    private String role;
    private String description;
    private String responsibilities;
    private String startDuration;
    private String endDuration;
    private String companyName;
    private String clientName;
    private List<Integer> skillIds;
}
