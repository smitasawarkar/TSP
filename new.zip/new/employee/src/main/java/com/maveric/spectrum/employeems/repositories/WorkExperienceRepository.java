package com.maveric.spectrum.employeems.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.spectrum.employeems.entities.WorkExperience;

public interface WorkExperienceRepository extends JpaRepository<WorkExperience, Integer> {

}
