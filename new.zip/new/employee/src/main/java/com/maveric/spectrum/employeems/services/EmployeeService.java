package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.employeems.dtos.EmployeeRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeSkillDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeUpdateDTO;
import com.maveric.spectrum.employeems.dtos.ManagerDetailsDTO;
import com.maveric.spectrum.employeems.dtos.MergeSkillDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;

public interface EmployeeService {

	ResponseEntity<String> addEmployeeDetails(EmployeeRequestDTO employeeDTO)throws EmployeeDetailsNotFoundException ;

	ResponseEntity<String> updateEmployeeDetails(EmployeeUpdateDTO employeeUpdateDTO)throws EmployeeDetailsNotFoundException;
	
	Employee getEmployeeById(Integer id) throws EmployeeDetailsNotFoundException ;

	List<EmployeeSkillDTO> getEmployeeSkill() throws EmployeeDetailsNotFoundException;

	List<EmployeeSkill> updateEmployeeSkill(List<EmployeeSkillDTO> employeeSkillDTOs)
			throws EmployeeDetailsNotFoundException, NoValidSkillsFoundException;
	

	List<ManagerDetailsDTO> findManagerNamesByRole();

	EmployeeResponseDTO getEmployeeProfileDetails(Integer id) throws EmployeeDetailsNotFoundException;
	
	void updateMergedSkills(MergeSkillDTO mergedSkillDTO);

}
