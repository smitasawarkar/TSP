package com.maveric.spectrum.employeems.exceptions;

public class EmployeeCertificateDetailsNotFoundException extends Exception{

	public EmployeeCertificateDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeCertificateDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmployeeCertificateDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeCertificateDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmployeeCertificateDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
