package com.maveric.spectrum.employeems.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.employeems.dtos.MentorCountResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorDataResponseDTO;
import com.maveric.spectrum.employeems.services.MentorService;

@RestController
@RequestMapping("/api/spectrum/mentors")
@CrossOrigin("*")
//@EnableDiscoveryClient
@Validated
public class MentorController {

	private MentorService service;

	public MentorController(MentorService service) {
		this.service = service;
	}

//	@GetMapping("/listBySkill")
	@GetMapping("/by/skills")
	public ResponseEntity<MentorDataResponseDTO> getMentorsBySkills(@RequestParam String skillName,
			@RequestParam int perPage, @RequestParam int currentPage) throws Throwable {

		return ResponseEntity.ok(service.findMentorsBySkill(skillName, perPage, currentPage));
	}

//	@GetMapping("/countBySkill")
	@GetMapping("/by/skills/count")
	public ResponseEntity<MentorCountResponseDTO> getMentorCountBySkill(@RequestParam String skillName) throws Throwable {
		return ResponseEntity.ok(service.findMentorsCountBySkill(skillName));
	}
}
