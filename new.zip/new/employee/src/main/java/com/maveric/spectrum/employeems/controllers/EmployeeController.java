package com.maveric.spectrum.employeems.controllers;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.spectrum.employeems.dtos.EmployeeRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeSkillDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeUpdateDTO;
import com.maveric.spectrum.employeems.dtos.ManagerDetailsDTO;
import com.maveric.spectrum.employeems.dtos.MergeSkillDTO;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.exceptions.EmployeeCertificateDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.EmployeeEducationDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;
import com.maveric.spectrum.employeems.exceptions.WorkExperienceDetailsNotFoundException;
import com.maveric.spectrum.employeems.services.EmployeeCertificateService;
import com.maveric.spectrum.employeems.services.EmployeeEducationService;
import com.maveric.spectrum.employeems.services.EmployeeService;
import com.maveric.spectrum.employeems.services.WorkExperienceService;

@RestController
@RequestMapping("/api/spectrum/employee")
@CrossOrigin
public class EmployeeController {
	
	private static final Logger logger = Logger.getLogger(EmployeeController.class.getName());

	private EmployeeService employeeService;
	
	private WorkExperienceService workExperienceService;
	
	private EmployeeEducationService employeeEducationService;
	
	private EmployeeCertificateService employeeCertificateService;
	
	public EmployeeController(EmployeeService employeeService,WorkExperienceService workExperienceService,EmployeeEducationService employeeEducationService,EmployeeCertificateService employeeCertificateService) {
		this.employeeService = employeeService;
		this.workExperienceService=workExperienceService;
		this.employeeEducationService=employeeEducationService;
		this.employeeCertificateService=employeeCertificateService;
	}

	@PostMapping("/add")
	public ResponseEntity<String> saveEmployeeDetails(@RequestBody EmployeeRequestDTO employeeDTO) throws EmployeeDetailsNotFoundException
	{
			return employeeService.addEmployeeDetails(employeeDTO);
	}
	
	@PostMapping("/update")
	public ResponseEntity<String> updateEmployeeDetails(@RequestBody EmployeeUpdateDTO employeeUpdateDTO) throws EmployeeDetailsNotFoundException
	{
			return employeeService.updateEmployeeDetails(employeeUpdateDTO);
	}
	
	@GetMapping("/getEmployeeProfile")
	public ResponseEntity<EmployeeResponseDTO> getEmployeeProfileDetails() throws EmployeeDetailsNotFoundException
	{
		logger.info("logging getEmployeeProfile controller endpoint");
		return new ResponseEntity<>(employeeService.getEmployeeProfileDetails(1),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteWorkExperience/{id}")
	public ResponseEntity<String> deleteWorkExperience(@PathVariable Integer id) throws WorkExperienceDetailsNotFoundException{
		return workExperienceService.deleteWorkExperienceById(id);
	}
	
	@GetMapping("/getEmployeeSkills")
	public ResponseEntity<?> getEmployeeSkill() throws EmployeeDetailsNotFoundException{
			List<EmployeeSkillDTO> employeeSkillDTOs = employeeService.getEmployeeSkill();
			return ResponseEntity.ok(employeeSkillDTOs);
	}
	
	@PostMapping("/updateEmployeeSkills")
	public ResponseEntity<?> updateEmployeeSkills(@RequestBody List<EmployeeSkillDTO> employeeSkillDTOs) throws NoValidSkillsFoundException ,EmployeeDetailsNotFoundException  {
			List<EmployeeSkill> employeeSkills = employeeService.updateEmployeeSkill(employeeSkillDTOs);
			return ResponseEntity.ok(employeeSkills);
	}

	@DeleteMapping("/deleteEducation/{id}")
	public ResponseEntity<String> deleteEducation(@PathVariable Integer id) throws EmployeeEducationDetailsNotFoundException{
		return employeeEducationService.deleteEmployeeEducationById(id);
	}
	
	@DeleteMapping("/deleteCertificate/{id}")
	public ResponseEntity<String> deleteCertificate(@PathVariable Integer id) throws EmployeeCertificateDetailsNotFoundException{
		return employeeCertificateService.deleteEmployeeCertificateById(id);
	}
	
	@GetMapping("/getManagerdetails")
	public List<ManagerDetailsDTO> getManagersDetails() {
    List<ManagerDetailsDTO> managerDetailsDtos = employeeService.findManagerNamesByRole();
     return managerDetailsDtos;
	}
	
	@GetMapping("/getEmployeeProfile/{id}")
	public ResponseEntity<EmployeeResponseDTO> getEmployeeProfileDetails(@PathVariable Integer id) throws EmployeeDetailsNotFoundException
	{		
		return new ResponseEntity<>(employeeService.getEmployeeProfileDetails(id),HttpStatus.OK);
	}
	
	@PostMapping("/mergeEmployeeSkills")
	public void mergeEmployeeSkills(@RequestBody MergeSkillDTO mergedSkillDTO) {
		employeeService.updateMergedSkills(mergedSkillDTO);
	}
	
	
}
