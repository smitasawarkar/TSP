package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import lombok.Data;

@Data
public class EmployeeResponseDTO {

	private Integer id;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String designation;
    private String aboutMe;
    private List<EmployeeEducationResponseDTO> employeeEducations;
    private List<ProjectExperienceResponseDTO> projectExperiences;
    private List<EmployeeCertificateResponseDTO> employeeCertificates;
    private List<EmployeeSkillDTO> employeeSkills;
    private List<WorkExperienceResponseDTO> workExperiences;
}