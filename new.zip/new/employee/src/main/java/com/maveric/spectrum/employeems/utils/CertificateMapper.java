package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeCertificateResponseDTO;
import com.maveric.spectrum.employeems.entities.EmployeeCertificate;

@Mapper(componentModel = "spring")
public interface CertificateMapper {
	
	@Mapping(target = "id",ignore = true)
	@Mapping(target="employee",ignore = true)
	@Mapping(target="skillIds",ignore = true)
	@Mapping(target="credentialURL",ignore = true)
	EmployeeCertificate toRequest(CertificateRequestDTO certificateRequestDTO);
	
	@Mapping(target = "employee",ignore = true)
	EmployeeCertificate toUpdate(EmployeeCertificateResponseDTO employeeCertificateResponseDTO);
	
//	EmployeeCertificateResponseDTO toGet(EmployeeCertificate certificate);

}
