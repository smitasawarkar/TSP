package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.WorkExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.WorkExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.WorkExperience;

@Mapper(componentModel = "spring")
public interface WorkExperienceMapper {

	@Mapping(target = "id",ignore = true)
	@Mapping(target = "employee",ignore = true)
	@Mapping(target = "skillIds",ignore = true)
	@Mapping(target = "employeeType",ignore = true)
	@Mapping(target = "industry",ignore = true)
	@Mapping(target = "isActive",ignore = true)
	@Mapping(target = "locationType",ignore = true)
	WorkExperience toRequest(WorkExperienceRequestDTO workExperienceRequestDTO);
	
	@Mapping(target="employee",ignore = true)
	WorkExperience toUpdate(WorkExperienceResponseDTO workExperienceResponseDTO);
	
//	WorkExperienceResponseDTO toGet(WorkExperience workExperience);
}
