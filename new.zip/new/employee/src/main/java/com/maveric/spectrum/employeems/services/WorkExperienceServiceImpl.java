package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.employeems.dtos.WorkExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.WorkExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.WorkExperience;
import com.maveric.spectrum.employeems.exceptions.WorkExperienceDetailsNotFoundException;
import com.maveric.spectrum.employeems.repositories.WorkExperienceRepository;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class WorkExperienceServiceImpl implements WorkExperienceService {

	private WorkExperienceRepository workExperienceRepository;
	private Util util;
	
	public WorkExperienceServiceImpl(WorkExperienceRepository workExperienceRepository,Util util) {
		this.workExperienceRepository = workExperienceRepository;
		this.util=util;
	}

	@Override
	public WorkExperience getWorkExperienceById(Integer id) throws WorkExperienceDetailsNotFoundException {
		return workExperienceRepository.findById(id).orElseThrow(()->new WorkExperienceDetailsNotFoundException("Work experience details not found for id: "+id)) ;
	}

	@Override
	public ResponseEntity<String> deleteWorkExperienceById(Integer id) throws WorkExperienceDetailsNotFoundException {
		getWorkExperienceById(id);
		workExperienceRepository.deleteById(id);
		return new ResponseEntity<>("Work experience deleted successfully for id: "+id,HttpStatus.OK);
	}

	@Override
	public void addAllEmployeeWorkExperiences(List<WorkExperienceRequestDTO> workExperiences,Employee employee) {
		
		for(WorkExperienceRequestDTO workExperienceDTO:workExperiences)
		{
			WorkExperience workExperience=util.toWorkExperienceRequest(workExperienceDTO);
			workExperience.setEmployee(employee);
			workExperienceRepository.save(workExperience);
		}
	}

	@Override
	public void updateAllEmployeeWorkExperiences(List<WorkExperienceResponseDTO> workExperiences, Employee employee) {
		
		for(WorkExperienceResponseDTO workExperienceDTO:workExperiences)
		{
			WorkExperience workExperience= util.toUpdateWorkExperience(workExperienceDTO);
			workExperience.setEmployee(employee);
			workExperienceRepository.save(workExperience);
		}
		
	}

}
