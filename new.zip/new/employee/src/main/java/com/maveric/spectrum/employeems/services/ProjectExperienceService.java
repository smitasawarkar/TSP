package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.employeems.dtos.ProjectExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.ProjectExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.ProjectExperience;
import com.maveric.spectrum.employeems.exceptions.ProjectExperienceDetailsNotFoundException;

public interface ProjectExperienceService {

	ProjectExperience getProjectExperienceById(Integer id) throws ProjectExperienceDetailsNotFoundException;
	ResponseEntity<String> deleteProjectExperienceById(Integer id) throws ProjectExperienceDetailsNotFoundException;
	void addAllEmployeeProjectExperiences(List<ProjectExperienceRequestDTO> projectExperiences,Employee employee);
	void updateAllEmployeeProjectExperiences(List<ProjectExperienceResponseDTO> projectExperiences,Employee employee);
}
