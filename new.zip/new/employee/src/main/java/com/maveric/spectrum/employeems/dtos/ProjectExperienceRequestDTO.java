package com.maveric.spectrum.employeems.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectExperienceRequestDTO {

	private String title,role,description,responsibilities,startDuration,endDuration;
	
}


