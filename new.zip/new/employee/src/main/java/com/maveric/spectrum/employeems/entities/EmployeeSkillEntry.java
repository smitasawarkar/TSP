package com.maveric.spectrum.employeems.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "employee_skills")
public class EmployeeSkillEntry {

    @EmbeddedId
    private CompositeKey id;

//    @MapsId("skillId")  // This maps the skillId field of the composite key
//    @Column(name="skill_id", insertable = false, updatable = false)
//    private Integer skillId;

    @Column(name="proficiency_level",length = 45)
    private String proficiency;
}
