package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeCertificateResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeCertificate;
import com.maveric.spectrum.employeems.exceptions.EmployeeCertificateDetailsNotFoundException;

public interface EmployeeCertificateService {

	EmployeeCertificate getEmployeeCertificateById(Integer id) throws EmployeeCertificateDetailsNotFoundException;
	ResponseEntity<String> deleteEmployeeCertificateById(Integer id) throws EmployeeCertificateDetailsNotFoundException;
	void addAllEmployeeCertificates(List<CertificateRequestDTO> certificates,Employee employee);
	void updateAllEmployeeCertificates(List<EmployeeCertificateResponseDTO> certificates,Employee employee);
}
