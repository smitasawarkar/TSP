package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.employeems.dtos.ManagerDetailsDTO;
import com.maveric.spectrum.employeems.entities.Employee;

@Mapper(componentModel = "spring")
public interface EmployeeMapper {

	@Mapping(target = "employeeSkills",ignore = true)
	EmployeeResponseDTO toGet(Employee employee);
	
	ManagerDetailsDTO employeeEntityToManagerDetailsDTO(Employee employee);
}
