package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import com.maveric.spectrum.employeems.entities.EmployeeSkill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MentorResponseDTO {

	private Long id;
	private String firstName;
	private String lastName;
	List<String> skills;
	private String aboutMe;
	private String designation;
  private String image;
  private int overallExperience;
  private String level;
	private int mentoringMins;
	private int menteesCount;
	private boolean available;
	//private String status;
	private float rating;
}
