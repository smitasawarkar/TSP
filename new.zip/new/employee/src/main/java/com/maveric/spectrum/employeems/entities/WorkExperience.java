package com.maveric.spectrum.employeems.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name="work_experience")
@NoArgsConstructor
@AllArgsConstructor
public class WorkExperience {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "job_title", length = 50, nullable = false)
	private String jobTitle;
	
	@Column(name = "company_name", length = 50, nullable = false)
	private String companyName;
	
	@Column(name = "start_date", length = 50, nullable = false)
	private String startDate;
	
	@Column(name = "end_date", length = 50, nullable = false)
	private String endDate;
	
	@Column(name = "location", length = 50, nullable = false)
	private String location;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "employee_id",nullable = false)
	private Employee employee;
	
	@Column(name="employee_type")
	private String employeeType;
	
	@Column(name="industry")
	private String industry;
	
	@Column(name="location_type")
	private String locationType;
	
	@Column(name="is_active")
	private Boolean isActive;
	
	@ElementCollection
	@CollectionTable(name = "workexperience_skills")
	private List<Integer> skillIds;

}
