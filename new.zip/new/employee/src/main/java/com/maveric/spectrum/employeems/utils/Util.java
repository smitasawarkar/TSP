package com.maveric.spectrum.employeems.utils;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.maveric.spectrum.employeems.dtos.CertificateRequestDTO;
import com.maveric.spectrum.employeems.dtos.EducationRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeCertificateResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeEducationResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeSkillDTO;
import com.maveric.spectrum.employeems.dtos.MentorResponseDTO;
import com.maveric.spectrum.employeems.dtos.ProjectExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.ProjectExperienceResponseDTO;
import com.maveric.spectrum.employeems.dtos.SkillDTO;
import com.maveric.spectrum.employeems.dtos.WorkExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.WorkExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeCertificate;
import com.maveric.spectrum.employeems.entities.EmployeeEducation;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.entities.ProjectExperience;
import com.maveric.spectrum.employeems.entities.WorkExperience;

@Component
public class Util {

	private CertificateMapper certificateMapper;
	private EducationMapper educationMapper;
	private ProjectExperienceMapper projectExperienceMapper;
	private WorkExperienceMapper workExperienceMapper;
	private EmployeeMapper employeeMapper;
	private EmployeeSkillMapper employeeSkillMapper;
	private MentorMapper mentorMapper;
	
	public Util(CertificateMapper certificateMapper, EducationMapper educationMapper,
			ProjectExperienceMapper projectExperienceMapper, WorkExperienceMapper workExperienceMapper,EmployeeMapper employeeMapper,EmployeeSkillMapper employeeSkillMapper, MentorMapper mentorMapper) {
		super();
		this.certificateMapper = certificateMapper;
		this.educationMapper = educationMapper;
		this.projectExperienceMapper = projectExperienceMapper;
		this.workExperienceMapper = workExperienceMapper;
		this.employeeMapper=employeeMapper;	
		this.employeeSkillMapper=employeeSkillMapper;
		this.mentorMapper = mentorMapper;
	}


	public EmployeeCertificate toCertificateRequest(CertificateRequestDTO certificateRequestDTO)
	{
		return certificateMapper.toRequest(certificateRequestDTO);
	}
	
	public EmployeeEducation toEducationRequest(EducationRequestDTO educationRequestDTO)
	{
		return educationMapper.toRequest(educationRequestDTO);
	}
	
	public ProjectExperience toProjectExperienceRequest(ProjectExperienceRequestDTO projectExperienceRequestDTO)
	{
		return projectExperienceMapper.toRequest(projectExperienceRequestDTO);
	}
	
	public WorkExperience toWorkExperienceRequest(WorkExperienceRequestDTO workExperienceRequestDTO)
	{
		return workExperienceMapper.toRequest(workExperienceRequestDTO);
	}
	
	public EmployeeCertificate toUpdateEmployeeCertificate(EmployeeCertificateResponseDTO employeeCertificateResponseDTO)
	{
		return certificateMapper.toUpdate(employeeCertificateResponseDTO);
	}
	
	public ProjectExperience toUpdateProjectExperience(ProjectExperienceResponseDTO projectExperienceResponseDTO)
	{
		return projectExperienceMapper.toUpdate(projectExperienceResponseDTO);
	}
	
	public EmployeeEducation toUpdateEducation(EmployeeEducationResponseDTO employeeEducationResponseDTO)
	{
		return educationMapper.toUpdate(employeeEducationResponseDTO);
	}
	
	public WorkExperience toUpdateWorkExperience(WorkExperienceResponseDTO workExperienceResponseDTO) {
		return workExperienceMapper.toUpdate(workExperienceResponseDTO);
	}
	
	public MentorResponseDTO toResposeMentorResponseDTO(Employee employee)
	{
		return mentorMapper.toResposeMentor(employee);
	}
	
	public List<String> mapSkills(List<SkillDTO> skills) {
        return skills.stream()
                .map(SkillDTO::getSkillName)
                .collect(Collectors.toList());
    }
	
	public MentorResponseDTO toResposeMentorMockDTO(MentorResponseDTO mentor)
	{
		mentor.setOverallExperience((int) (Math.random() * 40) + 1); // Random int between 1 and 40
		mentor.setLevel("Expert");
		mentor.setMentoringMins((int) (Math.random() * 301) + 100); // Random int between 100 and 400
		mentor.setMenteesCount((int) (Math.random() * 101) + 100); // Random int between 100 and 200
		mentor.setAvailable(Math.random() < 0.7);
		mentor.setRating((float) (Math.round((Math.random() * 4.0 + 1.0) * 2) / 2.0)); // Random float between 1.0 and 5.0

		return mentor;
	}
	
	public EmployeeSkillDTO employeeskillToDTOconversion(EmployeeSkill employeeSkill,SkillDTO skillDTO) {
		return employeeSkillMapper.fromEntitiesTOEmployeeSkillDTO(employeeSkill, skillDTO);
	}
	
	public EmployeeResponseDTO toGetEmployeeResponseDTO(Employee employee)
	{
		return employeeMapper.toGet(employee);
	}
}
