package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRequestDTO {
	
	private List<String> skills;
	private List<EducationRequestDTO> userEducation;
	private List<CertificateRequestDTO> userCertificates;
	private List<WorkExperienceRequestDTO> userWorkExperiences;
	private List<ProjectExperienceRequestDTO> userProjectExperiences;

}