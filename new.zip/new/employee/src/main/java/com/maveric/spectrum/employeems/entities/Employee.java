package com.maveric.spectrum.employeems.entities;

import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name="employee")
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id")
	private Integer id;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="reporting_manager",length = 50,nullable = false)
	private String reportingManager;
	
	@Column(name="email_address",length = 50,nullable = false)
	private String emailAddress;
	
	@Column(name="designation",length = 50,nullable = false)
	private String designation;
	
	@Column(name="about_me",columnDefinition = "TEXT",length = 1000)
	private String aboutMe;
	
	@Enumerated(EnumType.STRING)
	@Column(name="role",nullable = false)
	private Role role;
	
	
	@OneToMany(mappedBy = "employee")	
	private List<EmployeeEducation> employeeEducations;
	
	@OneToMany(mappedBy = "employee")	
	private List<ProjectExperience> projectExperiences;
	
	@OneToMany(mappedBy = "employee")	
	private List<EmployeeCertificate> employeeCertificates;
	
	@OneToMany(mappedBy = "employee")	
	private List<WorkExperience> workExperiences;
	
	
	@ElementCollection
	@CollectionTable(name="employee_skills")
	private List<EmployeeSkill> employeeSkills;


}
