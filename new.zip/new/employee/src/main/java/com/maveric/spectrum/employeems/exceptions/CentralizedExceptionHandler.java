package com.maveric.spectrum.employeems.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class CentralizedExceptionHandler {

	@ExceptionHandler(EmployeeDetailsNotFoundException.class)
	public ResponseEntity<String> handleEmployeeDetailsNotFound(EmployeeDetailsNotFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(EmployeeCertificateDetailsNotFoundException.class)
	public ResponseEntity<String> handleEmployeeCertificateDetailsNotFound(EmployeeCertificateDetailsNotFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(EmployeeEducationDetailsNotFoundException.class)
	public ResponseEntity<String> handleEmployeeEducationDetailsNotFound(EmployeeEducationDetailsNotFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(ProjectExperienceDetailsNotFoundException.class)
	public ResponseEntity<String> handleProjectExperienceDetailsNotFound(ProjectExperienceDetailsNotFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(WorkExperienceDetailsNotFoundException.class)
	public ResponseEntity<String> handleWorkExperienceDetailsNotFound(WorkExperienceDetailsNotFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(NoValidSkillsFoundException.class)
	public ResponseEntity<String> handleNoValidSkillsFound(NoValidSkillsFoundException exception)
	{
		return new ResponseEntity<>(exception.getMessage(),HttpStatus.NOT_FOUND);
	}
	
}
