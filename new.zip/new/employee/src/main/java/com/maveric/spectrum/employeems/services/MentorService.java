package com.maveric.spectrum.employeems.services;

import jakarta.validation.constraints.Min;
import org.hibernate.validator.constraints.Length;
import org.springframework.validation.annotation.Validated;

import com.maveric.spectrum.employeems.dtos.MentorCountResponseDTO;
import com.maveric.spectrum.employeems.dtos.MentorDataResponseDTO;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;

@Validated
public interface MentorService {

	MentorDataResponseDTO findMentorsBySkill(@Length(min = 2, max = 10) String skill, @Min(1) int perPage, @Min(0) int currentPage) throws EmployeeDetailsNotFoundException,NoValidSkillsFoundException ;

	MentorCountResponseDTO findMentorsCountBySkill(@Length(min = 2, max = 10)  String skillName)throws NoValidSkillsFoundException,EmployeeDetailsNotFoundException;
}
