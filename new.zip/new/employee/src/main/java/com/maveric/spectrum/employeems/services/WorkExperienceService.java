package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.employeems.dtos.WorkExperienceRequestDTO;
import com.maveric.spectrum.employeems.dtos.WorkExperienceResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.WorkExperience;
import com.maveric.spectrum.employeems.exceptions.WorkExperienceDetailsNotFoundException;

public interface WorkExperienceService {
	WorkExperience getWorkExperienceById(Integer id) throws WorkExperienceDetailsNotFoundException;
	ResponseEntity<String> deleteWorkExperienceById(Integer id) throws WorkExperienceDetailsNotFoundException;
	void addAllEmployeeWorkExperiences(List<WorkExperienceRequestDTO> workExperiences,Employee employee);
	void updateAllEmployeeWorkExperiences(List<WorkExperienceResponseDTO> workExperiences,Employee employee);

}
