package com.maveric.spectrum.employeems.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "employee_certificate")
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeCertificate {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id")
	private Integer id;

	@Column(name = "certification_name", length = 50, nullable = false)
	private String certificationName;
	
	@Column(name = "issuing_organization", length = 50, nullable = false)
	private String issuingOrganization;
	
	@Column(name = "issuing_date", nullable = false)
	private String issuingDate;
	
	@Column(name = "expiration_date", nullable = false)
	private String expirationDate;
	
	@Column(name = "credential_id")
	private String credentialId;

	@Column(name="credential_url")
	private String credentialURL;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "employee_id",nullable = false)
	private Employee employee;
	
	@ElementCollection
	@CollectionTable(name = "certificate_skills")
	private List<Integer> skillIds;
}
