package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.maveric.spectrum.employeems.dtos.EducationRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeEducationResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeEducation;
import com.maveric.spectrum.employeems.exceptions.EmployeeEducationDetailsNotFoundException;

public interface EmployeeEducationService {

	EmployeeEducation getEmployeeEducationById(Integer id) throws EmployeeEducationDetailsNotFoundException;
	ResponseEntity<String> deleteEmployeeEducationById(Integer id) throws EmployeeEducationDetailsNotFoundException;
	void addAllEmployeeEducations(List<EducationRequestDTO> educations,Employee employee);
	void updateAllEmployeeEducations(List<EmployeeEducationResponseDTO> educations,Employee employee);
}
