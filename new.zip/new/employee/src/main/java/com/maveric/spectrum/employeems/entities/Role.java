package com.maveric.spectrum.employeems.entities;

public enum Role {

	USER,
	MANAGER,
	SUPERUSER
}
