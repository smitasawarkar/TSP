package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.EducationRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeEducationResponseDTO;
import com.maveric.spectrum.employeems.entities.EmployeeEducation;


@Mapper(componentModel = "spring")
public interface EducationMapper {

	@Mapping(target = "id",ignore = true)
	@Mapping(target = "place",ignore = true)
	@Mapping(target = "employee",ignore = true)
	@Mapping(target = "skillIds",ignore = true)
	@Mapping(target = "activitiesAndSocieties",ignore = true)
	@Mapping(target = "fieldOfStudy",ignore = true)
	EmployeeEducation toRequest(EducationRequestDTO educationRequestDTO);
	
	@Mapping(target = "employee",ignore = true)
	EmployeeEducation toUpdate(EmployeeEducationResponseDTO educationResponseDTO);
	
//	EmployeeEducationResponseDTO toGet(EmployeeEducation employeeEducation);
}
