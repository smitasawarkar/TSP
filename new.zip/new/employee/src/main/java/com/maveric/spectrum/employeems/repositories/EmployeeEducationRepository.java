package com.maveric.spectrum.employeems.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maveric.spectrum.employeems.entities.EmployeeEducation;

public interface EmployeeEducationRepository extends JpaRepository<EmployeeEducation, Integer>{

}
