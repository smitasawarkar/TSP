package com.maveric.spectrum.employeems.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@Table(name="employee_education")
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeEducation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id")
	private Integer id; 
	@Column(name="education_title",length = 50,nullable = false)
	private String educationTitle;
	@Column(name="institute_name",length = 50,nullable = false)
	private String instituteName;
	@Column(name="place",length = 50)
	private String place;
	@Column(name="start_duration",nullable = false)
	private String startDuration;
	@Column(name="end_duration",nullable = false)
	private String endDuration;
	@Column(name="score",nullable = false)
	private Double score;
	
	@Column(name="field_of_study")
	private String fieldOfStudy;
	
	@ElementCollection
	@CollectionTable(name="education_activities")
	private List<String> activitiesAndSocieties;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "employee_id",nullable = false)
	private Employee employee;
	
	@ElementCollection
	@CollectionTable(name="education_skills")
	private List<Integer> skillIds;

	
}
