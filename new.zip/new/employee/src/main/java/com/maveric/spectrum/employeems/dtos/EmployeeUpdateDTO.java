package com.maveric.spectrum.employeems.dtos;

import java.util.List;

import com.maveric.spectrum.employeems.entities.EmployeeSkill;

import lombok.Data;

@Data
public class EmployeeUpdateDTO {
	
	private String aboutMe;
	private List<EmployeeEducationResponseDTO> employeeEducations;
    private List<ProjectExperienceResponseDTO> projectExperiences;
    private List<EmployeeCertificateResponseDTO> employeeCertificates;
    private List<EmployeeSkill> employeeSkills;
    private List<WorkExperienceResponseDTO> workExperiences;

}
