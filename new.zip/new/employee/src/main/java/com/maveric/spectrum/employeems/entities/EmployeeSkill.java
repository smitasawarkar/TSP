package com.maveric.spectrum.employeems.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeSkill {

	@Column(name="skill_id",nullable = false)
	private Integer skillId;
	@Column(name="proficiency_level",length = 45)
	private String proficiency;
}
