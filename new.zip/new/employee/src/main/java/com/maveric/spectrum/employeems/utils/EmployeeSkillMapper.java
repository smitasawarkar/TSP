package com.maveric.spectrum.employeems.utils;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.maveric.spectrum.employeems.dtos.EmployeeSkillDTO;
import com.maveric.spectrum.employeems.dtos.SkillDTO;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;

@Mapper(componentModel = "spring")
public interface EmployeeSkillMapper {
	
	@Mapping(source="employeeSkill.skillId",target="skillId")
	//@Mapping(source="skillDTO.skillId",target="skillId")
	EmployeeSkillDTO fromEntitiesTOEmployeeSkillDTO(EmployeeSkill employeeSkill,SkillDTO skillDTO);
	
}
