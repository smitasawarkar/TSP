package com.maveric.spectrum.employeems.services;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.maveric.spectrum.employeems.dtos.EducationRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeEducationResponseDTO;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeEducation;
import com.maveric.spectrum.employeems.exceptions.EmployeeEducationDetailsNotFoundException;
import com.maveric.spectrum.employeems.repositories.EmployeeEducationRepository;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class EmployeeEducationServiceImpl implements EmployeeEducationService {

	private EmployeeEducationRepository employeeEducationRepository;
	private Util util;
	
	
	public EmployeeEducationServiceImpl(EmployeeEducationRepository employeeEducationRepository,Util util) {
		this.employeeEducationRepository = employeeEducationRepository;
		this.util=util;
	}

	@Override
	public EmployeeEducation getEmployeeEducationById(Integer id) throws EmployeeEducationDetailsNotFoundException {
		return employeeEducationRepository.findById(id).orElseThrow(()->new EmployeeEducationDetailsNotFoundException("Employee education not found for id: "+id));
	}

	@Override
	public ResponseEntity<String> deleteEmployeeEducationById(Integer id)throws EmployeeEducationDetailsNotFoundException {
		getEmployeeEducationById(id);
		employeeEducationRepository.deleteById(id);
		return new ResponseEntity<>("Employee education successfully deleted for id: "+id,HttpStatus.OK);
	}

	@Override
	public void addAllEmployeeEducations(List<EducationRequestDTO> educations, Employee employee) {
		
		for(EducationRequestDTO educationDTO:educations)
		{
			EmployeeEducation employeeEducation=util.toEducationRequest(educationDTO);
			employeeEducation.setEmployee(employee);
			employeeEducationRepository.save(employeeEducation);
		}
		}

	@Override
	public void updateAllEmployeeEducations(List<EmployeeEducationResponseDTO> educations, Employee employee) {
		
		for(EmployeeEducationResponseDTO educationDTO:educations)
		{
			EmployeeEducation education= util.toUpdateEducation(educationDTO);
			education.setEmployee(employee);
			employeeEducationRepository.save(education);
		}
		
	}

}
