package com.maveric.spectrum.employeems.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.maveric.spectrum.employeems.dtos.EmployeeRequestDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeResponseDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeSkillDTO;
import com.maveric.spectrum.employeems.dtos.EmployeeUpdateDTO;
import com.maveric.spectrum.employeems.dtos.ManagerDetailsDTO;
import com.maveric.spectrum.employeems.dtos.MergeSkillDTO;
import com.maveric.spectrum.employeems.dtos.SkillDTO;
import com.maveric.spectrum.employeems.dtos.SkillMergeResquestDTO;
import com.maveric.spectrum.employeems.entities.CompositeKey;
import com.maveric.spectrum.employeems.entities.Employee;
import com.maveric.spectrum.employeems.entities.EmployeeSkill;
import com.maveric.spectrum.employeems.entities.EmployeeSkillEntry;
import com.maveric.spectrum.employeems.exceptions.EmployeeDetailsNotFoundException;
import com.maveric.spectrum.employeems.exceptions.NoValidSkillsFoundException;
import com.maveric.spectrum.employeems.repositories.EmployeeRepository;
import com.maveric.spectrum.employeems.repositories.EmployeeSkillEntryRepository;
import com.maveric.spectrum.employeems.utils.EmployeeMapper;
import com.maveric.spectrum.employeems.utils.Util;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeCertificateService employeeCertificateService;
	private EmployeeRepository employeeRepository;
	private ProjectExperienceService projectExperienceService;
	private WorkExperienceService workExperienceService;
	private EmployeeEducationService employeeEducationService;
	private RestTemplate restTemplate;
	private Util util;
	private EmployeeMapper employeeMapper;
	private EmployeeSkillEntryRepository employeeSkillEntryRepository;
	
	@Value("${myapp.urls.api.skillclusterms}")
	private String skillClusterURL;
	
	//injecting objects using constructor injection
	public EmployeeServiceImpl(EmployeeCertificateService employeeCertificateService,
			EmployeeRepository employeeRepository, ProjectExperienceService projectExperienceService,
			WorkExperienceService workExperienceService, EmployeeEducationService employeeEducationService,
			RestTemplate restTemplate, Util util,EmployeeMapper employeeMapper,EmployeeSkillEntryRepository employeeSkillEntryRepository) {
		super();
		this.employeeCertificateService = employeeCertificateService;
		this.employeeRepository = employeeRepository;
		this.projectExperienceService = projectExperienceService;
		this.workExperienceService = workExperienceService;
		this.employeeEducationService = employeeEducationService;
		this.restTemplate = restTemplate;
		this.util = util;
		this.employeeMapper = employeeMapper;
		this.employeeSkillEntryRepository = employeeSkillEntryRepository;
	}

	//adding employee details after resume parsing
	@Override
	public ResponseEntity<String> addEmployeeDetails(EmployeeRequestDTO employeeDTO) throws EmployeeDetailsNotFoundException {
		Employee employee=getEmployeeById(1);
		
		if(employeeDTO.getUserCertificates()!=null)
			employeeCertificateService.addAllEmployeeCertificates(employeeDTO.getUserCertificates(), employee);
		
		if(employeeDTO.getUserProjectExperiences()!=null)
			projectExperienceService.addAllEmployeeProjectExperiences(employeeDTO.getUserProjectExperiences(), employee);
		
		if(employeeDTO.getUserWorkExperiences()!=null)
			workExperienceService.addAllEmployeeWorkExperiences(employeeDTO.getUserWorkExperiences(), employee);
		
		if(employeeDTO.getUserEducation()!=null)
			employeeEducationService.addAllEmployeeEducations(employeeDTO.getUserEducation(), employee);
		
		Integer[] skillIds=restTemplate.postForObject(skillClusterURL+"/skills_clusterMS/reviewSkill", employeeDTO.getSkills(),Integer[].class);
		List<Integer> skills=Arrays.asList(skillIds);
		List<EmployeeSkill> employeeSkills=skills.stream().map(skillId->{
			EmployeeSkill skill=new EmployeeSkill();
			skill.setSkillId(skillId);
			return skill;
		}).collect(Collectors.toList());
		
		employee.setEmployeeSkills(employeeSkills);
		employeeRepository.save(employee);
		return new ResponseEntity<>("Employee details successfully saved",HttpStatus.OK);
	}
	
	//fetching employee details with the help of their employee id
	public Employee getEmployeeById(Integer id) throws EmployeeDetailsNotFoundException
	{
		return employeeRepository.findById(id).orElseThrow(()->new EmployeeDetailsNotFoundException("Employee not found for id:"+id));
	}

	//function to update all employee details
	@Override
	public ResponseEntity<String> updateEmployeeDetails(EmployeeUpdateDTO employeeUpdateDTO) throws EmployeeDetailsNotFoundException{
		Employee employee=getEmployeeById(1);
		employee.setAboutMe(employeeUpdateDTO.getAboutMe());
		
		if(employeeUpdateDTO.getEmployeeCertificates()!=null)
			employeeCertificateService.updateAllEmployeeCertificates(employeeUpdateDTO.getEmployeeCertificates(), employee);
		
		if(employeeUpdateDTO.getEmployeeEducations()!=null)
			employeeEducationService.updateAllEmployeeEducations(employeeUpdateDTO.getEmployeeEducations(), employee);
		
		if(employeeUpdateDTO.getProjectExperiences()!=null)
			projectExperienceService.updateAllEmployeeProjectExperiences(employeeUpdateDTO.getProjectExperiences(), employee);
		
		if(employeeUpdateDTO.getWorkExperiences()!=null)
			workExperienceService.updateAllEmployeeWorkExperiences(employeeUpdateDTO.getWorkExperiences(), employee);
		
		employeeRepository.save(employee);
		return new ResponseEntity<>("Employee Updated Successfully",HttpStatus.OK);
	}

	//function to fetch all employee skills
	@Override
	public List<EmployeeSkillDTO> getEmployeeSkill()throws EmployeeDetailsNotFoundException{
		Employee employee = getEmployeeById(1);
		List<Integer> skillIds = new ArrayList<>();
		for(EmployeeSkill employeeSkill : employee.getEmployeeSkills()) {
			skillIds.add(employeeSkill.getSkillId());
		}
		SkillDTO[] responseSkills = restTemplate.postForObject(skillClusterURL+"/skills_clusterMS/getUserSkill", skillIds ,SkillDTO[].class);
		List<SkillDTO> skillDTOList = new ArrayList<>(Arrays.asList(responseSkills));
		List <EmployeeSkillDTO> employeeSkillDTOs = new ArrayList<>();
	    for (EmployeeSkill employeeSkill : employee.getEmployeeSkills()) {
	        for (SkillDTO skillDTO : skillDTOList) {
	            if (skillDTO.getSkillId().equals(employeeSkill.getSkillId())) {
	                EmployeeSkillDTO employeeSkillDTO = util.employeeskillToDTOconversion(employeeSkill, skillDTO);
	                employeeSkillDTOs.add(employeeSkillDTO);
	            }
	        }
	    }
	    return employeeSkillDTOs;
	}
	
	//function to update all employee skill details
	@Override
	public List<EmployeeSkill> updateEmployeeSkill(List<EmployeeSkillDTO> employeeSkillDTOs) throws EmployeeDetailsNotFoundException, NoValidSkillsFoundException {
	    if (employeeSkillDTOs == null || employeeSkillDTOs.isEmpty()) {
	        throw new NoValidSkillsFoundException("No valid skills found in the received request");
	    }

	    Employee employee = getEmployeeById(1);

	    List<String> skillNames = new ArrayList<>();
	    for (EmployeeSkillDTO dto : employeeSkillDTOs) {
	        if (dto.getProficiency() != null && dto.getSkillName() != null) {
	            skillNames.add(dto.getSkillName());
	        }
	    }
	    if (skillNames.isEmpty()) {
	        throw new NoValidSkillsFoundException("No valid skills found in the received request");
	    }

	    // Fetching skills from external service
	    SkillDTO[] skillsDTO = restTemplate.postForObject(skillClusterURL+"/skills_clusterMS/reviewSkillDTO", skillNames.toArray(new String[0]), SkillDTO[].class);
	    
	    List<String> DTOskillNames = new ArrayList<>();
	    for(SkillDTO skillDTO : skillsDTO) {
	        DTOskillNames.add(skillDTO.getSkillName().toLowerCase());
	    }

	    Map<String, SkillDTO> skillMap = new HashMap<>();
	    for (SkillDTO skillDTO : skillsDTO) {
	        skillMap.put(skillDTO.getSkillName().toLowerCase(), skillDTO);
	    }

	    Map<Integer, EmployeeSkill> currentSkills = new HashMap<>();
	    for (EmployeeSkill skill : employee.getEmployeeSkills()) {
	        currentSkills.put(skill.getSkillId(), skill);
	    }
	    
	    List<EmployeeSkill> updatedSkills = new ArrayList<>();
	    for (EmployeeSkillDTO dto : employeeSkillDTOs) {
	        if (dto != null && containsSkill(DTOskillNames, dto.getSkillName().toLowerCase())) {
	            SkillDTO skillDTO = skillMap.get(dto.getSkillName().toLowerCase());
	            EmployeeSkill existingSkill = currentSkills.get(skillDTO.getSkillId());
	            if (existingSkill == null) {
	                existingSkill = new EmployeeSkill();
	                existingSkill.setSkillId(skillDTO.getSkillId());
	                employee.getEmployeeSkills().add(existingSkill);
	            }
	            existingSkill.setProficiency(dto.getProficiency());
	            updatedSkills.add(existingSkill);
	        }
	    }
	    employeeRepository.save(employee);
	    return updatedSkills;
	}
	
	private boolean containsSkill(List<String> skillNames, String skillName) {
	    return skillNames.contains(skillName);
	}

	@Override
	public EmployeeResponseDTO getEmployeeProfileDetails(Integer id) throws EmployeeDetailsNotFoundException {
		Employee employee =getEmployeeById(id);
		EmployeeResponseDTO employeeResponseDTO=util.toGetEmployeeResponseDTO(employee);
		employeeResponseDTO.setEmployeeSkills(getEmployeeSkill());
		return employeeResponseDTO;
	}

	
	@Override
	public List<ManagerDetailsDTO> findManagerNamesByRole() {
		List<Employee> employeeList=employeeRepository.findManagerNamesByRole();
		List<ManagerDetailsDTO> managerDetailsDTOs=new ArrayList<>();
		for(Employee employee:employeeList) {
			ManagerDetailsDTO managerDetailsDTO=employeeMapper.employeeEntityToManagerDetailsDTO(employee);
			managerDetailsDTOs.add(managerDetailsDTO);
		}
		return managerDetailsDTOs;
	}
	
	@Override
	public void updateMergedSkills(MergeSkillDTO mergedSkillDTO) {
		
		List<Integer> mergeSkills = new ArrayList<>();
		Set<Integer> skillsToBeMerged = new HashSet<>();
		Set<Integer> employeeIds = new HashSet<>();
		
		for(SkillMergeResquestDTO SkillMergeResquestDTO : mergedSkillDTO.getMergeSkills()) {
			mergeSkills.add(SkillMergeResquestDTO.getSkillId());
		}
		
		List<EmployeeSkillEntry> employeeSkillsEntry =  employeeSkillEntryRepository.findBySkillIds(mergeSkills);
		
		for(EmployeeSkillEntry employeeSkillEntry : employeeSkillsEntry) {
			employeeIds.add(employeeSkillEntry.getId().getEmpId());
			skillsToBeMerged.add(employeeSkillEntry.getId().getSkillId());
		}
		
		for(Integer employeeID : employeeIds) {
	        CompositeKey compositeKey = new CompositeKey();
	        
	        compositeKey.setSkillId(mergedSkillDTO.getMergedSkill().getSkillId());
	        compositeKey.setEmpId(employeeID);
	        
            EmployeeSkillEntry newEntry = new EmployeeSkillEntry();
            
            newEntry.setId(compositeKey);
            employeeSkillEntryRepository.save(newEntry);
		
		employeeSkillEntryRepository.deleteBySkillIds(skillsToBeMerged);		
	}	
  }
}
