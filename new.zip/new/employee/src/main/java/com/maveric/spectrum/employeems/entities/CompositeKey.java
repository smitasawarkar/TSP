package com.maveric.spectrum.employeems.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Embeddable
@Data
public class CompositeKey implements Serializable {

    @Column(name="employee_id",nullable = false)
    private Integer empId;
    
    @Column(name="skill_id",nullable = false)
    private Integer skillId;
}
