package com.maveric.spectrum.apigateway.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
@RequestMapping("/microsoft")
public class LoginWithMicrosoft {

	private static final Logger logger = Logger.getLogger(LoginWithMicrosoft.class.getName());
	
	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/login")
	public ResponseEntity<String> login() {
		logger.info("Login with microsoft success");
		return ResponseEntity.ok("SUCCESS");
	}

	@GetMapping("/getuser")
	public Map<String, Object> user(@AuthenticationPrincipal OAuth2User principal,
			@RegisteredOAuth2AuthorizedClient OAuth2AuthorizedClient authorizedClient) {
		
		String name  = principal.getAttribute("name");
		String email = principal.getAttribute("email");

		Map<String, Object> userInfo = new HashMap<>();
		String oid = principal.getAttribute("oid") == null ? null : principal.getAttribute("oid").toString();
		
		ResponseEntity<byte[]> profilePictureResponse = getProfilePicture(oid,
				authorizedClient.getAccessToken().getTokenValue());
		
		if (profilePictureResponse.getStatusCode().is2xxSuccessful()) {
			byte[] profilePictureBytes = profilePictureResponse.getBody();
			String profilePictureBase64 = Base64.getEncoder().encodeToString(profilePictureBytes);
			userInfo.put("profilePicture", profilePictureBase64);
		} else {
			logger.info("ProfilePicture not found for User "+email);
			userInfo.put("profilePicture", null);
		}

		userInfo.put("name", name);
		userInfo.put("email", email);

		return userInfo;
	}

	private ResponseEntity<byte[]> getProfilePicture(String oid, String accessToken) {

		String profilePictureUrl = "https://graph.microsoft.com/v1.0/users/" + oid + "/photo/$value";

		HttpHeaders headers = new HttpHeaders();
		headers.setBearerAuth(accessToken);
		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		ResponseEntity<byte[]> response = restTemplate.exchange(profilePictureUrl, HttpMethod.GET, entity,
				byte[].class);

		return response;
	}

}
